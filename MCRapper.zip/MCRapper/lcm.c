/* Linear time Closed itemset Miner for Frequent Itemset Mining problems */
/* 2004/4/10 Takeaki Uno */
/* This program is available for only academic use.
   Neither commercial use, modification, nor re-distribution is allowed */

#ifndef _lcm_c_
#define _lcm_c_

#include<time.h>
//#include"lib_e.c"
#ifndef _lib_e_c_
#define _lib_e_c_

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<time.h>
#include<math.h>
//#include <sys/time.h>
//#include <sys/resource.h>

//#include"var_declare.h"
#include "getopt.h"
#include"transaction_keeping.h"
#include "unistd.h"

/* expanding array  */
typedef struct {
    void* h;
    int unit;
    int num;
    int end;
    int dellist;
} ARY;

int** LCM_Ot, ** LCM_Os;
int LCM_th;
ARY LCM_Trsact;
// VARIABLES DEFINED IN transaction_keeping.c
BM_TRANS_LIST current_trans;
// VARIABLES DEFINED IN wy.c
int N;
int n;
long long n_pvalues_computed;
long long n_cellcounts_computed;
long long effective_total_dataset_frq;
// VARIABLES DEFINED IN permutation.c
int Neff;
int J;
char* labels;
char** labels_perm;
int* cell_counts;


#define QUEUE_INT int


/*  max, min  */
#define MAX(a,b)      ((a)>(b)?a:b)
#define MIN(a,b)      ((a)<(b)?a:b)

#define   malloc2(f,a,b,c)     if(!(f=(a *)malloc(sizeof(a)*(b)))){printf("memory error %s (%d byte)\n",c,sizeof(a)*(b));exit(1);}
#define   realloc2(f,a,b,c)     if(!(f=(a *)realloc(f,sizeof(a)*(b)))){printf("memory error, %s (%d byte)\n",c,sizeof(a)*(b));exit(1);}
#define  free2(a)      {if(a){free(a);(a)=NULL;}a=0;}

#define   fopen2r(f,a,c)     if(!(f=fopen(a,"r+"))){printf("%s:file open error %s\n",c,a);exit(1);}
#define   fopen2w(f,a,c)     if(!(f=fopen(a,"w+"))){printf("%s:file open error %s\n",c,a);exit(1);}

/* structure for bit-array */
typedef struct {
    unsigned long* a;
    int end;
} BARRAY;

/* macros for bit-array operations */
#define BARRAY_SET(A,x) ((A).a[(x)/32]|=BITMASK_1[(x)%32])
#define BARRAY_RESET(A,x) ((A).a[(x)/32]&=BITMASK_31[(x)%32])
#define BARRAY_BIT(A,x) ((A).a[(x)/32]&BITMASK_1[(x)%32])
#define BARRAY_01(A,x) (((A).a[(x)/32]&BITMASK_1[(x)%32])/BITMASK_1[(x)%32])

/* structure for integer queue */
typedef struct {
    int s;
    int t;
    int end;
    int* q;
} QUEUE;


/* swap's */
int swap_tmp_int;
double swap_tmp_double;
char swap_tmp_char;
void* swap_tmp_pointer;
#define SWAP_INT(a,b)  (swap_tmp_int=a,a=b,b=swap_tmp_int)
#define SWAP_DOUBLE(a,b)  (swap_tmp_double=a,a=b,b=swap_tmp_double)
#define SWAP_CHAR(a,b)  (swap_tmp_char=a,a=b,b=swap_tmp_char)
#define SWAP_PNT(a,b)  (swap_tmp_pointer=(void *)a,a=b,b=swap_tmp_pointer)

/* macros for QUEUE operation */
#define QUEUE_LENGTH(Q) ((Q).t-(Q).s)
#define QUEUE_F_LOOP_(Q,i)  for((i)=(Q).s;(i)<(Q).t;(i)++)
#define QUEUE_FE_LOOP_(Q,i,x)  for((i)=(Q).s,x=(Q).q[i];(i)<(Q).t;(i)++,x=(Q).q[i])
#define QUEUE_B_LOOP_(Q,i)  for((i)=(Q).t-1;(i)>=(Q).s;(i)--)
#define QUEUE_BE_LOOP_(Q,i,x)  for((i)=(Q).t-1,x=(Q).q[i];(i)>=(Q).s;(i)--,x=(Q).q[i])
#define QUEUE_RMALL(Q) ((Q).t=(Q).s)
#define QUEUE_RMALL_(Q) ((Q).t=0)


/* constants for bit mask */
int BITMASK_UPPER1[32] = { 0xffffffff, 0xfffffffe, 0xfffffffc, 0xfffffff8,
                           0xfffffff0, 0xffffffe0, 0xffffffc0, 0xffffff80,
                           0xffffff00, 0xfffffe00, 0xfffffc00, 0xfffff800,
                           0xfffff000, 0xffffe000, 0xffffc000, 0xffff8000,
                           0xffff0000, 0xfffe0000, 0xfffc0000, 0xfff80000,
                           0xfff00000, 0xffe00000, 0xffc00000, 0xff800000,
                           0xff000000, 0xfe000000, 0xfc000000, 0xf8000000,
                           0xf0000000, 0xe0000000, 0xc0000000, 0x80000000 };
int BITMASK_UPPER1_[32] = { 0xfffffffe, 0xfffffffc, 0xfffffff8, 0xfffffff0,
                            0xffffffe0, 0xffffffc0, 0xffffff80, 0xffffff00,
                            0xfffffe00, 0xfffffc00, 0xfffff800, 0xfffff000,
                            0xffffe000, 0xffffc000, 0xffff8000, 0xffff0000,
                            0xfffe0000, 0xfffc0000, 0xfff80000, 0xfff00000,
                            0xffe00000, 0xffc00000, 0xff800000, 0xff000000,
                            0xfe000000, 0xfc000000, 0xf8000000, 0xf0000000,
                            0xe0000000, 0xc0000000, 0x80000000, 0x00000000 };

int BITMASK_LOWER1[32] = { 0x00000000, 0x00000001, 0x00000003, 0x00000007,
                           0x0000000f, 0x0000001f, 0x0000003f, 0x0000007f,
                           0x000000ff, 0x000001ff, 0x000003ff, 0x000007ff,
                           0x00000fff, 0x00001fff, 0x00003fff, 0x00007fff,
                           0x0000ffff, 0x0001ffff, 0x0003ffff, 0x0007ffff,
                           0x000fffff, 0x001fffff, 0x003fffff, 0x007fffff,
                           0x00ffffff, 0x01ffffff, 0x03ffffff, 0x07ffffff,
                           0x0fffffff, 0x1fffffff, 0x3fffffff, 0x7fffffff };
int BITMASK_LOWER1_[32] = { 0x00000001, 0x00000003, 0x00000007, 0x0000000f,
                            0x0000001f, 0x0000003f, 0x0000007f, 0x000000ff,
                            0x000001ff, 0x000003ff, 0x000007ff, 0x00000fff,
                            0x00001fff, 0x00003fff, 0x00007fff, 0x0000ffff,
                            0x0001ffff, 0x0003ffff, 0x0007ffff, 0x000fffff,
                            0x001fffff, 0x003fffff, 0x007fffff, 0x00ffffff,
                            0x01ffffff, 0x03ffffff, 0x07ffffff, 0x0fffffff,
                            0x1fffffff, 0x3fffffff, 0x7fffffff, 0xffffffff };

int BITMASK_1[32] = { 0x00000001, 0x00000002, 0x00000004, 0x00000008,
                      0x00000010, 0x00000020, 0x00000040, 0x00000080,
                      0x00000100, 0x00000200, 0x00000400, 0x00000800,
                      0x00001000, 0x00002000, 0x00004000, 0x00008000,
                      0x00010000, 0x00020000, 0x00040000, 0x00080000,
                      0x00100000, 0x00200000, 0x00400000, 0x00800000,
                      0x01000000, 0x02000000, 0x04000000, 0x08000000,
                      0x10000000, 0x20000000, 0x40000000, 0x80000000 };
int BITMASK_31[32] = { 0xfffffffe, 0xfffffffd, 0xfffffffb, 0xfffffff7,
                       0xffffffef, 0xffffffdf, 0xffffffbf, 0xffffff7f,
                       0xfffffeff, 0xfffffdff, 0xfffffbff, 0xfffff7ff,
                       0xffffefff, 0xffffdfff, 0xffffbfff, 0xffff7fff,
                       0xfffeffff, 0xfffdffff, 0xfffbffff, 0xfff7ffff,
                       0xffefffff, 0xffdfffff, 0xffbfffff, 0xff7fffff,
                       0xfeffffff, 0xfdffffff, 0xfbffffff, 0xf7ffffff,
                       0xefffffff, 0xdfffffff, 0xbfffffff, 0x7fffffff };


#define LCMINT int


/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/

/* allocate integer array and set value */
int* intarray_malloc_const(int end, int c) {
    int i, * a;
    malloc2(a, int, end, "intarray_malloc_const");
    for (i = 0; i < end; i++) a[i] = c;
    return (a);
}
/* quick sort of integers and its relationship function */
int qsort_int_cmp(const void* x, const void* y) {
    if (*((int*)x) < *((int*)y)) return (-1);
    else return (*((int*)x) > * ((int*)y));
}
int qsort_int_cmp_(const void* x, const void* y) {
    if (*((int*)x) > * ((int*)y)) return (-1);
    else return (*((int*)x) < *((int*)y));
}
void qsort_int(int* a, int siz) {
    qsort(a, siz, sizeof(int), qsort_int_cmp);
}
void qsort_int_(int* a, int siz) {
    qsort(a, siz, sizeof(int), qsort_int_cmp_);
}
void qsort_int_struct(int* a, int siz, int unit, int flag) {
    if (flag) qsort(a, siz, unit, qsort_int_cmp_);
    else qsort(a, siz, unit, qsort_int_cmp);
}
void qsort_int2(int* a, int siz) {
    qsort(a, siz, sizeof(int) * 2, qsort_int_cmp);
}
void qsort_int2_(int* a, int siz) {
    qsort(a, siz, sizeof(int) * 2, qsort_int_cmp_);
}


/* give an identical permutation */
int* init_perm(int end) {
    int i, * p;
    malloc2(p, int, end, "init_perm");
    for (i = 0; i < end; i++) p[i] = i;
    return (p);
}
/* give an inverse of a permutation */
int* inverse_perm(int* perm, int end) {
    int i, * p;
    malloc2(p, int, end, "inverse_perm");
    for (i = 0; i < end; i++) p[i] = -1;
    for (i = 0; i < end; i++)
        if (perm[i] >= 0 && perm[i] < end) p[perm[i]] = i;
    return (p);
}
/* permute array of struct according to permutation */
void perm_struct(void* a, int unit, int* perm, int siz) {
    int i;
    char* s, * ss = a;
    malloc2(s, char, unit * siz, "perm_struct");
    memcpy(s, ss, unit * siz);
    for (i = 0; i < siz; i++)
        memcpy(ss + unit * perm[i], s + unit * i, unit);
    free(s);
}
/* radix sort */
int* radix_sort(void* a, int siz, int unit, int mm, int m, int* perm, int flag) {
    int* ll, * l, k, i, t;
    l = intarray_malloc_const(m - mm, -1);
    malloc2(ll, int, siz, "radix_sort");
    for (i = 0; i < siz; i++) {
        k = (*((int*)(((char*)a) + unit * i))) - mm;
        ll[i] = l[k];
        l[k] = i;
    }
    if (perm) {
        for (k = 0, i = 0; k < m - mm; k++) {
            while (l[k] >= 0) {
                t = l[k];
                l[k] = ll[t];
                ll[t] = perm[i];
                i++;
            }
        }
        memcpy(perm, ll, sizeof(int) * siz);
        free(ll);
        free(l);
        return (perm);
    }
    else {
        for (k = 0, i = 0; k < m - mm; k++) {
            while (l[k] >= 0) {
                t = l[k];
                l[k] = ll[t];
                ll[t] = i;
                i++;
            }
        }
        free(l);
        return (ll);
    }
}




/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/

/* print a QUEUE */
void QUEUE_print(QUEUE* Q) {
    int i;
    for (i = Q->s; i < Q->t; i++) {
        printf("%d,", Q->q[i]);
    }
    printf("\n");
}
void QUEUE_print_(QUEUE* Q) {
    int i;
    for (i = 0; i < Q->t; i++) {
        printf("%d,", Q->q[i]);
    }
    printf("\n");
}
/* initialize QUEUE structure */
void QUEUE_init(QUEUE* Q, int siz) {
    Q->s = 0;
    Q->t = 0;
    Q->end = siz + 1;
    malloc2(Q->q, int, siz + 1, "QUEUE_init");
}
/* free QUEUE */
void QUEUE_end(QUEUE* Q) {
    if (Q->q) {
        free(Q->q);
        Q->q = 0;
    }
}
/* insert an element to the end of QUEUE */
void QUEUE_ins_(QUEUE* Q, int e) {
    Q->q[Q->t] = e;
    Q->t++;
}
QUEUE_INT QUEUE_ext_tail_(QUEUE* Q) {
    (Q->t)--;
    return (Q->q[Q->t]);
}

void QUEUE_sort_(QUEUE* Q) {
    qsort_int(Q->q, Q->t);
}
void QUEUE_sortr_(QUEUE* Q) {  /* reverse order */
    qsort_int_(Q->q, Q->t);
}


#define ARY_CELL(a,b,c) ((a *)((b).h+((b).unit*c)))

void ARY_exp(ARY* A, int num) {
    if (num >= A->end) {
        A->end = MAX(A->end * 2, num + 1);
        realloc2(A->h, char, A->unit * A->end, "ARY_exp: A->h");
    }
    if (A->num <= num) A->num = num + 1;
}

void ARY_inc(ARY* A) {
    ARY_exp(A, A->num);
}

void ARY_exp_const(ARY* A, int num, int c) {
    int end = A->end, * x;
    void* p;
    ARY_exp(A, num);
    for (p = A->h; end < A->end; end++) {
        //x = p + A->unit * end; zzjzzjzzjzzjzzj
        x = (int*)p + end;
        *x = c;
    }
}

void ARY_init(ARY* A, int unit) {
    A->num = 0;
    A->end = 0;
    A->unit = unit;
    A->h = NULL;
    A->dellist = -1;
}

void ARY_end(ARY* A) {
    free2(A->h);
}

void ARY_del(ARY* A, int num) {
    int* arycell = (int*)A->h+num;
    *arycell = A->dellist;
    //*ARY_CELL(int, *A, num) = A->dellist; zzjzzjzzjzzjzzjzzj
    A->dellist = -num - 2;
}

void ARY_rm(ARY* A, int num) {
    if (num < 0 || num >= A->num) {
        printf("ARY_rm: num is outside the array %d", num);
        exit(1);
    }
    A->num--;
    memcpy(((char*)(A->h)) + num * A->unit,
        ((char*)(A->h)) + A->num * A->unit, A->unit);
}

int ARY_new(ARY* A) {
    int num;
    if (A->dellist != -1) {
        num = -A->dellist - 2;
        int* arycell = (int*)A->h + num;
        A->dellist = *arycell;
        //A->dellist = *ARY_CELL(int, *A, num); zzjzzjzzjzzjzzjzzj
    }
    else {
        num = A->num;
        ARY_inc(A);
    }
    return (num);
}


/******   BUF   **************/

typedef struct {
    int num;
    int end;
    int unit;
    void** h;
    void* l;
    void* c;
    int siz;
    int init_siz;
} BUF;


void BUF_clear(BUF* B) {
    while (B->h[B->num]) { free2(B->h[B->num]); B->num--; }
    B->num--;
}

void BUF_inc(BUF* B) {
    B->num++;
    if (B->num >= B->end) {
        B->end *= 2;
        realloc2(B->h, void*, B->end, "BUF_inc: B->h");
    }
}

void BUF_set(BUF* B) {
    BUF_inc(B);
    malloc2(B->h[B->num], void*, B->unit * B->siz, "BUF_set");
    B->c = B->h[B->num];
    B->l = (void*)((char*)B->c + B->unit * B->siz);//zzjzzjzzjzzjzzjzzjzzj
}

void BUF_reset(BUF* B) {
    BUF_inc(B);
    B->h[B->num] = NULL;
    B->siz = B->init_siz;
    BUF_set(B);
}

void BUF_init(BUF* B, int unit, int init_siz) {
    B->unit = unit;
    B->init_siz = init_siz;
    B->end = 8;
    B->num = -1;
    malloc2(B->h, void*, 8, "BUF_init");
    BUF_reset(B);
}

void BUF_end(BUF* B) {
    while (B->num >= 0) { free2(B->h[B->num]); B->num--; }
    free2(B->h);
}

void* BUF_get(BUF* B, int siz) {
    void* zz, * z = (void*)((char*)B->c + (siz * B->unit));//zzjzzjzzjzzjzzjzzj
    if (z > B->l) {
        B->siz = MAX(siz, B->siz * 2);
        BUF_set(B);
        z = (void*)((char*)B->c + (siz * B->unit));//zzjzzjzzjzzjzzjzzj
    }
    zz = B->c;
    B->c = z;
    return (zz);
}


#endif
//#include"lcm_var.c"
#ifndef _lcm_var_c_
#define _lcm_var_c_



/**********************************************************************/
/*  Global Variables                                                  */
/**********************************************************************/

time_t LCM_start_time;
int LCM_maximum_time = 1000;

int** LCM_Ot, ** LCM_Os, * LCM_Ofrq, * LCM_Op, * LCM_Ofrq_;
int LCM_th;  /* support */
int LCM_frq; /* frequency of the current itemset */
int LCM_Eend;  /* #frequent items */
int LCM_trsact_num;   /* #transactions in original file */
int* LCM_ary; /* array of size (#frequent item), for temporary uses */
int* LCM_prune_ary; /* array to recover marks for pruning */
int LCM_iters = 0;  /* counting #iterations */
long* LCM_shrink_p;   /* working space for shrinking */
QUEUE LCM_shrink_jump;  /* working space for shrinking */
QUEUE LCM_jump, LCM_add, LCM_prune;
QUEUE LCM_itemset, LCM_Qtmp;  // needless?
int LCM_itemsett, LCM_jumpt, LCM_prv, LCM_pprv;
char** LCM_itemsetp, * LCM_itemsetbuf, * LCM_p;
QUEUE_INT* LCM_buf;  /* main buffer for storing items */
ARY LCM_Trsact; /* original transactions */
int* LCM_sc;    /* # of itemsets of size i, and max.size of itemsets */

  /* printflag&1:output to file &2:print messages &4 print solutions */
int LCM_problem = 0, LCM_method = 0;
#define LCM_FREQSET 1
#define LCM_CLOSED  2
#define LCM_MAXIMAL 4

#ifdef LCM_MESSAGES
int LCM_print_flag = 2;
#else 
int LCM_print_flag = 0;
#endif


#endif
#define LCM_PROBLEM LCM_CLOSED
//#include"trsact.c"
#ifndef _trsact_c_
#define _trsact_c_

#define QUEUE_INT int


//#include"lib_e.c"
//#include"lcm_bm.c"
#ifndef _lcm_bm_c_ 
#define _lcm_bm_c_ 

//#include"lcm_var.c"

/* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
//#include"transaction_keeping.c"
#ifndef _transaction_keeping_c_
#define _transaction_keeping_c_

/* INCLUDE DEPENDENCIES ON LCM CODE */
//Need access to some internal LCM variables


/* MACROS */
// Compute rounded up integer of quotient a/b
#define CEIL(a, b) (((a) / (b)) + (((a) % (b)) > 0 ? 1 : 0))

/* GLOBAL VARIABLES */
TRANS_LIST root_trans_list;
BM_TRANS_LIST* bm_trans_list;
BM_TRANS_LIST current_trans;
int** shrink_workspace1;
int* workspace1;
int* bitmap_item_frq;
int bm_trans_list_nodes;
int* non_empty_trans_idx;
//int print_counter = 0;

/* FUNCTION DECLARATIONS */
void remove_empty_transactions(char*);

/* AUXILIARY FUNCTIONS */

void TRANS_LIST_INIT(TRANS_LIST* L, int siz1, int siz2) {
    L->siz1 = siz1;
    L->siz2 = siz2;
    L->list = (int*)malloc(siz1 * sizeof(int));
    if (!L->list) {
        fprintf(stderr, "Error in function TRANS_LIST_INIT: couldn't allocate memory for array L->list\n");
        exit(1);
    }
    L->ptr = (int**)malloc(siz2 * sizeof(int*));
    if (!L->ptr) {
        fprintf(stderr, "Error in function TRANS_LIST_INIT: couldn't allocate memory for array L->ptr\n");
        exit(1);
    }
}

void TRANS_LIST_END(TRANS_LIST* L) {
    free(L->list);
    free(L->ptr);
}

void BM_TRANS_LIST_INIT(int n_items) {
    int i, n_nodes, mem_siz;
    int l1, l2;
    //Compute 2^LCM_BM_MAXITEM
    for (i = 0, n_nodes = 1; i < n_items; i++, n_nodes *= 2);
    //Allocate memory for BM_TRANS_LIST structure
    bm_trans_list = (BM_TRANS_LIST*)malloc(n_nodes * sizeof(BM_TRANS_LIST));
    if (!bm_trans_list) {
        fprintf(stderr, "Error in function BM_TRANS_LIST_INIT: couldn't allocate memory for array bm_trans_list\n");
        exit(1);
    }
    //Initialize lists inside each node of BM_TRANS_LIST
    //The (i+1)-th most frequent item has 2^i nodes, hence each node gets a share
    //of frq[i]/2^i *sizeof(int) bytes
    for (i = 0, l1 = 1, l2 = 2; i < n_items; i++, l2 *= 2) {
        mem_siz = CEIL(bitmap_item_frq[i], l1);
        //mem_siz = bitmap_item_frq[i];
        for (; l1 < l2; l1++) {
            bm_trans_list[l1].list = (int*)malloc(mem_siz * sizeof(int));
            if (!bm_trans_list[l1].list) {
                fprintf(stderr, "Error in function BM_TRANS_LIST_INIT: couldn't allocate memory for array bm_trans_list[l1].list\n");
                exit(1);
            }
            bm_trans_list[l1].max_siz = mem_siz;
            bm_trans_list[l1].siz = 0;
        }
    }
    bm_trans_list_nodes = n_nodes;
    // Initialize structure to keep current transaction
    current_trans.list = (int*)malloc(bitmap_item_frq[0] * sizeof(int));
    if (!current_trans.list) {
        fprintf(stderr, "Error in function BM_TRANS_LIST_INIT: couldn't allocate memory for array current_trans.list\n");
        exit(1);
    }
    current_trans.max_siz = bitmap_item_frq[0];
    current_trans.siz = 0;
}

void BM_TRANS_LIST_END() {
    int i;
    // Note that bm_trans_list[0] is in fact never initialized
    for (i = 1; i < bm_trans_list_nodes; i++) free(bm_trans_list[i].list);
    free(bm_trans_list);
}

void BM_TRANS_LIST_INSERT(int p, int* src, int siz) {
    int new_size;
    // If p==0, the transaction does not belong in the CPT
    if (p == 0) return;
    // Check if current list size if big enough to fit new data
    // If not, allocate double the current memory size
    new_size = bm_trans_list[p].siz + siz;
    if (new_size > bm_trans_list[p].max_siz) {
        new_size = (new_size > 2 * bm_trans_list[p].max_siz) ? new_size : 2 * bm_trans_list[p].max_siz;
        bm_trans_list[p].list = (int*)realloc(bm_trans_list[p].list, new_size * sizeof(int));
        if (!bm_trans_list[p].list) {
            fprintf(stderr, "Error in function BM_TRANS_LIST_INSERT: couldn't reallocate memory for array bm_trans_list[p].list\n");
            exit(1);
        }
        bm_trans_list[p].max_siz = new_size;
    }
    memcpy(bm_trans_list[p].list + bm_trans_list[p].siz, src, siz * sizeof(int));
    bm_trans_list[p].siz += siz;
}

void BM_TRANS_LIST_EMPTY(int p) {
    bm_trans_list[p].siz = 0;
}

void BM_CURRENT_TRANS_INSERT(int p) {
    // This list can never overflow its initially allocated size, equal to the frequency of the
    // most frequent item
    memcpy(current_trans.list + current_trans.siz, bm_trans_list[p].list, bm_trans_list[p].siz * sizeof(int));
    current_trans.siz += bm_trans_list[p].siz;
}

void BM_CURRENT_TRANS_EMPTY() {
    current_trans.siz = 0;
}

/* INITIALIZATION AND TERMINATION FUNCTIONS */

void transaction_keeping_init(char* trans_file) {
    int i;
    non_empty_trans_idx = (int*)malloc(LCM_Trsact.num * sizeof(int));
    if (!non_empty_trans_idx) {
        fprintf(stderr, "Error in function transaction_keeping_init: couldn't allocate memory for array non_empty_trans_idx\n");
        exit(1);
    }
    remove_empty_transactions(trans_file);
    TRANS_LIST_INIT(&root_trans_list, LCM_Trsact.num, LCM_Trsact.num);
    for (i = 0; i < LCM_Trsact.num; i++) {
        root_trans_list.list[i] = i;
        root_trans_list.ptr[i] = &root_trans_list.list[i];
    }
    // Cipher-permutation version
    /*
    for(i=0;i<LCM_Trsact.num;i++){
        root_trans_list.list[i] = non_empty_trans_idx[i];
        root_trans_list.ptr[i] = &root_trans_list.list[i];
    }
    // non_empty_trans_idx no longer necessary
    free(non_empty_trans_idx);
    */
    workspace1 = (int*)malloc(LCM_Trsact.num * sizeof(int));
    if (!workspace1) {
        fprintf(stderr, "Error in function transaction_keeping_init: couldn't allocate memory for array workspace1\n");
        exit(1);
    }
    shrink_workspace1 = (int**)malloc(LCM_Trsact.num * sizeof(int*));
    if (!shrink_workspace1) {
        fprintf(stderr, "Error in function transaction_keeping_init: couldn't allocate memory for array shrink_workspace1\n");
        exit(1);
    }
    for (i = 0; i < LCM_Trsact.num; i++) shrink_workspace1[i] = ((int*)0);
}

void transaction_keeping_end() {
    TRANS_LIST_END(&root_trans_list);
    BM_TRANS_LIST_END();
    free(bitmap_item_frq);
    free(shrink_workspace1);
    free(workspace1);
    free(current_trans.list);
    //printf("Number of lines outputted: %d\n",print_counter);
}

/* FUNCTION FOR DEALING WITH EMPTY TRANSACTIONS */
void remove_empty_transactions(char* trans_file) {
    char c;
    FILE* f_trans = ((FILE*)0);
    int n_lines = 0, n_lines_non_empty = 0;
    int non_empty_line_flag = 0;

    //Try to open file, giving an error message if it fails
    if (!(f_trans = fopen(trans_file, "r"))) {
        fprintf(stderr, "Error in function remove_empty_transactions when opening file %s\n", trans_file);
        exit(1);
    }

    // Scan transaction database to find non-empty transactions and store their indices in
    // non_empty_trans_idx
    while ((c = fgetc(f_trans)) != EOF) {
        if (c == '\n') {
            if (non_empty_line_flag) non_empty_trans_idx[n_lines_non_empty++] = n_lines;
            n_lines++;
            non_empty_line_flag = 0;
        }
        else {
            non_empty_line_flag = 1;
        }
    }

    // Close file
    fclose(f_trans);
}


/* FUNCTION FOR DISPLAYING TRANSACTIONS OF A NON-BITMAP REPRESENTED ITEMSET */
/*
void print_transaction_list(TRANS_LIST *L,int item){
    int *t, *t_end;
    int *ptr, *end_ptr;
    print_counter++;
    return;
    for(t=LCM_Os[item],t_end=LCM_Ot[item];t<t_end;t++){
        end_ptr = (*t == (L->siz2-1)) ? L->list + L->siz1 : L->ptr[*t+1];
        for(ptr = L->ptr[*t];ptr < end_ptr;ptr++){
            if((ptr==(end_ptr-1)) && (t==(t_end-1))) printf("%d",*ptr);
            else printf("%d,",*ptr);
        }
    }
    printf("\n");
}

void print_current_trans(){
    int i;
    print_counter++;
    return;
    for(i=0;i<(current_trans.siz-1);i++) printf("%d,",current_trans.list[i]);
    printf("%d\n",current_trans.list[i]);
}

void print_trans0(){
    int i;
    print_counter++;
    return;
    for(i=0;i<(bm_trans_list[1].siz-1);i++) printf("%d,",bm_trans_list[1].list[i]);
    printf("%d\n",bm_trans_list[1].list[i]);
}
*/
#endif
/* END OF MODIFICATIONS */

void LCM_trsact_and(QUEUE_INT* q, QUEUE_INT* qq, int* t);
void LCM_additem(int item);

int LCM_BM_space;
int* LCM_BM_weight;
char* LCM_BM_highbit;
int LCM_BM_MAXITEM, LCM_BM_prefix_max;
int* LCM_BM_pt;
int* LCM_BM_pp;
QUEUE_INT** LCM_BM_pq;
BUF LCM_B;



void LCM_BM_init() {
    int i, ii, m, mm;
    for (ii = 0, LCM_BM_space = 1; ii < LCM_BM_MAXITEM; ii++, LCM_BM_space *= 2);
    malloc2(LCM_BM_weight, int, LCM_BM_space, "LCM_BM_init: LCM_BM_weight");
    malloc2(LCM_BM_highbit, char, LCM_BM_space, "LCM_BM_init: LCM_BM_highbit");
    if (LCM_PROBLEM == LCM_CLOSED) {
        malloc2(LCM_BM_pt, int, LCM_BM_space, "LCM_BM_init: LCM_BM_pt");
        malloc2(LCM_BM_pp, int, LCM_BM_space, "LCM_BM_init: LCM_BM_pt");
        malloc2(LCM_BM_pq, QUEUE_INT*, LCM_BM_space, "LCM_BM_init: LCM_BM_pq");
        BUF_init(&LCM_B, sizeof(int), 10000);
    }
    for (m = ii = 0, mm = 2; ii < LCM_BM_MAXITEM; ii++, mm *= 2) {
        for (; m < mm; m++) {
            LCM_BM_weight[m] = 0;
            LCM_BM_highbit[m] = ii;
        }
    }
}

void LCM_BM_end() {
    free2(LCM_BM_weight);
    free2(LCM_BM_highbit);
    if (LCM_PROBLEM == LCM_CLOSED) {
        free2(LCM_BM_pt);
        free2(LCM_BM_pp);
        free2(LCM_BM_pq);
        BUF_end(&LCM_B);
    }
}

/****************************************************************************/
/*       Occurrence Deliver for Bitmap                                      */
/* input: occ:occurrences, max_item                                         */
/* CAHNGE: for each item i<max_item, set O->h[i] to the transactions of occ */
/*    including i (items larger than i are removed from the transactions)   */
/****************************************************************************/
void LCM_BM_occurrence_deliver_proc(int p, int frq) {
    int* ww = &LCM_BM_weight[p];
    if (*ww == 0) {
        int h = LCM_BM_highbit[p];
        *LCM_Ot[h] = p;
        LCM_Ot[h]++;
    }
    *ww += frq;
}


void LCM_BM_occurrence_deliver_iter(int item, int mask) {
    int w = 0, * t, * t_end, ww;
    mask &= BITMASK_LOWER1[item];
    for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
        ww = LCM_BM_weight[*t];
        w += ww;
        LCM_BM_occurrence_deliver_proc(*t & mask, ww);
    }
    LCM_Ofrq[item] = w;
}

void LCM_BM_occurrence_deliver_iter_delete(int item, int mask) {
    int i, * t, * t_end, * ww;
    mask &= BITMASK_LOWER1[item];
    for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
        ww = &(LCM_BM_weight[*t]);
        LCM_BM_occurrence_deliver_proc(*t & mask, *ww);
        *ww = 0;
    }
    LCM_Ot[item] = LCM_Os[item];
    LCM_Ofrq[item] = 0;
}

void LCM_BM_occurrence_deliver(int item, int mask) {
    for (; item > 1; item--) LCM_BM_occurrence_deliver_iter(item, mask);
    LCM_Ofrq[0] = LCM_BM_weight[1] + LCM_BM_weight[3];
    LCM_Ofrq[1] = LCM_BM_weight[2] + LCM_BM_weight[3];
}

void LCM_BM_occurrence_deliver_(int item, int mask) {
    LCM_BM_occurrence_deliver_iter_delete(item, mask);
    LCM_BM_occurrence_deliver(item - 1, mask);
}


void LCM_BM_occurrence_deliver_first(int item, ARY* T) {
    int p, i, m = BITMASK_LOWER1[LCM_BM_MAXITEM];
    QUEUE* TQ = T->h;
    if (item < 0) {  /* then, occ is considered top be "all transactions" */
        long t;
        for (t = 0; t < T->num; t++)
            LCM_BM_occurrence_deliver_proc(TQ[t].s & m, TQ[t].end);
    }
    else {
        int* t, * t_end;
        for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++)
            LCM_BM_occurrence_deliver_proc(TQ[*t].s & m, TQ[*t].end);
    }
    LCM_BM_occurrence_deliver(LCM_BM_MAXITEM - 1, 0xffffffff);
}


void LCM_BM_occurrence_delete(int item) {
    if (item == 0) {
        LCM_BM_weight[1] = 0;
        /* MODIFICATIONS TO KEEP TRACK OF TRANSACTIONS */
        BM_TRANS_LIST_EMPTY(1);
        /* END OF MODIFICATIONS */
    }
    else {
        int* t, * t_end;
        for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
            LCM_BM_weight[*t] = 0;
            /* MODIFICATIONS TO KEEP TRACK OF TRANSACTIONS */
            BM_TRANS_LIST_EMPTY(*t);
            /* END OF MODIFICATIONS */
        }
    }
    LCM_Ot[item] = LCM_Os[item];
    LCM_Ofrq[item] = 0;
}


/****************************************************************************/
/*       Occurrence Deliver for Bitmap                                      */
/* input: occ:occurrences, max_item                                         */
/* CAHNGE: for each item i<max_item, set O->h[i] to the transactions of occ */
/*    including i (items larger than i are removed from the transactions)   */
/****************************************************************************/
void LCMclosed_BM_occ_deliver_proc(int p, int pp) {
    if (p == 0) return;
    if (LCM_BM_weight[p] == 0) {
        *LCM_Ot[LCM_BM_highbit[p]]++ = p;
        int* z = BUF_get(&LCM_B, LCM_BM_pt[pp] + 1);
        memcpy(z, LCM_BM_pq[pp], (LCM_BM_pt[pp] + 1) * sizeof(int));
        LCM_BM_pp[p] = LCM_BM_pp[pp];
        LCM_BM_pq[p] = z;
        LCM_BM_pt[p] = LCM_BM_pt[pp];
    }
    else {
        LCM_trsact_and(LCM_BM_pq[p], LCM_BM_pq[pp], &LCM_BM_pt[p]);
        LCM_BM_pp[p] &= LCM_BM_pp[pp];
    }
    LCM_BM_weight[p] += LCM_BM_weight[pp];
    /* MODIFICATION TO KEEP TRACK OF TRANSACTIONS */
    BM_TRANS_LIST_INSERT(p, bm_trans_list[pp].list, bm_trans_list[pp].siz);
    /* END OF MODIFICATION */
}
void LCMclosed_BM_occ_deliver_first_proc(QUEUE* Q, int mask, int imax) {
    int p = Q->s & mask, pp = p, * x;
    if (p == 0) return;
    for (x = Q->q; *x <= imax; x++)
        if (LCM_Ofrq[*x] >= LCM_th) pp |= BITMASK_1[LCM_Op[*x]];
    if (LCM_BM_weight[p] == 0) {
        *LCM_Ot[LCM_BM_highbit[p]]++ = p;
        int* z = BUF_get(&LCM_B, Q->t + 1), * zz;
        for (zz = z; *x < LCM_Eend; x++)
            if (LCM_Ofrq[*x] >= LCM_th) { *zz = *x; zz++; }
        *zz = LCM_Eend;
        LCM_BM_pp[p] = pp;
        LCM_BM_pq[p] = z;
        LCM_BM_pt[p] = zz - z;
    }
    else {
        LCM_trsact_and(LCM_BM_pq[p], x, &(LCM_BM_pt[p]));
        LCM_BM_pp[p] &= pp;
    }
    LCM_BM_weight[p] += Q->end;
}

void LCMclosed_BM_occurrence_deliver_iter(int item, int mask) {
    int w = 0, * t, * t_end;
    mask &= BITMASK_LOWER1[item];
    for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
        w += LCM_BM_weight[*t];
        LCMclosed_BM_occ_deliver_proc(*t & mask, *t);
    }
    LCM_Ofrq[item] = w;
}

void LCMclosed_BM_occurrence_deliver_iter_delete(int item, int mask) {
    int* t, * t_end;
    int flag_aux, i;
    mask &= BITMASK_LOWER1[item];

    if (item < 0) {
        for (i = 0; i < LCM_BM_MAXITEM; i++) {
            flag_aux = LCM_Ot[i] - LCM_Os[i];
            if (flag_aux) printf("Bucket of item %d not empty. Size %d. Parent node %d.\n", i, item, flag_aux);
        }
    }
    else {
        for (i = 0; i < item; i++) {
            flag_aux = LCM_Ot[i] - LCM_Os[i];
            if (flag_aux) printf("Bucket of item %d not empty. Size %d. Parent node %d.\n", i, item, flag_aux);
        }
    }

    for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
        LCMclosed_BM_occ_deliver_proc(*t & mask, *t);
        LCM_BM_weight[*t] = 0;
        /* MODIFICATIONS TO KEEP TRACK OF TRANSACTIONS */
        BM_CURRENT_TRANS_INSERT(*t);
        BM_TRANS_LIST_EMPTY(*t);
        /* END OF MODIFICATIONS */
    }
    LCM_Ot[item] = LCM_Os[item];
    LCM_Ofrq[item] = 0;
}

void LCMclosed_BM_occurrence_deliver(int item, int mask) {
    for (; item > 1; item--) {
        LCMclosed_BM_occurrence_deliver_iter(item, mask);
    }
    LCM_Ofrq[0] = LCM_BM_weight[1] + LCM_BM_weight[3];
    LCM_Ofrq[1] = LCM_BM_weight[2] + LCM_BM_weight[3];
    if (LCM_BM_weight[3] > 0) LCMclosed_BM_occ_deliver_proc(1, 3);
}

void LCMclosed_BM_occurrence_deliver_(int item, int mask) {
    LCMclosed_BM_occurrence_deliver_iter_delete(item, mask);
    LCMclosed_BM_occurrence_deliver(item - 1, mask);
}

// LAST ARGUMENT ADDED FOR TRANSACTION KEEPING
void LCMclosed_BM_occurrence_deliver_first(int item, ARY* T, TRANS_LIST* trans_list) {
    int p, i, m = BITMASK_LOWER1[LCM_BM_MAXITEM], jt = LCM_jump.t, imax = -1, flag = 0;

    int flag_aux;

    QUEUE* TQ = T->h;

    if (item < 0) {
        for (i = 0; i < LCM_BM_MAXITEM; i++) {
            flag_aux = LCM_Ot[i] - LCM_Os[i];
            if (flag_aux) printf("Bucket of item %d not empty. Size %d. Parent node %d.\n", i, item, flag_aux);
        }
    }
    else {
        for (i = 0; i < item; i++) {
            flag_aux = LCM_Ot[i] - LCM_Os[i];
            if (flag_aux) printf("Bucket of item %d not empty. Size %d. Parent node %d.\n", i, item, flag_aux);
        }
    }

    //  shift prefix items to bitmap of upper parts
    for (i = LCM_BM_MAXITEM; i < sizeof(int) * 8; i++) {
    START:;
        if (flag == 1 && jt == LCM_jump.t) break;
        if (jt == LCM_jump.s) { jt = LCM_jumpt; flag = 1; goto START; }
        jt--;
        imax = LCM_jump.q[jt];
        LCM_Op[imax] = i;
        // printf ("(%d), %d %d: %d -> %x  (%dth,%d:%d)\n", item, LCM_pprv, LCM_prv, imax, BITMASK_1[i], jt-LCM_jump.s, LCM_jump.t-LCM_jump.s, LCM_jumpt-LCM_jump.s);
    }
    LCM_BM_prefix_max = i;

    if (item < 0) {  /* then, occ is considered top be "all transactions" */
        long t;
        for (t = 0; t < T->num; t++) {
            LCMclosed_BM_occ_deliver_first_proc(&TQ[t], m, imax);
            /* MODIFICATION TO KEEP TRACK OF TRANSACTIONS */
            //Insert all the original transactions of transaction t into the appropriate queue in BM_TRANS_LIST (node given by the masked bitmap prefix of the transaction TQ[t].s&m)
            //The last argument is simply the number of elements to be inserted, which has to take care of checking whether we are inserting the last transaction (boundary case) or not
            BM_TRANS_LIST_INSERT(TQ[t].s & m, trans_list->ptr[t], (t == (trans_list->siz2 - 1)) ? (trans_list->list + trans_list->siz1) - trans_list->ptr[t] : trans_list->ptr[t + 1] - trans_list->ptr[t]);
            /* END OF MODIFICATIONS */
        }
    }
    else {
        int* t, * t_end;
        for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
            LCMclosed_BM_occ_deliver_first_proc(&TQ[*t], m, imax);
            /* MODIFICATION TO KEEP TRACK OF TRANSACTIONS */
            //Insert all the original transactions of transaction *t into the appropriate queue in BM_TRANS_LIST (node given by the masked bitmap prefix of the transaction TQ[t].s&m)
            //The last argument is simply the number of elements to be inserted, which has to take care of checking whether we are inserting the last transaction (boundary case) or not
            BM_TRANS_LIST_INSERT(TQ[*t].s & m, trans_list->ptr[*t], (*t == (trans_list->siz2 - 1)) ? (trans_list->list + trans_list->siz1) - trans_list->ptr[*t] : trans_list->ptr[*t + 1] - trans_list->ptr[*t]);
            /* END OF MODIFICATIONS */
        }
    }

    LCMclosed_BM_occurrence_deliver(LCM_BM_MAXITEM - 1, 0xffffffff);
}




/********************************************************************/
/********************************************************************/
/********************************************************************/


int LCM_BM_rm_infreq(int item, int* pmask) {
    int i, m = 0, flag = -1;
    for (i = 0; i < item; i++) {
        if (LCM_Ofrq[i] >= LCM_th) {
            if (LCM_Ofrq[i] == LCM_frq) {
                if (LCM_PROBLEM == LCM_FREQSET) QUEUE_ins_(&LCM_add, LCM_Op[i]);
                else {
                    LCM_additem(LCM_Op[i]);
                    *pmask &= BITMASK_31[i];
                }
                LCM_BM_occurrence_delete(i);
            }
            else m |= BITMASK_1[i];
        }
        else {
            LCM_BM_occurrence_delete(i);
        }
    }
    return (m);
}

/*************************************************************************/
/* set TT to the transactions of occ with frequency in the given
  upper and lower bounds */
  /* return #all freq items */
  /*************************************************************************/
  // LAST TWO ARGUMENTS ADDED FOR TRANSACTION KEEPING
int LCM_mk_freq_trsact(ARY* TT, ARY* T, QUEUE_INT item, QUEUE_INT max_item, int cnt, int mask, TRANS_LIST* old_trans_list, TRANS_LIST* new_trans_list) {
    QUEUE_INT* x, * buf, * bbuf, * b;
    QUEUE* Q = T->h, * QQ;
    int i, ii, n = 0, imax = -1, flag, jt = LCM_jump.t, * t, * t_end;

    /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
    int n_items_cpy;
    int* trans_list_buf = new_trans_list->list;
    new_trans_list->siz1 = 0;
    new_trans_list->siz2 = 0;
    /* END OF MODIFICATIONS */

    for (i = 0; i < LCM_BM_MAXITEM; i++) {
        if (LCM_Ofrq[i] < LCM_th) {
            LCM_jump.t--;
            imax = LCM_jump.q[LCM_jump.t];
            LCM_Op[imax] = i;
            LCM_Op[i] = imax;
            if (LCM_jump.t == LCM_jump.s) break;
        }
    }

    ARY_init(TT, sizeof(QUEUE));
    ARY_exp(TT, (LCM_Ot[item] - LCM_Os[item]) - 1);
    QQ = TT->h;
    malloc2(buf, QUEUE_INT, cnt, "TRSACT_mk_freq_trsact: buf");
    bbuf = buf;
    for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
        QQ[n].q = b = buf;
        QQ[n].s = Q[*t].s & mask;
        x = Q[*t].q;
        for (; *x <= imax; x++)
            if (LCM_Ofrq[*x] > 0) QQ[n].s |= BITMASK_1[LCM_Op[*x]];
        for (; *x <= max_item; x++)
            if (LCM_Ofrq[*x] > 0) { *buf = *x; buf++; }
        if (buf != b || QQ[n].s > 0) {
            QQ[n].t = buf - b;
            QQ[n].end = Q[*t].end;   /* multiplicity of transaction t */
            *buf = LCM_Eend;
            buf++;
            /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
            new_trans_list->ptr[n] = trans_list_buf;
            n_items_cpy = (*t == (old_trans_list->siz2 - 1)) ? (old_trans_list->list + old_trans_list->siz1) - old_trans_list->ptr[*t] : old_trans_list->ptr[*t + 1] - old_trans_list->ptr[*t];
            memcpy(trans_list_buf, old_trans_list->ptr[*t], sizeof(int) * n_items_cpy);
            new_trans_list->siz1 += n_items_cpy;
            trans_list_buf += n_items_cpy;
            /* END OF MODIFICATIONS */
            n++;
        }
    }
    for (i = LCM_jump.t; i < jt; i++) {
        LCM_Ofrq[LCM_jump.q[i]] = 0;
        if (LCM_PROBLEM != LCM_FREQSET) LCM_Ofrq_[LCM_jump.q[i]] = 0;
    }
    if (LCM_PROBLEM != LCM_FREQSET) {
        for (imax = LCM_jump.t; i < LCM_jumpt; i++, imax++)
            LCM_jump.q[imax] = LCM_jump.q[i];
        LCM_jumpt = imax;
    }
    TT->num = n;
    /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
    new_trans_list->siz2 = n;
    /* END OF MODIFICATIONS */
    return (buf - bbuf);
}

///////////////////////////////////////////

int LCM_BM_closure(int item, int pmask) {
    int i, * t, * t_end, p = pmask & BITMASK_UPPER1[item], ee, z = -1;
    QUEUE_INT* x, * jq = &(LCM_jump.q[LCM_jump.t]), * jqq = jq, * jjq, * xx;

    for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
        p &= LCM_BM_pp[*t];
        ee = LCM_BM_weight[*t];
        for (x = LCM_BM_pq[*t]; *x < LCM_Eend; x++) {
            if (LCM_Ofrq[*x] == 0) { *jq = *x; jq++; }
            LCM_Ofrq[*x] += ee;
        }
    }
    if (p) {
        for (i = item + 1; i < LCM_BM_MAXITEM; i++)
            if ((p & BITMASK_1[i]) && LCM_Op[i] > z) z = LCM_Op[i];
        for (; i < LCM_BM_prefix_max; i++)
            if ((p & BITMASK_1[i])) z = LCM_prv;
    }
    for (jjq = jq - 1; jjq >= jqq; jjq--)
        if (LCM_Ofrq[*jjq] == LCM_frq && *jjq > z) z = *jjq;

    if (z < 0 && jq>jqq) {
        for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
            for (xx = x = LCM_BM_pq[*t]; *x < LCM_Eend; x++) {
                if (LCM_Ofrq[*x] >= LCM_th) {
                    if (x > xx) *xx = *x;
                    xx++;
                }
            }
            if (x != xx) { *xx = LCM_Eend; LCM_BM_pt[*t] = xx - LCM_BM_pq[*t]; }
        }
    }

    for (jjq = jq - 1; jjq >= jqq; jjq--) LCM_Ofrq[*jjq] = 0;
    return(z);
}

#endif

/* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
//#include"transaction_keeping.c"
/* END OF MODIFICATIONS */

/***********************************/
/*   print transactions            */
/***********************************/
void TRSACT_print(ARY* T) {
    int i, j, e;
    QUEUE* Q = T->h;
    for (i = 0; i < T->num; i++) {
        for (j = 0; j < Q[i].t; j++) {
            e = Q[i].q[j];
            printf("%d,", e);
        }
        printf(" (%d)\n", Q[i].end);
    }
}


/********************************************************************/
/* sort indices of frequent items by their frequency                */
/* INPUT: E:counters of items, th:support                           */
/* RETURN: permutation, #freq items                                 */
/* CHANGE: counters (-1 if infrequent )                             */
/* set *num to the size of database composed only of frequent items */
/* set *Enum to #frequent items                                     */
/********************************************************************/
int* TRSACT_sort_item_by_frq(ARY* E, int th, int* num, int* Enum) {
    int* Eq = E->h, * perm, i;
    *num = 0;
    *Enum = 0;
    malloc2(perm, int, E->num * 2, "TRSACT_perm_freq_item: perm");
    for (i = 0; i < E->num; i++) {
        if (Eq[i] >= th) {
            perm[(*Enum) * 2] = Eq[i];
            perm[(*Enum) * 2 + 1] = i;
            (*Enum)++;
            *num += Eq[i];
        }
        else Eq[i] = -1;
    }
    qsort(perm, *Enum, sizeof(int) * 2, qsort_int_cmp_);
    for (i = 0; i < *Enum; i++) perm[i] = perm[i * 2 + 1];
    realloc2(perm, int, *Enum, "TRSACT_sort_item_by_frq: perm");
    return (perm);
}

/*****************************/
/* sort transactions by their sizes */
/* input: T:transactions, jump:list of frequnet items, p:working space */
/*****************************/
void TRSACT_sort_by_size(ARY* T, QUEUE* jump, long* p) {
    int* q, t, tt, ii;
    QUEUE* Q = T->h, * Qtmp;
    QUEUE_INT* jq, * jqq;

    malloc2(Qtmp, QUEUE, T->num, "TRSACT_sort_size: Qtmp");
    malloc2(q, int, T->num, "TRSACT_sort_size: q");

    for (t = 0, jq = jump->q; t < T->num; t++) {
        ii = Q[t].t;
        if (p[ii] == -1) { *jq = ii; jq++; }  /* insert each tr */
        q[t] = p[ii];
        p[ii] = t;
    }

    jump->t = jq - jump->q;
    QUEUE_sort_(jump);  /* sort "sizes" */
    jump->t = 0;

    for (tt = 0, jqq = jq - 1; jqq >= jump->q; jqq--) {
        for (t = p[*jqq]; t >= 0; t = q[t]) {
            Qtmp[tt] = Q[t];
            tt++;
        }
        p[*jqq] = -1;
    }
    memcpy(Q, Qtmp, sizeof(QUEUE) * T->num);

    free(Qtmp);
    free(q);
}


/************************************************************************/
/*       Occurrence Deliver                                             */
/* input: T:transactions, max_item                                      */
/* CAHNGE: for each item e<max_item, set O->h[e].q to the transactions  */
/*     including e, and set O->h[e].t to the # of such transactions     */
/************************************************************************/
void LCM_occ_deliver(ARY* T, QUEUE_INT max_item) {
    int t;
    QUEUE_INT* x;
    QUEUE* Q = T->h;
    for (t = 0; t < T->num; t++) {
        for (x = Q[t].q; *x <= max_item; x++) { *LCM_Ot[*x] = t; *LCM_Ot[*x]++; }
    }
}

/**************************************************************/
/* initialization of shrink operation */
/* input: T:transactions, Eend:# of items */
/* output: working space (array of long integers) */
/* alloc the working space to *jump (QUEUE) */
/**************************************************************/
void LCM_shrink_init(ARY* T, QUEUE_INT Eend) {
    int i;
    malloc2(LCM_shrink_p, long, Eend * 2 + T->num * 4 + 4, "TRSACT_shrink_init");
    for (i = 0; i < Eend * 2 + 2; i++) LCM_shrink_p[i] = -1;
    QUEUE_init(&LCM_shrink_jump, Eend * 2 + 2);
    LCM_shrink_jump.end = Eend;
}


void LCM_trsact_and(QUEUE_INT* q, QUEUE_INT* qq, int* t) {
    int* xx, * x1, * x2;
    for (xx = x1 = q, x2 = qq; *x1 < LCM_Eend; x1++) {
        while (*x2 < *x1) x2++;
        if (*x2 == *x1) {
            if (x1 != xx) *xx = *x1;
            xx++;
            x2++;
        }
    }
    *xx = LCM_Eend;
    *t = xx - q;
}


/**************************************************************/
/* shrink T */
/* input: T:transactions, jump,q:working space(re-use for omiting initialization) */
/* find the identical transactions from T by radix sort (bucket sort)
  and merge them into one transaction */
  /* set T->h[i].end to the multiplicity of transaction i
       (# of transactions merged to i) */
       /* flag&1 => BitMap version */
       /* flag&2 => for closed sets */
       /*************************************************************************/
       // LAST TWO ARGUMENTS ADDED TO KEEP TRACK OF TRANSACTIONS
void LCM_shrink(ARY* T, int max_item, int flag, TRANS_LIST* old_trans_list, TRANS_LIST* new_trans_list) {
    int ii, j, t, tt = -1, v, vv, end = LCM_shrink_jump.end;
    QUEUE_INT* jt, * jtt, * jq = LCM_shrink_jump.q, * jqq = jq + end + 1;
    long* p = LCM_shrink_p;
    long* pp = &p[end + 1], * q = &p[end * 2 + 2], * qq = &p[end * 2 + 2 + T->num * 2];
    QUEUE* Q = T->h;
    QUEUE_INT* x1, * xx, * x2;

    /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
    int* workspace_buf = workspace1;
    int* trans_list_buf = new_trans_list->list;
    int* aux_buf;
    int n_items_cpy;
    int counter = 0;
    /* END OF MODIFICATIONS */

    if (flag & 1) {  /*  BitMap version */
        LCM_BM_weight[0] = 0;  // it is not cleared in other routines
        for (t = 0; t < T->num; t++) {
            j = LCM_BM_weight[Q[t].s];
            if (LCM_BM_weight[Q[t].s] == 0) {
                qq[t * 2] = tt;
                qq[t * 2 + 1] = t;
                LCM_BM_weight[Q[t].s] = t + 1;
                tt = t;
            }
            else {
                j--;
                qq[t * 2] = qq[j * 2];
                qq[j * 2] = t;
                qq[t * 2 + 1] = j;
            }
        }
        jtt = jqq + 1; *jqq = 0; pp[0] = tt;
        for (t = 0; t < T->num; t++) LCM_BM_weight[Q[t].s] = 0;
        j = 0;
    }
    else {   /* normal version */
        exit(1);
        for (t = 0, jtt = jqq; t < T->num; t++) {
            ii = Q[t].q[0];
            if (pp[ii] == -1) { *jtt = ii; jtt++; }
            qq[t * 2] = pp[ii];
            qq[t * 2 + 1] = 0;
            pp[ii] = t;
        }
        j = 1;
    }

    for (; jtt > jqq; j++) {
        for (jt = jq; jtt > jqq;) {
            jtt--;
            if (*jtt == max_item) goto END2;
            t = pp[*jtt];
            pp[*jtt] = -1;
            v = -1;
            do {
                tt = qq[t * 2];
                if (v != qq[t * 2 + 1]) {
                    v = qq[t * 2 + 1];
                    vv = t;
                    if (tt < 0) goto END2;
                    if (qq[tt * 2 + 1] != v) goto END1;
                }
                ii = Q[t].q[j];
                if (p[ii] == -1) { *jt = ii; jt++; }
                q[t * 2] = p[ii];
                p[ii] = t;
                q[t * 2 + 1] = vv;
            END1:;
                t = tt;
            } while (tt >= 0);
        END2:;
        }

        if ((tt = pp[max_item]) < 0) goto END3;
        pp[max_item] = -1;
        while (1) {
            t = tt;
            v = qq[t * 2 + 1];
            while (1) {   /* shrink the same transactions into one */
                if ((tt = qq[tt * 2]) < 0) {
                    /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
                    if (counter) *workspace_buf++ = -1;
                    counter = 0;
                    /* END OF MODIFICATIONS */
                    goto END3;
                }
                if (qq[tt * 2 + 1] != v) {
                    /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
                    if (counter) {
                        //printf("t=%d,tt=%d\n",t,-1);
                        //printf("counter=%d\n",counter);
                        *workspace_buf++ = -1;
                    }
                    counter = 0;
                    /* END OF MODIFICATIONS */
                    break;
                }
                Q[t].end += Q[tt].end; /* add multiplicity */
                Q[tt].end = 0;
                /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
                if (counter == 0) shrink_workspace1[t] = workspace_buf;
                counter++;
                *workspace_buf++ = tt;
                /* END OF MODIFICATIONS */
                if (LCM_PROBLEM == LCM_CLOSED) {    /* for closed sets */
                    if (max_item < LCM_Eend) {
                        LCM_trsact_and(Q[t].q + j, Q[tt].q + j, &(Q[t].t));
                        Q[t].t += j;
                    }
                }
            }
        }

    END3:;
        SWAP_PNT(p, pp);
        SWAP_PNT(q, qq);
        SWAP_PNT(jq, jqq);
        SWAP_PNT(jt, jtt);
    }

    for (t = j = 0; t < T->num; t++) {
        if (Q[t].end > 0) {
            if (t != j) Q[j] = Q[t];
            //printf("t=%d,j=%d\n",t,j);
            /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
            // First copy original transactions of the new transaction t to be added
            new_trans_list->ptr[j] = trans_list_buf;
            n_items_cpy = (t == (old_trans_list->siz2 - 1)) ? (old_trans_list->list + old_trans_list->siz1) - old_trans_list->ptr[t] : old_trans_list->ptr[t + 1] - old_trans_list->ptr[t];
            memcpy(trans_list_buf, old_trans_list->ptr[t], sizeof(int) * n_items_cpy);
            trans_list_buf += n_items_cpy;
            // Now copy all original transactions which belong to other transactions which will be merged with current one
            aux_buf = shrink_workspace1[t];
            if (aux_buf) {
                while (*aux_buf != -1) {
                    n_items_cpy = (*aux_buf == (old_trans_list->siz2 - 1)) ? (old_trans_list->list + old_trans_list->siz1) - old_trans_list->ptr[*aux_buf] : old_trans_list->ptr[*aux_buf + 1] - old_trans_list->ptr[*aux_buf];
                    memcpy(trans_list_buf, old_trans_list->ptr[*aux_buf], sizeof(int) * n_items_cpy);
                    trans_list_buf += n_items_cpy;
                    aux_buf++;
                }
            }
            shrink_workspace1[t] = ((int*)0);
            /* END OF MODIFICATIONS */
            j++;
        }
    }
    T->num = j;
    /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
    new_trans_list->siz2 = j;
    /* END OF MODIFICATIONS */
}
#endif
//#include"lcm_io.c"
#ifndef _lcm_io_c_
#define _lcm_io_c_

//#include"fastio.c"
#ifndef FASTIO_C_
#define FASTIO_C_

//#include"lib_e.c"

#define FASTO_SEPARATOR ' '
#define FASTI_BUFSIZ 20000
#define FASTO_BUFSIZ 20000
#define FASTI_REST 256
FILE* FASTI_fp = NULL, * FASTO_fp = NULL;
char* FASTI_buf = NULL;
char* FASTI_flag = NULL;
char* FASTO_buf = NULL, * FASTO_digit = NULL, * FASTO_mag = NULL;
char FASTO_buf2[64], * FASTO_buf2end = FASTO_buf2 + 32;
char* FASTO_p, * FASTO_th, * FASTI_p, * FASTI_bufend, * FASTI_bufend_;
int FASTI_bufsiz, FASTO_mmag, * FASTO_perm;
int FASTI_err;    /* 0:normal, 1:newline, 2:end of file */

/*****************************************************************/
/* initialization of FAST INPUT                                  */
/* open the file "filename" and set FASTI_fp to its file pointer */
/* initialize FASTI_p, FASTI_buf, FASTI_bufsiz                   */
/*****************************************************************/
void FASTI_init(char* filename) {
    malloc2(FASTI_buf, char, FASTI_BUFSIZ, "FASTI_init: FASTI_buf");
    FASTI_bufend = FASTI_buf + FASTI_BUFSIZ;
    FASTI_bufend_ = FASTI_buf + FASTI_BUFSIZ - FASTI_REST;
    FASTI_p = FASTI_bufend;
    fopen2r(FASTI_fp, filename, "FASTI_init");
    malloc2(FASTI_flag, char, 256, "FASTI_init: FASTI_flag");
    int i; for (i = 0; i < 256; i++) FASTI_flag[i] = 127;
    for (i = '0'; i <= '9'; i++) FASTI_flag[i] = i - '0';
    FASTI_flag['\n'] = 126;
}

/*****************************************************************/
/* post-processing of FAST INPUT                                 */
/* close the file pointer and free buffer                        */
/*****************************************************************/
void FASTI_end() {
    fclose(FASTI_fp);
    free2(FASTI_buf);
    free2(FASTI_flag);
}

/*********************************************************************/
/* read a charactor from input-buffer                                */
/* RETURN: an integer                                                */
/* if EOF, set FASTI_err := 2, else not change FASTI_err             */
/* CHANGES: FASTI_p, FASTI_buf, FASTI_bufsiz                         */
/*********************************************************************/
char FASTI_char() {
    if (FASTI_p >= FASTI_bufend) {
        FASTI_p = FASTI_buf;
        FASTI_bufend = FASTI_buf + fread(FASTI_buf, 1, FASTI_BUFSIZ, FASTI_fp);
        if (FASTI_bufend <= FASTI_buf) {
            FASTI_err = 2;
            return (0);
        }
    }
    return (*FASTI_p++);
}


char FASTI_char_() {
    int i = FASTI_bufend - FASTI_p;
    if (FASTI_p >= FASTI_bufend_) {
        if (FASTI_bufend - FASTI_buf < FASTI_BUFSIZ - 1) {
            if (FASTI_p >= FASTI_bufend) {
                FASTI_err = 2;
                return (0);
            }
        }
        else {
            memcpy(FASTI_buf, FASTI_p, i);
            FASTI_p = FASTI_buf;
            FASTI_bufend = FASTI_buf + i + fread(FASTI_buf + i, 1, FASTI_BUFSIZ - i - 1, FASTI_fp);
            FASTI_bufend_ = FASTI_bufend - FASTI_REST;
        }
        *FASTI_bufend = 0;
    }
    return (*FASTI_p++);
}


/*********************************************************************/
/* read an integer from input-buffer                                 */
/*   - can't read real numbers                                       */
/*   - can't read negative number                                    */
/*   - ignore preceeding non-number charactors                       */
/*   - if the following charactor is '\n', backtrack FASTI_p (pointer)
       by one char (at the next execusion, set FASTI_err := 1        */
       /* RETURN: an integer                                                */
       /* FAST_err := 1: newline following, 2:eof(read no integer),
                      3: newline without reading integer
                      not change: otherwise                                 */
                      /* CHANGES: FASTI_p, FASTI_buf, FASTI_bufsiz                         */
                      /*********************************************************************/
int FASTI_int() {
    int item, flag = 1, i;
    char ch;
    do {
        ch = FASTI_char_();
        if (ch == '\n') { FASTI_err = 3; return (0); }
        if (FASTI_err == 2) return (0);

        /*
            i = FASTI_bufend - FASTI_p;
            if ( i < FASTI_REST ){
              if ( FASTI_bufend - FASTI_buf < FASTI_BUFSIZ-1 ){
                if ( FASTI_p >= FASTI_bufend ){
                  FASTI_err = 2;
                  return (0);
                }
              } else {
                memcpy ( FASTI_buf, FASTI_p, i);
                FASTI_p = FASTI_buf;
               FASTI_bufend=FASTI_buf+i+fread(FASTI_buf+i,1,FASTI_BUFSIZ-i-1,FASTI_fp);
              }
              *FASTI_bufend = 0;
            }
            ch = *FASTI_p++;
            if ( ch == '\n' ){ FASTI_err = 3; return (0); }
        */
    } while (FASTI_flag[ch] == 127);

    for (item = (int)(ch - '0'); 1; item = item * 10 + (int)(ch - '0')) {
        ch = FASTI_char();
        if (FASTI_err == 2) return (0);
        if (FASTI_flag[ch] == 127) break;
    }
    if (ch == '\n') FASTI_p--;
    return (item);
}

int FASTI_int_() {
    int item, flag = 1, i;
    char ch;

    do {
        if (FASTI_p >= FASTI_bufend_) {
            if (FASTI_bufend - FASTI_buf < FASTI_BUFSIZ - 1) {
                if (FASTI_p >= FASTI_bufend) {
                    FASTI_err = 2;
                    return (0);
                }
            }
            else {
                i = FASTI_bufend - FASTI_p;
                memcpy(FASTI_buf, FASTI_p, i);
                FASTI_p = FASTI_buf;
                FASTI_bufend = FASTI_buf + i + fread(FASTI_buf + i, 1, FASTI_BUFSIZ - i - 1, FASTI_fp);
                FASTI_bufend_ = FASTI_bufend - FASTI_REST;
            }
            *FASTI_bufend = 0;
        }
        ch = FASTI_flag[*FASTI_p++];
    } while (ch == 127);
    if (ch == 126) { FASTI_err = 3; return (0); }

    for (item = (int)ch; 1; item = item * 10 + (int)ch) {
        ch = FASTI_flag[*FASTI_p++];
        if (ch & 64) break;
    }
    if (ch == 126) FASTI_err = 1;
    return (item);
}



/*****************************************************************/
/* count items and transactions in the given file                */
/* fname: filename */
/* RETURN: counters for items, #transactions                     */
/* set *rows to #rows (!= # of newlines)
       *deg to maximum size of rows
       *eles to #items                                           */
       /*****************************************************************/
ARY FASTI_count(char* filename, int* rows, int* eles, int* deg) {
    ARY E;
    int item, i;
    char ch;

    *rows = 0;           /* # rows */
    *deg = 0;            /* max. size */
    *eles = 0;           /* # elements (items) */
    ARY_init(&E, sizeof(int));
    FASTI_init(filename);

    while (1) {
        while (1) {

            /* read an integer to variable "item" */
            do {
                if (FASTI_p >= FASTI_bufend_) {
                    if (FASTI_bufend - FASTI_buf < FASTI_BUFSIZ - 1) {
                        if (FASTI_p >= FASTI_bufend) {
                            goto END;
                        }
                    }
                    else {
                        i = FASTI_bufend - FASTI_p;
                        memcpy(FASTI_buf, FASTI_p, i);
                        FASTI_p = FASTI_buf;
                        FASTI_bufend = FASTI_buf + i + fread(FASTI_buf + i, 1, FASTI_BUFSIZ - i - 1, FASTI_fp);
                        FASTI_bufend_ = FASTI_bufend - FASTI_REST;
                    }
                    *FASTI_bufend = 0;
                }
                ch = FASTI_flag[*FASTI_p++];
            } while (ch == 127);
            if (ch == 126) { goto END1; }

            for (item = (int)ch; 1; item = item * 10 + (int)ch) {
                ch = FASTI_flag[*FASTI_p++];
                if (ch & 64) break;
            }
            /* end of "read an item" */
            (*eles)++;
            ARY_exp_const(&E, item, 0);
            ((int*)E.h)[item]++;
            if (ch == 126) goto END1;
        }
    END1:;
        (*rows)++;  /* increase #transaction */
    }
END:;
    //  (*deg)++;
    FASTI_end();
    return (E);
}




/*****************************************************************/
/* write an integer to FASTO_buf2                                */
/* INPUT: i:integer to be written                                */
/* RETURN: # digits written                                      */
/* CHANGE: FASTO_buf2                                            */
/*****************************************************************/
char* FASTO_int_buf2(int i) {
    char* p = FASTO_buf2end, k = 0;
    if (i == 0) {
        p--;
        *p = '0';
    }
    else {
        do {
            p--;
            *p = '0' + (i % 10);
            i /= 10;
        } while (i > 0);
    }
    return (p);
}

/*****************************************************************/
/* copy an integer from FASTO_buf2 to *dest                      */
/* INPUT: dest:pointer to the position to be writen,
          p:pointer to the beginning of the digit                */
          /* RETURN: # digits written                                      */
          /* CHANGE: FASTO_buf2                                            */
          /*****************************************************************/
int FASTO_cpy(char* dest, char* p, char* end) {
    while (1) {
        *((int*)dest) = *((int*)p);
        p += sizeof(int);
        if (p >= end) break;
        dest += sizeof(int);
    }
}


/*****************************************************************/
/* initialization of FAST OUTPUT                                 */
/* open the file "filename" and set FASTO_fp to its file pointer */
/* initialize FASTO_p, FASTO_buf                                 */
/* set the initialize FASTO_p, FASTO_buf                         */
/*****************************************************************/
void FASTO_init(char* filename, int end) {
    malloc2(FASTO_buf, char, FASTO_BUFSIZ, "FASTO_init: FASTO_buf");
    fopen2w(FASTO_fp, filename, "FASTO_init");
    FASTO_p = FASTO_buf;
    FASTO_th = FASTO_buf + (FASTO_BUFSIZ / 2);

    int i, k;
    for (FASTO_mmag = 1, i = end; i > 0; FASTO_mmag++, i /= 10);
    malloc2(FASTO_digit, char, FASTO_mmag * end + sizeof(int) * 4, "FASTO_init: FASTO_digit");
    malloc2(FASTO_mag, char, end, "FASTO_init: FASTO_mag");
    char* p, * pnt = FASTO_digit;

    for (i = 0; i < end; i++) {
        p = FASTO_int_buf2(i);
        k = FASTO_buf2end - p;
        FASTO_mag[i] = k + 1;
        FASTO_cpy(pnt, p, FASTO_buf2end);
        *(pnt + k) = FASTO_SEPARATOR;
        pnt += FASTO_mmag;
    }
}


/*****************************************************************/
/* initialization of FAST OUTPUT (permutation version)           */
/* write perm[i] when i is given                                 */
/* open the file "filename" and set FASTO_fp to its file pointer */
/* initialize FASTO_p, FASTO_buf                                 */
/* set the initialize FASTO_p, FASTO_buf                         */
/*****************************************************************/
void FASTO_init_perm(char* filename, int end) {
    malloc2(FASTO_buf, char, FASTO_BUFSIZ, "FASTO_init_perm: FASTO_buf");
    fopen2w(FASTO_fp, filename, "FASTO_init");
    FASTO_p = FASTO_buf;
    FASTO_th = FASTO_buf + (FASTO_BUFSIZ / 2);

    int i, k;
    for (k = i = 0; i < end; i++) if (k < FASTO_perm[i]) k = FASTO_perm[i];
    for (FASTO_mmag = 1; k > 0; FASTO_mmag++, k /= 10);
    malloc2(FASTO_digit, char, FASTO_mmag * end + sizeof(int) * 4, "FASTO_init_perm: FASTO_digit");
    malloc2(FASTO_mag, char, end, "FASTO_init_perm: FASTO_mag");
    char* p, * pnt = FASTO_digit;

    for (i = 0; i < end; i++) {  /* write digits to memory */
        p = FASTO_int_buf2(FASTO_perm[i]);
        k = FASTO_buf2end - p;
        FASTO_mag[i] = k + 1;
        FASTO_cpy(pnt, p, FASTO_buf2end);
        *(pnt + k) = FASTO_SEPARATOR;
        pnt += FASTO_mmag;
    }
}

/*********************************************************************/
/* flush buffer to output file                                       */
/* CHANGE: FASTO_p := FASTO_buf                                      */
/* FASTO_flush_ flushes if wrote buffer size is larger than FASTO_th */
/*********************************************************************/
void FASTO_flush() {
    fwrite(FASTO_buf, 1, ((int)(FASTO_p - FASTO_buf)), FASTO_fp);
    FASTO_p = FASTO_buf;
}
void FASTO_flush_() {
    if (FASTO_p > FASTO_th) FASTO_flush();
}

/*****************************************************************/
/* post-processing of FAST OUTPUT                                */
/* close the file pointer and free buffer                        */
/*****************************************************************/
void FASTO_end() {
    FASTO_flush();
    fclose(FASTO_fp);
    free2(FASTO_buf);
    free2(FASTO_mag);
    free2(FASTO_digit);
}

/*****************************************************************/
/* write a charactor to output-file buffer                       */
/* CHANGE: FASTO_p += 1                                          */
/*****************************************************************/
void FASTO_char(char ch) {
    *FASTO_p = ch;
    FASTO_p++;
}

/*****************************************************************/
/* write an integer to output buffer                             */
/* CHANGE: FASTO_p += FASTO_mag[i]                               */
/*****************************************************************/
void FASTO_int(int i) {
    char* p = &FASTO_digit[i * FASTO_mmag];
    FASTO_cpy(FASTO_p, p, p + FASTO_mag[i]);
    FASTO_p += FASTO_mag[i];
}
void FASTO_int_(int i) {
    long long* j = (long long*)(&FASTO_digit[i * FASTO_mmag]);
    *((long long*)FASTO_p) = *j;
    FASTO_p += FASTO_mag[i];
}
void FASTO_int_large(int i) {
    char* p = FASTO_int_buf2(i);
    int k = FASTO_buf2end - p;
    FASTO_cpy(FASTO_p, p, FASTO_buf2end);
    FASTO_p += k;
    *(FASTO_p) = FASTO_SEPARATOR;
    FASTO_p++;
}

/*****************************************************************/
/* write integers in a QUEUE to output buffer, and flush         */
/* CHANGE: FASTO_p, FASTO_buf                                    */
/* FASTO_QUEUEn:without newline, FASTO_QUEUE:with newline        */
/*****************************************************************/
void FASTO_QUEUEn(QUEUE* Q) {
    int i, e;
    QUEUE_FE_LOOP_(*Q, i, e) FASTO_int(e);
}

void FASTO_QUEUE(QUEUE* Q) {
    int i, e;
    QUEUE_FE_LOOP_(*Q, i, e) FASTO_int(e);
    FASTO_p--;
    FASTO_char('\n');
}

void FASTO_QUEUE_perm(QUEUE* Q, int* perm) {
    int i, e;
    QUEUE_FE_LOOP_(*Q, i, e) FASTO_int(perm[e]);
}

#endif
//#include"lcm_bm.c"
//#include"lcm_var.c"

/* MODIFICATIONS FOR FAST WY ALGORITHIM */
//#include"wy.c"
/* END OF MODIFICATIONS */
//#include"mcrapper.c"
#ifndef _mcrapper_c_
#define _mcrapper_c_

#define REPORT_INTERVAL 9999999
//#define DEBUG_PERF 1
#define USE_PERM_FILTERING 1
//#define CENTRALIZATION 1
//#define USE_PERM_EARLY_STOP 1

/* LIBRARY INCLUDES */


/* CODE DEPENDENCIES */
//#include"time_keeping.c"
#ifndef _time_keeping_c_
#define _time_keeping_c_

/* LIBRARY INCLUDES FOR MEASURING EXECUTION TIME */
//#include <time.h> //Already included in original LCM source code above

/* END OF LIBRARY INCLUDES FOR MEASURING EXECUTION TIME */

/* CODE DEPENDENCIES */
//#include"var_declare.h"

/* GLOBAL VARIABLES (TIME SPENT) */
FILE* timing_file;
double time_LCM_init = 0;
double time_permutations = 0;
double time_initialisation_wy = 0;
double time_threshold_correction = 0;
#ifdef PROFILE_MINING
double time_minpval = 0;
double ticp, tocp;
#endif
double time_termination = 0;
double t_init, t_end;
double tic, toc;

// Measure running time
/*double measureTime() {
    struct rusage t;
    struct timeval tv, ts;
    getrusage(RUSAGE_SELF, &t);
    tv = t.ru_utime;
    ts = t.ru_stime;
    return tv.tv_sec + ts.tv_sec + ((double)tv.tv_usec + (double)ts.tv_usec) * 1e-6;
}*/

// Measure peak memory usage
/*size_t measurePeakMemory() {
    struct rusage t;
    getrusage(RUSAGE_SELF, &t);
    return (size_t)((double)t.ru_maxrss / 1000.0);
}*/

// Display execution time and memory consumption
/*void profileCode() {
    size_t peak_memory;

    fprintf(timing_file, "CODE PROFILING\n");
    fprintf(timing_file, "Total execution time: %f (s).\n", t_end - t_init);
    fprintf(timing_file, "\t Time to initialise LCM: %f (s).\n", time_LCM_init);
    fprintf(timing_file, "\t Time to compute permutations: %f (s).\n", time_permutations);
    fprintf(timing_file, "\t Time to initialise MCRapper cache: %f (s).\n", time_initialisation_wy);
    fprintf(timing_file, "\t Time to compute corrected significance threshold: %f (s).\n", time_threshold_correction);
#ifdef PROFILE_MINING
    fprintf(timing_file, "\t\t Mining time: %f (s).\n", time_threshold_correction - time_minpval);
#else
#endif
    fprintf(timing_file, "\t Time to terminate algorithm: %f (s).\n", time_termination);

    //printf("\t Time to terminate algorithm: %f (s).\n",time_termination);

    //peak_memory = measurePeakMemory();

    //printf("Peak memory consumption: %lld (KB in Linux, B in Mac OS X).\n",peak_memory);

    fprintf(timing_file, "Peak memory consumption: %lld (KB in Linux, B in Mac OS X).\n", peak_memory);
    fprintf(timing_file, "\t Memory consumption due to storing permutation matrix: %f (MB).\n", (((long long)J) * Neff * sizeof(char) + Neff * sizeof(char*)) / ((double)1048576));

    // Close timing file
    fclose(timing_file);
}*/

#endif

//#include"permutation.c"
#define READ_BUF_SIZ 524288 //Size of the buffer to read chars from file
#define STORE_PERMUTATIONS_FILE 0 //Set the flag to 1 if the generated permutions should be written to a file for reuse/debugging
#ifndef _permutation_c_
#define _permutation_c_

int Neff;
int J;
//Random generator seed for reproducibility
time_t seed;
// Original vector of labels (dimension # non-empty transactions)
char* labels;
// Matrix of size J x (# non-empty transactions)
char** labels_perm;
int* n1s;

/* FUNCTION DECLARATIONS */
void get_N_n(char* labels_file) {
    FILE* f_labels;//Stream with file containing class labels
    int n_read;//Number of chars read
    int i;// Iterator variable to be used in loops
    char char_to_int[256];//Array for converting chars to int fast
    char* read_buf, * read_buf_aux, * read_buf_end;//Buffer for reading from file and extra pointers for loops

    // Initialise both counters to 0 (the variables are defined as global variables in wy.c)
    N = 0; n = 0;

    //Try to open file, giving an error message if it fails
    if (!(f_labels = fopen(labels_file, "r"))) {
        fprintf(stderr, "Error in function get_N_n when opening file %s\n", labels_file);
        exit(1);
    }

    //Try to allocate memory for the buffer, giving an error message if it fails
    read_buf = (char*)malloc(READ_BUF_SIZ * sizeof(char));
    if (!read_buf) {
        fprintf(stderr, "Error in function read_labels_file: couldn't allocate memory for array read_buf\n");
        exit(1);
    }

    //Initialize the char to int converter
    for (i = 0; i < 256; i++) char_to_int[i] = 127;
    // We only care about the chars '0' and '1'. Everything else is mapped into the same "bucket"
    char_to_int['0'] = 0; char_to_int['1'] = 1;

    // Read the entire file
    while (1) {
        // Try to read READ_BUF_SIZ chars from the file containing the class labels
        n_read = fread(read_buf, sizeof(char), READ_BUF_SIZ, f_labels);
        // If the number of chars read, n_read_ is smaller than READ_BUF_SIZ, either the file ended
        // or there was an error. Check if it was the latter
        if ((n_read < READ_BUF_SIZ) && !feof(f_labels)) {
            fprintf(stderr, "Error in function read_labels_file while reading the file %s\n", labels_file);
            exit(1);
        }
        // Process the n_read chars read from the file
        for (read_buf_aux = read_buf, read_buf_end = read_buf + n_read; read_buf_aux < read_buf_end; read_buf_aux++) {
            //If the character is anything other than '0' or '1' go to process the next char
            if (char_to_int[*read_buf_aux] == 127) continue;
            N++;
            if (char_to_int[*read_buf_aux]) n++;
        }
        // Check if the file ended,. If yes, then exit the while loop
        if (feof(f_labels)) break;
    }

    //Close the file
    fclose(f_labels);

    //Free allocated memory
    free(read_buf);
}

void read_labels_file(char*);
void randperm(char*, char*, int, FILE*);

/* --------------------------------INITIALIZATION AND TERMINATION FUNCTIONS--------------------------------------- */

//#define USE_ABSOLUTE_VALUE_RADEMACHER 1
void get_N(char* transactions_file) {

    // Initialise both counters to 0 (the variables are defined as global variables in wy.c)
    N = 0; n = 0;
    FILE* f_trans;//Stream with file containing class labels

    //Try to open file, giving an error message if it fails
    if (!(f_trans = fopen(transactions_file, "r"))) {
        fprintf(stderr, "Error in function get_N_n when opening file %s\n", transactions_file);
        exit(1);
    }

    char* read_buf = (char*)malloc(READ_BUF_SIZ * sizeof(char));
    if (!read_buf) {
        fprintf(stderr, "Error in function read_labels_file: couldn't allocate memory for array read_buf\n");
        exit(1);
    }

    while (fgets(read_buf, READ_BUF_SIZ, f_trans) != NULL) {
        N++;
    }

    printf("\nN %d\n", N);

}
// Function to initialise core variables
void permutation_init(int n_perm, char* labels_file, int seed_idx) {
    int i, j; // Iterator variable to be used in loops
    FILE* f_perm = ((FILE*)0);
    char* perm_buffer;
    char* prev_ptr;

    // Obtain number of observations N and number of observations in positive class n
    // from the class labels file
    get_N(labels_file);
    //get_N_n(labels_file);
      //printf("N = %d\n",N);
      //printf("n = %d\n",n);

      // Save core constants as global variables
    J = n_perm;

    // Allocate memory for the vector of labels, giving an error if it fails
    labels = (char*)malloc(N * sizeof(char));
    if (!labels) {
        fprintf(stderr, "Error in function permutation_init: couldn't allocate memory for array labels\n");
        exit(1);
    }

    Neff = root_trans_list.siz1;
    labels_perm = (char**)malloc(Neff * sizeof(char*));
    if (!labels_perm) {
        fprintf(stderr, "Error in function permutation_init: couldn't allocate memory for array labels_perm\n");
        exit(1);
    }
    // Now allocate memory for a contiguous block of J*(# non-empty transactions) chars
    labels_perm[0] = (char*)malloc(((long long)J) * Neff * sizeof(char));
    if (!labels_perm[0]) {
        fprintf(stderr, "Error in function permutation_init: couldn't allocate memory for array labels_perm[0]\n");
        exit(1);
    }
    // And make each row pointer point to the appropriate position (labels_perm[0] is
    // already correctly set)
    for (i = 1; i < Neff; i++) labels_perm[i] = labels_perm[0] + ((long long)i) * J;

    seed = (((unsigned long long)seed_idx) * 31415926535) ^ 271828271828;
    srand(seed);

    if (STORE_PERMUTATIONS_FILE) {
        f_perm = fopen("permutations.csv", "w");
        // Check if file was correctly created, otherwise raise an error
        if (!f_perm) {
            fprintf(stderr, "Error in function permutation_init: file %s couldn't be created\n", "permutations.csv");
            exit(1);
        }
    }

    perm_buffer = (char*)malloc(N * sizeof(char));
    if (!perm_buffer) {
        fprintf(stderr, "Error in function permutation_init: couldn't allocate memory for array perm_buffer\n");
        exit(1);
    }
    n1s = (int*)malloc(J * sizeof(int));
    n = 0;
    for (j = 0; j < J; j++) {
        //randperm(perm_buffer, labels, N, f_perm);
        int n1_ = randlabels(perm_buffer, labels, N, f_perm);
        n = max(n, n1_);
        n1s[j] = n1_;

        for (i = 0; i < Neff; i++) labels_perm[i][j] = perm_buffer[non_empty_trans_idx[i]];
    }
    free(perm_buffer);
    // The array containing the indices of all non-empty transactions is no longer needed
    free(non_empty_trans_idx);

    // Close the file f_perm (if necessary)
    if (f_perm) fclose(f_perm);

    return;
}

// Function that free all allocated memory
void permutation_end() {
    int i;// Iterator variable to be used in loops
    // Free allocated memory for class labels
    free(labels);
    // Free the main memory block for the permuted labels matrix
    free(labels_perm[0]);
    // Free the array of row pointers
    free(labels_perm);
}

void read_labels_file(char* labels_file) {
    FILE* f_labels;//Stream with file containing class labels
    int n_read;//Number of chars read
    int i;// Iterator variable to be used in loops
    char char_to_int[256];//Array for converting chars to int fast
    char* read_buf, * read_buf_aux, * read_buf_end;//Buffer for reading from file and extra pointers for loops
    char* labels_aux = labels;//Auxiliary pointer to array labels for increments

    //Try to open file, giving an error message if it fails
    if (!(f_labels = fopen(labels_file, "r"))) {
        fprintf(stderr, "Error in function read_labels_file when opening file %s\n", labels_file);
        exit(1);
    }

    //Try to allocate memory for the buffer, giving an error message if it fails
    read_buf = (char*)malloc(READ_BUF_SIZ * sizeof(char));
    if (!read_buf) {
        fprintf(stderr, "Error in function read_labels_file: couldn't allocate memory for array read_buf\n");
        exit(1);
    }

    //Initialize the char to int converter
    for (i = 0; i < 256; i++) char_to_int[i] = 127;
    // We only care about the chars '0' and '1'. Everything else is mapped into the same "bucket"
    char_to_int['0'] = 0; char_to_int['1'] = 1;

    // Read the entire file
    while (1) {
        // Try to read READ_BUF_SIZ chars from the file containing the class labels
        n_read = fread(read_buf, sizeof(char), READ_BUF_SIZ, f_labels);
        // If the number of chars read, n_read_ is smaller than READ_BUF_SIZ, either the file ended
        // or there was an error. Check if it was the latter
        if ((n_read < READ_BUF_SIZ) && !feof(f_labels)) {
            fprintf(stderr, "Error in function read_labels_file while reading the file %s\n", labels_file);
            exit(1);
        }
        // Process the n_read chars read from the file
        for (read_buf_aux = read_buf, read_buf_end = read_buf + n_read; read_buf_aux < read_buf_end; read_buf_aux++) {
            //If the character is anything other than '0' or '1' go to process the next char
            if (char_to_int[*read_buf_aux] == 127) continue;
            *labels_aux++ = char_to_int[*read_buf_aux];
        }
        // Check if the file ended,. If yes, then exit the while loop
        if (feof(f_labels)) break;
    }

    //Close the file
    fclose(f_labels);

    //Free allocated memory
    free(read_buf);
}

/* -----------------FUNCTIONS TO SAMPLE RANDOM INTEGERS AND GENERATE RANDOM PERMUTATIONS--------------------------- */

/* Sample a random integer uniformly distributed the range [0,x)
 * Default random number generator samples integers uniformly in the range [0,RAND_MAX)
 * To sample in the range [0,x) with x < RAND_MAX, one can think of sampling an integer
 * rnd from [0,RAND_MAX) and then returning rnd % x. However, this may generate a non-uniform
 * distribution unless RAND_MAX is a multiple of x. To fix that, we combine that basic idea
 * with rejection sampling, rejecting any value rnd greater or equal than RAND_MAX - RAND_MAX *x.
 * This is the same as ensuring that the "effective" RAND_MAX is an exact multiple of x, so that
 * returning rnd % x leads to a uniform sampling scheme in the range [0,x)
 * The seed of the random number generator should have been initialised externally
 * */
static int rand_int(int x) {
    int rnd;
    int limit = RAND_MAX - RAND_MAX % x;

    int test;
    test = 1;
    test++;

    do {
        rnd = rand();
    } while (rnd >= limit);
    return rnd % x;
}

void randperm(char* buffer, char* src, int l, FILE* f_perm) {
    int i, j; // Variables for looping and swapping
    char tmp; // Temp int for swapping
    //Array to store the permutation and temp int for swapping (only needed if f_perm is not NULL)
    int* perm_array, tmp_int;

    // First of all, copy the original array in the buffer
    for (i = 0; i < l; i++) buffer[i] = src[i];

    // If the generated permutation is to be stored in a file, initialise memory for perm_array and int_to_str
    if (f_perm) {
        perm_array = (int*)malloc(l * sizeof(int));
        if (!perm_array) {
            fprintf(stderr, "Error in function randperm: couldn't allocate memory for array perm_array\n");
            exit(1);
        }
        // Initialise indices of the permutation to the identity permutation
        for (i = 0; i < l; i++) perm_array[i] = i;
    }

    // Fisher-Yates algorithm
    for (i = l - 1; i > 0; i--) {
        // Sample a random integer in [0,i]
        j = rand_int(i + 1);
        // Swap dest[j] and dest[i]
        tmp = buffer[j];
        buffer[j] = buffer[i];
        buffer[i] = tmp;
        // If the generated permutation has to be written to the stream f_perm, keep
        // track of the indices as well
        if (f_perm) {
            tmp_int = perm_array[j];
            perm_array[j] = perm_array[i];
            perm_array[i] = tmp_int;
        }
    }
    // If the generated permutation is to be stored in a file, write perm_array to the stream
    if (f_perm) {
        // Write the first l-1 indices with comma as a delimiter
        for (i = 0; i < (l - 1); i++) fprintf(f_perm, "%d,", perm_array[i]);
        // For the last index, change the comma by a newline char
        fprintf(f_perm, "%d\n", perm_array[i]);
        // Free allocated memory
        free(perm_array);
    }
}

int randlabels(char* buffer, char* src, int l, FILE* f_perm) {
    int i, j; // Variables for looping and swapping
    char tmp; // Temp int for swapping
    //Array to store the permutation and temp int for swapping (only needed if f_perm is not NULL)
    int* perm_array, tmp_int;
    int n1_ = 0;

    // First of all, copy the original array in the buffer
    //for(i=0;i<l;i++) buffer[i] = src[i];

    // If the generated permutation is to be stored in a file, initialise memory for perm_array and int_to_str
    if (f_perm) {
        perm_array = (int*)malloc(l * sizeof(int));
        if (!perm_array) {
            fprintf(stderr, "Error in function randperm: couldn't allocate memory for array perm_array\n");
            exit(1);
        }
        // Initialise indices of the permutation to the identity permutation
        for (i = 0; i < l; i++) perm_array[i] = i;
    }

    //fprintf(stdout,"--------\n");
    int total = RAND_MAX;
    int half = 50000;
    for (i = l - 1; i > 0; i--) {
        // Sample a random integer in [0,i]
        j = rand();//zzjzzjzzjzzjzzjzzj rand_int(total);
        //buffer[i] = (j >= half) ? 1 : -1;//((j / half) * 2) - 1;
        buffer[i] = (j >= half) ? 1 : 0;
        n1_ += buffer[i];
        //printf("%d\n",buffer[i]);
        // If the generated permutation has to be written to the stream f_perm, keep
        // track of the indices as well
        if (f_perm) {
            tmp_int = perm_array[j];
            perm_array[j] = perm_array[i];
            perm_array[i] = tmp_int;
        }
    }
    //printf("n1 = %d\n",n1_);
    // If the generated permutation is to be stored in a file, write perm_array to the stream
    if (f_perm) {
        // Write the first l-1 indices with comma as a delimiter
        for (i = 0; i < (l - 1); i++) fprintf(f_perm, "%d,", perm_array[i]);
        // For the last index, change the comma by a newline char
        fprintf(f_perm, "%d\n", perm_array[i]);
        // Free allocated memory
        free(perm_array);
    }

    return n1_;
}

#endif
//#include"transaction_keeping.c"
//#include"lcm_var.c"
//#include"priority_queue.c"
#ifndef _PRI_QUEUE_C_
#define _PRI_QUEUE_C_
typedef struct {
    double priority;
    int data;
} node_t;

typedef struct {
    node_t* nodes;
    int len;
    int size;
} heap_t;

void push(heap_t* h, double priority, int data) {
    if (h->len + 1 >= h->size) {
        h->size = h->size ? h->size * 2 : 4;
        h->nodes = (node_t*)realloc(h->nodes, h->size * sizeof(node_t));
    }
    int i = h->len + 1;
    int j = i / 2;
    while (i > 1 && h->nodes[j].priority < priority) {
        h->nodes[i] = h->nodes[j];
        i = j;
        j = j / 2;
    }
    h->nodes[i].priority = priority;
    h->nodes[i].data = data;
    h->len++;
}

double pop(heap_t* h) {
    int i, j, k;
    if (!h->len) {
        //return NULL;
        return 1.0;
    }
    //char *data = h->nodes[1].data;
    double priority = h->nodes[1].priority;
    //free(h->nodes[1].data);

    h->nodes[1] = h->nodes[h->len];

    h->len--;

    i = 1;
    while (i != h->len + 1) {
        k = h->len + 1;
        j = 2 * i;
        if (j <= h->len && h->nodes[j].priority > h->nodes[k].priority) {
            k = j;
        }
        if (j + 1 <= h->len && h->nodes[j + 1].priority > h->nodes[k].priority) {
            k = j + 1;
        }
        h->nodes[i] = h->nodes[k];
        i = k;
    }
    //return data;
    return priority;
}

double top(heap_t* h) {
    if (!h->len) {
        //return NULL;
        return 1.0;
    }
    return h->nodes[1].priority;
}

int top_value(heap_t* h) {
    if (!h->len) {
        //return NULL;
        return -1;
    }
    return h->nodes[1].data;
}
#endif
/* CONSTANT DEFINES */

//#define min(a,b) (a < b) ? a : b
//#define max(a,b) (a > b) ? a : b

int min_integer(int a, int b) {
    return (a < b) ? a : b;
}

int max_integer(int a, int b) {
    return (a > b) ? a : b;
}

double min_double(double a, double b) {
    return (a < b) ? a : b;
}

double max_double(double a, double b) {
    return (a > b) ? a : b;
}


/* GLOBAL VARIABLES */
FILE* results_file, * minpvals_file, * reports_file, * minsupp_file, * tfp_file;
// Number of samples, N
int N, N_over_2; // consider remove N_over_2
// Number of positive rademacher r.v.
int n; // consider remove
double delta;
double max_pattern_freq;
double max_variance;
double dev_lower_bound;
double approximation_ratio;
double maximum_epsilon;
// maximum deviations for each permutation
double* maxdev;
int* permutations_to_process;
int minimum_deviation_index;
int minimum_deviation;
double avg_rad;
double avg_rad_hyb;
double epsilon_lb;

// store statistics
unsigned long explored_itemsets;
unsigned long patterns_above_topk;
int last_support;
int* supports;
double start_instant;
int last_explored_report;
int tested;

double union_bound_term;
double theta;

// top-k strategy
int K;
heap_t* topk_queue;

// bounds using last tested pattern
int last_precomputation;
int last_processed_support;
int last_processed_as;
int last_processed_max_dev;
int last_processed_min_dev;
int* last_processed_transactions;
int* temp_transaction_list;
double WY_time;
int update_minimum;
// Cell-count counter
int* a_cnt;
int below_delta;
long bound1;
long bound2;
long improved_estimate;
int improved;




void compute_rade_estimate(int k_) {
    int j = 0;
    avg_rad = 0.0;
    double min_dev_value = 0.0;
    if (dev_lower_bound > 0.0) {
        min_dev_value = (double)LCM_th - 1;
    }
    int min_J_k = min_integer((int)J, k_);
    for (j = 0; j < min_J_k; j++) {
        avg_rad += max_double(maxdev[j], min_dev_value);
    }
    avg_rad = avg_rad / (double)(min_J_k);
    avg_rad = avg_rad / (double)N;

    // performs centralization
    double dev_labels = 0;
    for (j = 0; j < min_J_k; j++) {
        dev_labels += 2 * n1s[j] - N;
    }
    dev_labels = dev_labels / (double)(min_J_k);
    dev_labels = dev_labels / (double)N;

    avg_rad = avg_rad + dev_labels;
    avg_rad = max_double(avg_rad, 0.0);
}

// Theorem 4.5
void compute_rade_hybrid_estimate(int k_) {

    double sample_size = (double)N;
    double perms_ = (double)J;
    double low_freq_bound = sqrt((2. * theta * (log(perms_) + union_bound_term)) / sample_size);
    low_freq_bound = low_freq_bound * (double)N;

    int j = 0;
    avg_rad_hyb = 0.0;
    double min_dev_value = low_freq_bound;
    int min_J_k = min_integer((int)J, k_);
    for (j = 0; j < min_J_k; j++) {
        avg_rad_hyb += max_double(maxdev[j], min_dev_value);
    }
    avg_rad_hyb = avg_rad_hyb / (double)(min_J_k);
    avg_rad_hyb = avg_rad_hyb / (double)N;

    // performs centralization
    double dev_labels = 0;
    for (j = 0; j < min_J_k; j++) {
        dev_labels += 2 * n1s[j] - N;
    }
    dev_labels = dev_labels / (double)(min_J_k);
    dev_labels = dev_labels / (double)N;

    avg_rad_hyb = avg_rad_hyb + dev_labels;
    avg_rad_hyb = max_double(avg_rad_hyb, 0.0);

}

// Theorem 4.6
double tail_bound_1(double estimated_rademacher) {
    double sample_size = (double)N;
    double epsilon_ = 2. * estimated_rademacher + 3.0 * sqrt(log(2.0 / delta) / (2.0 * sample_size));
    return epsilon_;
}

double compute_epsilon_1() {
    compute_rade_estimate(1);
    double epsilon_ = tail_bound_1(avg_rad);
    return epsilon_;
}

// Theorem 3.1
double sbf_tail_bound(double estimated_rademacher) {
    double sample_size = (double)N;
    double perms_ = (double)J;
    double z = 0.5;
    double empirical_rademacher = estimated_rademacher + 2.0 * z * sqrt(log(4.0 / delta) / (2.0 * sample_size * perms_));
    double tail_term = sqrt(log(4.0 / delta) * (4.0 * sample_size * empirical_rademacher + log(4.0 / delta))) / sample_size;
    tail_term += log(4.0 / delta) / sample_size;
    tail_term += sqrt(log(4.0 / delta) / (2. * sample_size));
    double epsilon_ = 2. * empirical_rademacher + tail_term;
    return epsilon_;
}

double compute_epsilon_sbf() {
    compute_rade_estimate(J);
    double epsilon_ = sbf_tail_bound(avg_rad);
    return epsilon_;
}

double compute_epsilon_sbf_hyb() {
    compute_rade_hybrid_estimate(J);
    double epsilon_ = sbf_tail_bound(avg_rad_hyb);
    return epsilon_;
}

double compute_epsilon_sbf_hyb_1() {
    compute_rade_hybrid_estimate(1);
    double epsilon_ = tail_bound_1(avg_rad_hyb);
    return epsilon_;
}

// Theorem 3.2
double compute_epsilon_sbf_var() {
    compute_rade_estimate(J);
    double sample_size = (double)N;
    double perms_ = (double)J;
    double z = 0.5;
    double log_d = log(4.0 / delta);
    double empirical_rademacher = avg_rad + 2.0 * z * sqrt(log_d / (2.0 * sample_size * perms_));
    empirical_rademacher += (sqrt((4. * sample_size * empirical_rademacher + log_d) * log_d) + log_d) / (2.0 * sample_size);
    double epsilon_ = 2.0 * empirical_rademacher;
    epsilon_ += sqrt(2.0 * log_d * (8.0 * empirical_rademacher + max_variance) / sample_size);
    epsilon_ += 2.0 * log_d / (3.0 * sample_size);
    return epsilon_;
}

double era_tail(double delta, double sample_size) {
    double z = 0.5;
    double perms_ = (double)J;
    double log_d = log(4.0 / delta);
    return 2.0 * z * sqrt(log_d / (2.0 * sample_size * perms_));
}

struct bounds_info {
    int frequency;
    //int as;
    int max_as;
    /*int max_as_j;
    int min_as;
    int max_dev;*/
};

void init_bounds(struct bounds_info* current_) {
    current_->frequency = 0;
    //current_->as = 0;
    current_->max_as = 0;
}

void reset_bounds(struct bounds_info* current_) {
    //printf("Call reset_bounds %d , %d\n",current_->frequency,n);
    current_->max_as = current_->frequency;
}


/* FUNCTION DECLARATIONS */
int doublecomp(const void*, const void*);

double get_cpu_time() {
    return (double)clock() / CLOCKS_PER_SEC;
}

void start_measuring_time() {
    start_instant = get_cpu_time();
}

void print_debug_report() {
    printf("NEW REPORT:\n");
    printf("  sigma %d, est_rade %f, epsilon_lb %f\n", LCM_th, avg_rad, epsilon_lb);
    double epsilon = compute_epsilon_sbf();
    printf("  epsilon %f, LCM_th/N %f, est_rade*N %d, eps*N %d\n", epsilon, (double)LCM_th / (double)N, (int)(avg_rad * (double)N), (int)(epsilon * (double)N));
    printf("  explored patterns: %lu\n", explored_itemsets);
    printf("  current tested patterns: %d\n", tested);
    printf("  tested ratio: %f\n", ((double)tested / (double)explored_itemsets));
    printf("  improved_estimate: %ld\n", improved_estimate);
    printf("  improved ratio: %f\n", ((double)improved_estimate / (double)explored_itemsets));
    printf("  elapsed:%f\n", (get_cpu_time() - start_instant));
    last_explored_report = tested;
}


void update_minsupp() {

    minimum_deviation = N;
    int j = 0;
    double new_thr = N;
    double thr_temp = 0.0;
    for (j = 0; j < J; j++) {
        minimum_deviation = min_double(minimum_deviation, maxdev[j]);
    }
    new_thr = minimum_deviation + 1;

    if (approximation_ratio > 1.) {
        new_thr = new_thr * approximation_ratio;
    }

    double epsilon = 0.0;
    if (LCM_th < new_thr) {
        LCM_th = new_thr;
        epsilon = compute_epsilon_sbf();
        double tail_term = era_tail(delta, (double)N);
        printf("*  sigma %d, min_dev %d, n1min = %d, est_rade %f, tail_era %f, epsilon %f\n", LCM_th, minimum_deviation, n1s[minimum_deviation_index], avg_rad, tail_term, epsilon);
        printf("   epsilon_lb %f, LCM_th/N %f, est_rade*N %d, eps*N %d\n", epsilon_lb, (double)LCM_th / (double)N, (int)(avg_rad * (double)N), (int)(epsilon * (double)N));
        printf("   explored patterns: %lu, ", explored_itemsets);
        printf("current tested patterns: %d, ", tested);
        printf("tested ratio: %f\n", ((double)tested / (double)explored_itemsets));
    }
    if (epsilon > 0.0 && epsilon > maximum_epsilon) {
        LCM_th = N + 1;
    }

}
/* -------------------------------- INITIALISATION AND TERMINATION FUNCTIONS ----------------------------------------- */

/* Initialise MCRapper
 * Input arguments are self-explanatory
 * */
void mcrapper_init(double target_fwer, int k_, double max_eps_) {
    int j; //Loop variable

    delta = target_fwer;
    avg_rad = 0.0;
    avg_rad_hyb = 0.0;

    // Allocate memory for maximum deviations, raising error if it fails
    maxdev = (double*)malloc(J * sizeof(double));
    if (!maxdev) {
        fprintf(stderr, "Error in function mcrapper_init: couldn't allocate memory for array maxdev\n");
        exit(1);
    }
    // Array to store the indexes of the permutations to process
    permutations_to_process = (int*)malloc(J * sizeof(int));
    if (!permutations_to_process) {
        fprintf(stderr, "Error in function mcrapper_init: couldn't allocate memory for array permutations_to_process\n");
        exit(1);
    }
    // Allocate memory for cell counts, raising an error if it fails
    a_cnt = (int*)malloc(J * sizeof(int));
    if (!a_cnt) {
        fprintf(stderr, "Error in function mcrapper_init: couldn't allocate memory for array a_cnt\n");
        exit(1);
    }
    supports = (int*)malloc((N + 1) * sizeof(int));
    if (!supports) {
        fprintf(stderr, "Error in function mcrapper_init: couldn't allocate memory for array supports\n");
        exit(1);
    }

    // Initialize counts
    for (j = 0; j < J; j++) {
        a_cnt[j] = 0;
    }
    // Initialise all deviations
    double dev_lower_bound_supp = dev_lower_bound * N;
    for (j = 0; j < J; j++) {
        if (max_pattern_freq == 1.0) {
            maxdev[j] = max_integer(0, 2 * n1s[j] - N);
        }
        else {
            maxdev[j] = 0;
        }
        maxdev[j] = max_integer(maxdev[j], dev_lower_bound_supp);
    }
    // initialize support counts
    for (j = 0; j <= N; j++) {
        supports[j] = 0;
    }

    minimum_deviation_index = 0;
    minimum_deviation = 0;
    below_delta = 0;
    explored_itemsets = 0;
    patterns_above_topk = 0;
    last_support = 0;
    last_explored_report = 0;

    K = k_;
    maximum_epsilon = max_eps_;
    epsilon_lb = compute_epsilon_sbf();
    if (maximum_epsilon < 1.0) {
        printf("maximum_epsilon %f\n", maximum_epsilon);
        double maximum_rademacher = (maximum_epsilon - epsilon_lb) / 2.0;
        printf("maximum value of rademacher %f\n", maximum_rademacher);
        int dev_upper_bound = (int)(maximum_rademacher * (double)N) - 1;
        if (dev_upper_bound > 0 && dev_upper_bound > LCM_th) {
            LCM_th = dev_upper_bound;
        }
    }

    reports_file = fopen("reports.txt", "w");
    minsupp_file = fopen("minsupp.txt", "w");
    last_processed_transactions = (int*)malloc((N + 1) * sizeof(int));
    temp_transaction_list = (int*)malloc((N + 1) * sizeof(int));
    topk_queue = (heap_t*)calloc(1, sizeof(heap_t));
    //printf("size of queue: %d\n", topk_queue->len);
    //push(topk_queue, 1.0, 0);
    //pop(topk_queue);
    //printf("size of queue: %d\n", topk_queue->len);
    last_precomputation = -1; last_processed_support = 0;
    last_processed_as = 0; last_processed_max_dev = 0; last_processed_min_dev = 0;
    tested = 0; WY_time = 0.0; bound1 = 0; bound2 = 0; improved_estimate = 0;

    update_minsupp();
    print_debug_report();

}


/* Free all allocated memory and give some output for debugging purposes */
void mcrapper_end() {
    int j, idx_max;

    int min_dev = N;
    int max_dev = 0;
    for (j = 0; j < J; j++) {
        min_dev = min_double(min_dev, maxdev[j]);
        max_dev = max_double(max_dev, maxdev[j]);
    }

    compute_rade_estimate(1);

    if (J == 1) {
        fprintf(results_file, "%f\n", compute_epsilon_1());
    }
    if (J > 1) {
        fprintf(results_file, "%f\n", compute_epsilon_sbf());
    }

    printf("\n\n");

    double tail_term = era_tail(delta, (double)N);

    printf("Estimated Rademacher: %f\n", avg_rad);
    printf("Estimated hyb Rademacher: %f\n", avg_rad_hyb);
    printf("tail term %f , era %f\n", tail_term, tail_term + avg_rad);
    printf("Min dev: %d , %f\n", min_dev, (double)min_dev / (2. * (double)N));
    printf("Max dev: %d , %f\n", max_dev, (double)max_dev / (2. * (double)N));
    printf("Eps lower bound (using standard bounds) %f\n", epsilon_lb);
    printf("(2*rade estimate with no tail bound) %f\n", 2. * avg_rad);
    printf("Epsilon (n=1) %f\n", compute_epsilon_1());
    printf("Epsilon (SBF bound) %f\n", compute_epsilon_sbf());
    printf("Epsilon (Var bound) %f\n", compute_epsilon_sbf_var());
    printf("Epsilon (Hyb bound) %f\n", compute_epsilon_sbf_hyb());
    printf("Epsilon (Hyb bound n=1) %f\n", compute_epsilon_sbf_hyb_1());
    printf("Final LCM support: %d\n", LCM_th);
    printf("Number of explored itemsets: %lu\n", explored_itemsets);
    printf("Number of tested itemsets: %d\n", tested);
    printf("improved_estimate: %ld\n", improved_estimate);
    printf("improved ratio: %f\n", ((double)improved_estimate / (double)explored_itemsets));
    printf("bound1: %ld\n", bound1);
    printf("bound2: %ld\n", bound2);
    printf("Runtime for correction (s): %f\n", (get_cpu_time() - start_instant));
    printf("Runtime for WY computations (s): %d\n", (int)WY_time);
    //printf("Peak Memory (MB): %d\n", (int)measurePeakMemory());

    // Report the seed for reproducibility
    fprintf(minpvals_file, "\nRANDOM SEED USED FOR KEY GENERATION\n");
    fprintf(minpvals_file, "\t Seed = %u\n", (unsigned)seed);

    // Free allocated memory
    free(maxdev);
    free(permutations_to_process);
    free(a_cnt);
    free(supports);

    free(topk_queue);
    free(last_processed_transactions);
    free(temp_transaction_list);

    // Close files
    fclose(results_file); fclose(minpvals_file);
}

// debug functions printing the deviations
void print_deviations() {
    int j = 0;
    for (j = 0; j < J; j++) {
        printf("%d,", (int)maxdev[j]);
    }
    printf("\n");
}

// update the frequency threshold for the search




int count_common_transactions(int* current_transaction_list, int current_support) {
    int common_transactions = 0;
    int i = 0; int j = 0;
    int cond = 0;
    // count how many transactions are in common between last and current
    while (i < current_support && j < last_processed_support) {
        cond = current_transaction_list[i] == last_processed_transactions[j];
        i = (cond) ? i + 1 : i;
        j = (cond) ? j + 1 : j;
        common_transactions = (cond) ? common_transactions + 1 : common_transactions;
        cond = current_transaction_list[i] > last_processed_transactions[j];
        j = (cond) ? j + 1 : j;
        i = (cond) ? i : i + 1;
    }
    return common_transactions;
}





void process_permutations(struct bounds_info* current_info, int* current_transaction_list, struct bounds_info* parent_info) {
    // process the rademacher variables for the current pattern
    //printf("Processing permutations of pattern with support %d\n",current_info->frequency);

    int x = current_info->frequency;
    int i, j;
    char* labels_perm_aux; //Auxiliary pointer
    int curr_max_as = (current_info->max_as < x) ? current_info->max_as : x;//min(current_info->max_as , x);


#ifdef USE_PERM_FILTERING
    i = 0;
    for (j = 0; j < J; j++) {
        int current_bound = (curr_max_as < n1s[j]) ? curr_max_as : n1s[j];//min(curr_max_as , n1s[j]);
        if (current_bound > maxdev[j]) {
            permutations_to_process[i] = j;
            i++;
        }
    }
    int permutations_to_process_length = i;

    if (permutations_to_process_length > 0) {
        if ((double)permutations_to_process_length / (double)J < 0.7) {
            int current_bound;
            int perm_idx;
#ifdef DEBUG_PERF
            printf("processing labels\n");
#endif
            for (i = 0; i < x; i++) {
#ifdef DEBUG_PERF
                printf("    current_transaction_list[i] %d", current_transaction_list[i]);
#endif
                labels_perm_aux = labels_perm[current_transaction_list[i]];//Avoid recomputing labels_perm[current_trans.list[i]] all the time
                for (j = 0; j < permutations_to_process_length; j++) {
                    perm_idx = permutations_to_process[j];
                    a_cnt[perm_idx] += labels_perm_aux[perm_idx];

#ifdef USE_PERM_EARLY_STOP
                    if ((i + 1) % 10 == 0) { // don't check too often
                        current_bound = 2 * (a_cnt[permutations_to_process[j]] + min_integer(curr_max_as, x - (i + 1))) - x;
                        if (current_bound <= maxdev[j]) {
                            // remove current permutation from further consideration
                            permutations_to_process[j] = permutations_to_process[permutations_to_process_length - 1];
                            permutations_to_process_length--;
                        }
                    }
#endif

                }
            }
        }
        else {
            for (i = 0; i < x; i++) {
                labels_perm_aux = labels_perm[current_transaction_list[i]];//Avoid recomputing labels_perm[current_trans.list[i]] all the time
                for (j = 0; j < J; j++) {
                    a_cnt[j] += labels_perm_aux[j];
                }
            }
        }
    }
#endif
#ifndef USE_PERM_FILTERING
    // standard loop to update values of a_cnt
    for (i = 0; i < x; i++) {
        labels_perm_aux = labels_perm[current_transaction_list[i]];//Avoid recomputing labels_perm[current_trans.list[i]] all the time
        for (j = 0; j < J; j++) {
            a_cnt[j] += labels_perm_aux[j];
        }
    }
#endif

    // the current will be the new last processed pattern
#ifdef ENABLE_LAST_TESTED_BOUNDS
    for (i = 0; i < x; i++) { last_processed_transactions[i] = current_transaction_list[i]; }
#endif
    last_processed_support = x;
    last_processed_min_dev = x;
    last_processed_max_dev = 0;

    update_minimum = 0;
    improved = 0;
    int any_above = 0;
    int max_dev_above = 0;
    int current_deviation = 0;
    int current_dev_compl = 0;
    int max_j_index = 0;
    int max_dev = N;
    int current_bound;
    curr_max_as = 0;

    for (j = 0; j < J; j++) {
        current_deviation = 2 * a_cnt[j] - x;
        curr_max_as = (curr_max_as < a_cnt[j]) ? a_cnt[j] : curr_max_as;
        improved += (current_deviation > maxdev[j]);
        maxdev[j] = (current_deviation > maxdev[j]) ? current_deviation : maxdev[j];
        a_cnt[j] = 0;
    }
    update_minimum = (improved > 0);
    improved_estimate += (improved > 0);
    current_info->max_as = curr_max_as;

}

#define ENABLE_BOUNDS 1
//#define ENABLE_LAST_TESTED_BOUNDS 1

int current_pattern_is_testworthy(struct bounds_info* parent_info, struct bounds_info* current_info, int* current_transaction_list) {

    // don't use bounds, always process the pattern
#ifndef ENABLE_BOUNDS
    return 0;
#endif

    int to_ret = 0;
    int j;
    int any_above = 0;
    int x = current_info->frequency;
    int current_max_as = (current_info->max_as < x) ? current_info->max_as : x;
    int max_as_j_;
    int upp_bound_dev_j = 0;
    int max_bound_dev_j = 0;
#ifdef DEBUG_PERF
    fflush(stdout);
    printf("untest check: x %d , max_as %d\n", x, current_max_as);
#endif
    for (j = 0; j < J; j++) {
        max_as_j_ = (current_max_as < n1s[j]) ? current_max_as : n1s[j];
        upp_bound_dev_j = 2 * max_as_j_ - x;
        any_above += (upp_bound_dev_j > maxdev[j]);
#ifdef DEBUG_PERF
        max_bound_dev_j = max_integer(max_bound_dev_j, upp_bound_dev_j);
        printf("   j %d , maxdev[j] %f , n1[j] %d , max_as_j %d , upp_bound_dev_j %d \n", j, maxdev[j], n1s[j], max_as_j_, upp_bound_dev_j);
#endif
    }
    if (any_above == 0) {
        to_ret = 1;
        bound2++;
    }
#ifdef DEBUG_PERF
    printf("   any_above %d , max_bound_dev_j %d , toret %d\n", any_above, max_bound_dev_j, to_ret);
    fflush(stdout);
#endif

    // compute a bound on the current pattern using the last processed pattern
    // possibly broken , to be fixed
#ifdef ENABLE_LAST_TESTED_BOUNDS
//if (current_transaction_list && ( ( last_processed_max_dev + (current_info->frequency - count_common_transactions(current_transaction_list , current_info->frequency))) < LCM_th ) )
//  return 1;
#endif

    return to_ret;

}

/* Process a solution involving the bitmap represented itemsets */
// x = frequency (i.e. number of occurrences) of newly found solution
void bm_process_solution(int x, int item, int* mask, struct bounds_info* parent_info, struct bounds_info* current_info) {
    //printf("bm_process_solution: supp %d\n",x);
    //printf("  current tested patterns:%d\n",tested);
    int i, j;//Loop iterators

    if (max_pattern_freq == 0.0) {
        fprintf(tfp_file, "%d - %d\n", item, x);
    }

    //double temp_time_ = get_cpu_time();

    if (parent_info->frequency <= 0) {
        parent_info->frequency = N;
        parent_info->max_as = N;
    }
    current_info->max_as = (x <= parent_info->max_as) ? x : parent_info->max_as;//min(x , parent_info->max_as);
    current_info->frequency = x;

    if (x != current_info->frequency) {
        printf("problem in bm_process_solution: supp %d, current supp %d\n", x, current_info->frequency);
    }
    if (x < N && x >= parent_info->frequency) {
        printf("problem in bm_process_solution: supp %d, parent supp %d\n", x, parent_info->frequency);
    }

    ++explored_itemsets;
    ++supports[x];

    last_support = x;

    // Sanity-check
    if (x != current_trans.siz) printf("Error: x = %d, current_trans.siz=%d\n", x, current_trans.siz);

    if (((double)x) / ((double)N) > max_pattern_freq) return;

    if (current_pattern_is_testworthy(parent_info, current_info, current_trans.list)) return;




    ++tested;

    process_permutations(current_info, current_trans.list, parent_info);

    /* Finally, check if the minimum constraint is still satisfied, if not compute it again */
    if (update_minimum == 1) {
        update_minsupp();
        // Correct possible corruption of LCM data structures due to unexpected change in minimum support
        for (i = 0; i < item; i++) {
            //printf("Item %d, Frq %d, Current_th %d\n",i,LCM_Ofrq[i],LCM_th);
            if (LCM_Ofrq[i] == (LCM_th - 1)) {
                //printf("Bucket of item %d corrupted after TH change! Parent %d. Current Th%d.\n",i,item,LCM_th);
                LCM_BM_occurrence_delete(i);
                *mask &= ~BITMASK_1[i];
                //printf("Problem fixed!\n");
            }
        }
    }


    if (tested - last_explored_report > REPORT_INTERVAL) {
        print_debug_report();
    }


}

/* Process a solution involving the most frequent item (item 0) */
// x = frequency (i.e. number of occurrences) of newly found solution
void process_solution0(int x, struct bounds_info* parent_info, struct bounds_info* current_info) {
    //printf("process_solution0: supp %d\n",x);
    //printf("  current tested patterns:%d\n",tested);
    int i, j;//Loop iterators

    if (max_pattern_freq == 0.0) {
        fprintf(tfp_file, "%d - %d\n", 0, x);
    }

    if (parent_info->frequency <= 0) {
        parent_info->frequency = N;
        parent_info->max_as = N;
    }
    current_info->max_as = (x <= parent_info->max_as) ? x : parent_info->max_as;//min(x , parent_info->max_as);
    current_info->frequency = x;

    if (x != current_info->frequency) {
        printf("problem in bm_process_solution: supp %d, current supp %d\n", x, current_info->frequency);
    }
    if (x < N && x >= parent_info->frequency) {
        printf("problem in bm_process_solution: supp %d, parent supp %d\n", x, parent_info->frequency);
    }

    ++explored_itemsets;
    ++supports[x];

    last_support = x;

    // Sanity-check
    if (x != bm_trans_list[1].siz) printf("Error: x = %d, bm_trans_list[1].siz=%d\n", x, bm_trans_list[1].siz);

    if (((double)x) / ((double)N) > max_pattern_freq) return;

    if (current_pattern_is_testworthy(parent_info, current_info, bm_trans_list[1].list)) return;



    ++tested;

    process_permutations(current_info, bm_trans_list[1].list, parent_info);
    /* Finally, check if the minimum constraint is still satisfied, if not compute it again */
    if (update_minimum == 1) {
        update_minsupp();
    }



    if (tested - last_explored_report > REPORT_INTERVAL) {
        print_debug_report();
    }

}

/* Process a solution involving the array-list represented itemsets */
// x = frequency (i.e. number of occurrences) of newly found solution
// L = pointer to TRANS_LIST struct keeping track of merged transactions
// item = current node of the tree
void ary_process_solution(int x, TRANS_LIST* L, int item, int* mask, struct bounds_info* parent_info, struct bounds_info* current_info) {
    //printf("ary_process_solution: supp %d\n",x);
    //printf("  current tested patterns:%d\n",tested);
    int i, j;//Loop iterator
    int aux; //Auxiliary counter
    int* t, * t_end, * ptr, * end_ptr; //Pointers for iterating on transaction list

    //double temp_time_ = get_cpu_time();

    if (max_pattern_freq == 0.0) {
        fprintf(tfp_file, "%d - %d\n", item, x);
    }

    if (parent_info->frequency <= 0) {
        parent_info->frequency = N;
        parent_info->max_as = N;
    }
    current_info->max_as = (x <= parent_info->max_as) ? x : parent_info->max_as;//min(x , parent_info->max_as);
    current_info->frequency = x;

    if (x != current_info->frequency) {
        printf("problem in bm_process_solution: supp %d, current supp %d\n", x, current_info->frequency);
    }
    if (x < N && x >= parent_info->frequency) {
        printf("problem in bm_process_solution: supp %d, parent supp %d\n", x, parent_info->frequency);
    }

    ++explored_itemsets;
    ++supports[x];

    last_support = x;


    if (current_pattern_is_testworthy(parent_info, current_info, NULL)) return;



    // Sanity-check (this one is more complicated due to the way the transactions are stored)
    aux = 0;
    for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
        end_ptr = (*t == (L->siz2 - 1)) ? L->list + L->siz1 : L->ptr[*t + 1];
        for (ptr = L->ptr[*t]; ptr < end_ptr; ptr++) aux++;
    }
    if (x != aux) printf("Error: x = %d, trans_size=%d\n", x, aux);


    j = 0;
    for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
        end_ptr = (*t == (L->siz2 - 1)) ? L->list + L->siz1 : L->ptr[*t + 1];
        for (ptr = L->ptr[*t]; ptr < end_ptr; ptr++) {
            temp_transaction_list[j] = *ptr;
            ++j;
        }
    }

    if (((double)x) / ((double)N) > max_pattern_freq) return;

#ifdef ENABLE_LAST_TESTED_BOUNDS
    if (current_pattern_is_testworthy(parent_info, current_info, temp_transaction_list)) return;
#endif

    ++tested;

    process_permutations(current_info, temp_transaction_list, parent_info);
    /* Finally, check if the minimum constraint is still satisfied, if not compute it again */
    if (update_minimum == 1) {
        update_minsupp();
        // Correct possible corruption of LCM data structures due to unexpected change in minimum support
        for (j = 0; j < LCM_BM_MAXITEM; j++) {
            //printf("Item %d, Frq %d, Current_th %d\n",j,LCM_Ofrq[j],LCM_th);
            if (LCM_Ofrq[j] == (LCM_th - 1)) {
                //printf("Bucket of item %d corrupted after TH change! Parent %d. Current Th%d.\n",j,item,LCM_th);
                LCM_BM_occurrence_delete(j);
                *mask &= ~BITMASK_1[j];
                //printf("Problem fixed!\n");
            }
        }
    }



    if (tested - last_explored_report > REPORT_INTERVAL) {
        print_debug_report();
    }


}

/* AUXILIARY FUNCTIONS */
// Comparison function used by quicksort implementation in C
int doublecomp(const void* elem1, const void* elem2) {
    if (*(const double*)elem1 < *(const double*)elem2)
        return -1;
    return *(const double*)elem1 > * (const double*)elem2;
}

#endif
/**************************************************************/
/* load transaction database from file                        */
/* INPUT: filename:filename, th:minimum support               */
/* RETURN: sum of #items over all transaction                 */
/* set LCM_Trsact to the transactions loaded from file        */
/*     FASTO_perm to permutation of items ( sorted by frq )   */
/* set LCM_Eend to #frq items (maximum index of item +1 )     */
/**************************************************************/
int LCM_BM_load(char* filename) {
    int e, i, bnum, item, transaction_num, m, zz; /* max item, sum of #items */
    QUEUE_INT* ibuf, * b;  /* buffer for storing all items */
    char ch;
    /* first pass of input file. compute the frequency of each item,
       and compute the re-numbers of items in the file.
       the re-numbered number of infrequent items are set to -1 */
    ARY E = FASTI_count(filename, &LCM_trsact_num, &bnum, &m);
    if (LCM_print_flag & 2)
        printf("database: #transactions=%d, #item=%d #elements=%d\n", LCM_trsact_num, E.num, bnum);
    int* Eq = E.h;
    FASTO_perm = TRSACT_sort_item_by_frq(&E, LCM_th, &bnum, &LCM_Eend);

    /* compute adequite value for LCM_BM_MAXITEM
       (working space is not larger than transaction database */
    for (item = 0, bnum = 0; item < LCM_Eend; item++)
        bnum += Eq[FASTO_perm[item]];
    //  if ( LCM_print_flag &2 ) printf ("Memory(#int): Original %d ", bnum*2 );
    long long z = -1, mm = LCM_PROBLEM == LCM_FREQSET ? 2 : 5;
    for (item = 0; item < (MIN(LCM_Eend, 32)); item++) {
        if (mm + bnum * 2 < z || z == -1) {
            z = mm + bnum * 2;
            zz = item + 1;
        }
        bnum -= Eq[FASTO_perm[item]];
        mm *= 2;
    }
    LCM_BM_MAXITEM = MAX(zz, 12);
    /* MODIFICATIONS FOR TRANSACTION KEEPING */
    bitmap_item_frq = (int*)malloc(LCM_BM_MAXITEM * sizeof(int));
    if (!bitmap_item_frq) {
        fprintf(stderr, "Error in function LCM_BM_load: couldn't allocate memory for array bitmap_item_frq\n");
        exit(1);
    }
    for (i = 0; i < LCM_BM_MAXITEM; i++)	bitmap_item_frq[i] = Eq[FASTO_perm[i]];
    BM_TRANS_LIST_INIT(LCM_BM_MAXITEM);
    /* END OF MODIFICATIONS */
    if (LCM_print_flag & 2)
        printf("Reduced %d, #items in BitMap= %d %d\n", z * 2, LCM_BM_MAXITEM);
    for (bnum = item = 0; item < LCM_Eend; item++) {
        if (Eq[FASTO_perm[item]] < LCM_th) Eq[FASTO_perm[item]] = -1;
        /* if item FASTO_perm[item] is infrequent, set Eq[FASTO_perm[item]]=-1 */
        else if (item >= LCM_BM_MAXITEM) bnum += Eq[FASTO_perm[item]]; /* count up the size of transaction database */
        Eq[FASTO_perm[item]] = item;     /* if item FASTO_perm[item] is frequnet set Eq[FASTO_perm[item]] to the re-numbered item */
    }

    /* initialization of variables */
    FASTI_init(filename);
    ARY_init(&LCM_Trsact, sizeof(QUEUE));
    ARY_exp(&LCM_Trsact, LCM_trsact_num + 2);
    QUEUE* Q = LCM_Trsact.h, * QQ = Q;
    malloc2(ibuf, QUEUE_INT, bnum + LCM_trsact_num + 4, "TRSACT_load: ibuf");

    /* read file and store frequent items in memory */
    LCM_Trsact.num = 0;

    while (1) {
        b = Q->q = ibuf;
        Q->s = 0;      /* bitmap for header items */
        Q->end = 1;    /* multiplicity */
    START:;
        while (1) {


            /* read an integer to variable "item" */
            do {
                if (FASTI_p >= FASTI_bufend_) {
                    if (FASTI_bufend - FASTI_buf < FASTI_BUFSIZ - 1) {
                        if (FASTI_p >= FASTI_bufend) {
                            goto END;
                        }
                    }
                    else {
                        i = FASTI_bufend - FASTI_p;
                        memcpy(FASTI_buf, FASTI_p, i);
                        FASTI_p = FASTI_buf;
                        FASTI_bufend = FASTI_buf + i + fread(FASTI_buf + i, 1, FASTI_BUFSIZ - i - 1, FASTI_fp);
                        FASTI_bufend_ = FASTI_bufend - FASTI_REST;
                    }
                    *FASTI_bufend = 0;
                }
                ch = FASTI_flag[*FASTI_p++];
            } while (ch == 127);
            if (ch == 126) { goto END1; }

            for (item = (int)ch; 1; item = item * 10 + (int)ch) {
                ch = FASTI_flag[*FASTI_p++];
                if (ch & 64) break;
            }
            /* end of "read an item" */

            if ((e = Eq[item]) >= 0) {
                if (e < LCM_BM_MAXITEM) {
                    Q->s |= BITMASK_1[e];
                }
                else {
                    *ibuf = e;
                    ibuf++;
                }
            }
            if (ch == 126) goto END1;
        }
    END1:;
        if ((e = ibuf - b) == 0) {
            if (Q->s == 0) goto START;    /* no item is inserted */
            Q->t = 0;
        }
        else {
            Q->t = e; /* #items in this transaction */
            if (Q->t > 1) {
                qsort_int(b, Q->t);
                for (item = 0, i = 1; i < Q->t; i++) {
                    if (b[item] != b[i]) {
                        item++;
                        if (item < i) b[item] = b[i];
                    }
#ifdef LCM_MESSAGES
                    else printf("duplicated item %d in %dth row\n", item, LCM_Trsact.num);
#endif
                }
                Q->t = item + 1;
            }
        }
        *ibuf = LCM_Eend;   /* loop stopper */
        LCM_Trsact.num++;
        ibuf++;
        Q++;
    }
END:;
    FASTI_end();
    ARY_end(&E);
    return (bnum);
}


/*****************************************************************************/
/* Output routines, for given queue of items, output "permutated items"      */
/* In the computation, items are re-numbered so that computation become fast */
/* When output an itemset, the re-numbered items are numbered according to   */
/* "FASTO_perm" array to get the original number                             */
/*****************************************************************************/

void LCM_additem(int item) {
    if (LCM_print_flag & 1) {
        LCM_itemsetp[LCM_itemsett] = LCM_p;
        char* p = &FASTO_digit[item * FASTO_mmag];
        FASTO_cpy(LCM_p, p, p + FASTO_mag[item]);
        LCM_p += FASTO_mag[item];
    }
    LCM_itemsett++;
}
void LCM_delitem() {
    LCM_itemsett--;
    if (LCM_print_flag & 1) LCM_p = LCM_itemsetp[LCM_itemsett];
}

void LCM_output_itemset() {
    int* t;
    FASTO_cpy(FASTO_p, LCM_itemsetbuf, LCM_p);
    FASTO_p += LCM_p - LCM_itemsetbuf;
    FASTO_char('(');
    FASTO_int_large(LCM_frq);
    FASTO_p--;
    FASTO_char(')');
    FASTO_char('\n');
    FASTO_flush_();
}

/* process when find a solution */
void LCM_solution() {
#ifdef LCM_OVERTIME_END
    if (time(NULL) - LCM_start_time > LCM_maximum_time) {
        printf("time over\n"); exit(1);
    }
#endif
    LCM_sc[LCM_itemsett]++;
    if (LCM_print_flag & 1) LCM_output_itemset();
}


/* iteration of output solutions (for LCM_freq) */
void LCMFREQ_output_itemset(int* q) {
    LCM_output_itemset();
    for (q--; q >= LCM_add.q; q--) {
        LCM_additem(*q);
        LCMFREQ_output_itemset(q);
        LCM_delitem();
    }
}

/* process when find a solution (for LCM_freq) */
void LCMFREQ_solution() {
    if (LCM_print_flag & 1) LCMFREQ_output_itemset(LCM_add.q + LCM_add.t);
    //  int i, cc=1, s = LCM_itemset.t;
    int i, cc = 1, s = LCM_itemsett;
    for (i = 0; i <= LCM_add.t; i++) {
        LCM_sc[s] += cc;
        cc = cc * (LCM_add.t - i) / (i + 1);
        s++;
    }
}

/*******************************************************************/
/* add an item to the cullent solution and print it (for LCM_freq) */
/* input: item:item to be added, frq:frequency of obtained itemset */
/*******************************************************************/
void LCM_print_last(int item, int frq, struct bounds_info* parent_info, struct bounds_info* current_info) {
    /*printf("Call to LCM_print_last. item %d\n",item);
    printf("  supp %d\n",frq);

    printf("  parent info supp %d\n",parent_info->frequency);
    printf("  parent info as %d\n",parent_info->as);
    printf("  parent info max_as %d\n",parent_info->max_as);
    printf("  parent info min_as %d\n\n",parent_info->min_as);
    printf("  current info supp %d\n",current_info->frequency);
    printf("  current info as %d\n",current_info->as);
    printf("  current info max_as %d\n",current_info->max_as);
    printf("  current info min_as %d\n\n",current_info->min_as);*/

    if (frq != current_info->frequency) {
        printf("Call to LCM_print_last. item %d\n", item);
        printf("  supp %d\n", frq);

        printf("  parent info supp %d\n", parent_info->frequency);
        //printf("  parent info as %d\n",parent_info->as);
        printf("  parent info max_as %d\n", parent_info->max_as);
        //printf("  parent info min_as %d\n\n",parent_info->min_as);
        printf("  current info supp %d\n", current_info->frequency);
        //printf("  current info as %d\n",current_info->as);
        printf("  current info max_as %d\n", current_info->max_as);
        //printf("  current info min_as %d\n\n",current_info->min_as);
        current_info->frequency = frq;
        reset_bounds(current_info);
    }

    LCM_iters++;
    LCM_frq = frq;
    LCM_additem(item);
    LCMFREQ_solution();
    /* MODIFICATION FOR WY ALGORITHM */
    process_solution0(LCM_frq, parent_info, current_info);
    /* END OF MODIFICATIONS */
    /* MODIFICATION TO KEEP TRACK OF TRANSACTIONS */
    //print_trans0();
    /* END OF MODIFICATIONS */
    LCM_delitem();
    //printf("Call to LCM_print_last done. item %d\n",item);
}

/*******************************************************************/
/* output at the termination of the algorithm */
/* print #of itemsets of size k, for each k */
/* flag=1:all,closed,   0:maximal */
/*******************************************************************/
void LCM_output() {
    int i, n, ii;
    LCM_sc[0] = LCM_problem == LCM_MAXIMAL ? 0 : 1;
    for (n = i = 0; i <= LCM_Eend; i++) {
        n += LCM_sc[i];
        if (LCM_sc[i] != 0) ii = i;
    }
    /* MODIFICATION FOR WY ALGORITHM (DELETION OF CODE) */
    /*
    printf("%d\n", n);
    for(i=0; i<=ii; i++) printf("%d\n", LCM_sc[i] );
    if(LCM_PROBLEM != LCM_MAXIMAL){
      if(LCM_print_flag&1){
        FASTO_char('(');
        FASTO_int_large(LCM_trsact_num);
        FASTO_p--;
        FASTO_char(')');
        FASTO_char('\n');
      }
    }
    */
    /* END OF MODIFICATIONS (DELETION OF CODE) */
    if (LCM_print_flag & 2) {
        printf("iters=%d\n", LCM_iters);
        if (LCM_PROBLEM == LCM_FREQSET)
            printf("compress ratio = %f\n", ((double)n) / LCM_iters);
    }
}


#endif
//#include"lcm_init.c"
#ifndef _lcm_init_c_
#define _lcm_init_c_

//#include"lcm_io.c"

/* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
//#include"transaction_keeping.c"
/* END OF MODIFICATIONS */

/*************************************************************************/
/* Common initialization for LCM, LCMfreq, LCMmax */
/*************************************************************************/
int LCM_init(char* trans_filename) {
    int i, m, n, nn, * bbuf;
    QUEUE* Q;
    QUEUE_INT* x;

    TRANS_LIST aux_trans_list;

    LCM_start_time = time(NULL);
    /* MODIFICATIONS FOR FAST WY ALGORITHIM */
    LCM_print_flag = 0; //Force no output
    //LCM_print_flag |= (argc>2? 1 : 0);//Check argc>3 changed to argc>2 since LCM_th is no longer an input argument
    /* END OF MODIFICATIONS */
    n = LCM_BM_load(trans_filename);   /* loding file of bitmap version */

    if (LCM_Trsact.num == 0) {
        if (LCM_print_flag & 2) printf("there is no frequent itemset\n");
        ARY_end(&LCM_Trsact);
        exit(0);
    }

    if (LCM_print_flag & 2) {
        printf("shrinked database: #transactions=%d, #item=%d #elements=%d\n", LCM_Trsact.num, LCM_Eend, n);
    }

    bbuf = ((QUEUE*)(LCM_Trsact.h))->q;
    if (LCM_BM_MAXITEM > LCM_Eend) LCM_BM_MAXITEM = LCM_Eend;
    LCM_BM_init();

    /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
    transaction_keeping_init(trans_filename);
    /* END OF MODIFICATIONS */

    if (LCM_BM_MAXITEM < LCM_Eend) {
        LCM_shrink_init(&LCM_Trsact, LCM_Eend);
        /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
        TRANS_LIST_INIT(&aux_trans_list, root_trans_list.siz1, root_trans_list.siz2);
        LCM_shrink(&LCM_Trsact, LCM_Eend, 1, &root_trans_list, &aux_trans_list);//LAST TWO ARGUMENTS ADDED FOR TRANSACTION KEEPING
        TRANS_LIST_END(&root_trans_list);
        root_trans_list = aux_trans_list;
        /* END OF MODIFICATIONS */
    }
    //  LCM_buf = (int *)realloc ( bbuf, sizeof(int)*(nn+LCM_Trsact.num));
    //  for ( i=0 ; i<LCM_Trsact.num ; i++ )
    // ((QUEUE*)(LCM_Trsact.h))[i].q =((QUEUE*)(LCM_Trsact.h))[i].q+(LCM_buf-bbuf);

    /***********************************************************************/
    //  TRSACT_sort_by_size ( &LCM_Trsact, &LCM_shrink_jump, LCM_shrink_p );
    //    realloc2 ( A->h, char, A->unit*A->end, "ARY_exp: A->h" );
    /***********************************************************************/

    if (LCM_print_flag & 2) {
        for (n = i = 0; i < LCM_Trsact.num; i++) n += ((QUEUE*)(LCM_Trsact.h))[i].t;
        printf("shrinked database2: #transactions=%d, #item=%d #elements=%d\n", LCM_Trsact.num, LCM_Eend, n);
        printf("LCM_BM_MAXITEM = %d\n", LCM_BM_MAXITEM);
    }

    malloc2(LCM_sc, int, LCM_Eend + 1, "LCM_init: LCM_sc");
    QUEUE_init(&LCM_jump, LCM_Eend * 2 + 2);
    LCM_jump.end = LCM_Eend;
    LCM_itemsett = 0;
    malloc2(LCM_itemsetp, char*, LCM_Eend, "LCM_init: LCM_itemsetp");

    QUEUE_init(&LCM_add, LCM_Eend);
    if (LCM_PROBLEM != LCM_FREQSET) {
        malloc2(LCM_ary, int, LCM_Eend * 2, "LCM_init: LCM_ary");
        QUEUE_init(&LCM_Qtmp, LCM_Eend * 2 + 2);
        malloc2(LCM_Ofrq_, int, LCM_Eend, "LCM_init: LCM_Ofrq_");
        for (i = 0; i < LCM_Eend; i++) {
            LCM_ary[i] = 0;
            LCM_Qtmp.q[i + LCM_Eend] = -1;
        }
    }
    malloc2(LCM_Os, int*, LCM_Eend, "LCM_init: LCM_Os");
    malloc2(LCM_Ot, int*, LCM_Eend, "LCM_init: LCM_Ot");
    malloc2(LCM_Ofrq, int, LCM_Eend, "LCM_init: LCM_Ofrq");
    malloc2(LCM_Op, int, LCM_Eend, "LCM_init: LCM_Op");
    for (i = 0; i < LCM_Eend; i++) {
        LCM_sc[i] = LCM_Ofrq[i] = 0;
        LCM_Ot[i] = NULL;
    }
    LCM_sc[LCM_Eend] = 0;
    for (Q = LCM_Trsact.h, i = 0; i < LCM_Trsact.num; i++) {
        m = Q[i].end;
        for (x = Q[i].q; *x < LCM_Eend; x++) {
            LCM_Ot[*x]++;
            LCM_Ofrq[*x] += m;
        }
    }
    int* ttt = 0;
    for (i = 0, m = 2; i < LCM_Eend; i++) {
        if (i < LCM_BM_MAXITEM) {
            malloc2(LCM_Os[i], int, m + 2, "LCM_init: LCM_Os[i]");
            m *= 2;
        }
        else malloc2(LCM_Os[i], int, (LCM_Ot[i] - ttt) + 2, "LCM_init: LCM_Os[i]");
        if (LCM_Os[i] == NULL) {
            printf("LCM_init: memory short for LCM_Os[i]");
            exit(1);
        }
        LCM_Ot[i] = LCM_Os[i];
    }

    for (i = 0; i < LCM_BM_MAXITEM; i++) LCM_Op[i] = i;  /* item permutation for bitmap items */
    LCM_occ_deliver(&LCM_Trsact, LCM_Eend - 1);
}

/*************************************************************************/
/* Common end processing for LCM, LCMfreq, LCMmax */
/*************************************************************************/
void LCM_end() {
    int j, i, * x, n = 0, m;
    QUEUE* Q;

    if (LCM_print_flag & 1) { FASTO_end(); free2(LCM_itemsetbuf); }
    QUEUE_end(&LCM_jump);
    QUEUE_end(&LCM_add);
    if (LCM_PROBLEM != LCM_FREQSET) {
        QUEUE_end(&LCM_Qtmp);
        free2(LCM_Ofrq_);
        free2(LCM_ary);
    }
    for (i = 0; i < LCM_Eend; i++) free2(LCM_Os[i]);
    free2(LCM_Os);
    free2(LCM_Ot);
    free2(LCM_Ofrq);
    free2(LCM_Op);
    free2(LCM_sc);
    free2(LCM_buf);
}

#endif
//#include"lcm_lib.c"
#ifndef LCM_LIB_C_
#define LCM_LIB_C_
int LCM_jump_rm_infreq(int item) {
    QUEUE_INT* x, * xx, * e = LCM_jump.q + LCM_jump.t;
    int flag = -1;
    for (x = xx = (LCM_jump.q + LCM_jump.s); x != e; x++) {
        if (LCM_Ofrq[*x] >= LCM_th) {
            if (LCM_Ofrq[*x] < LCM_frq) {
                if (x != xx) *xx = *x;
                xx++;
                if (LCM_PROBLEM != LCM_FREQSET) {
                    if (*x < item) LCM_Ofrq_[*x] = LCM_Ofrq[*x];
                }
                continue;
            }
            else {
                if (LCM_PROBLEM == LCM_FREQSET) QUEUE_ins_(&LCM_add, *x);
                else {
                    if (*x < item) LCM_additem(*x);
                    else if (*x > flag) flag = *x;
                }
            }
        }
        LCM_Ofrq[*x] = 0;
    }
    LCM_jump.t = xx - LCM_jump.q;
    return (flag);
}

/*************************************************************************/
/* compute the frequency by occurrence deliver , for LCMmax */
/* INPUT: T:transactions, occ:occurences, max_item.
   OPERATION:
   1. for each item i<=max_item,
        set O->h[i] to the list of transactions in occ including i,
   2. set jump to the list of items i s.t. at least one occurrence of occ
      includes i.   */
      /*************************************************************************/
int LCM_freq_calc(ARY* T, int item, int max_item) {
    QUEUE_INT* x, * jq = &(LCM_jump.q[LCM_jump.t]);
    int ee, n = 0, * t, * t_end;
    QUEUE* Q = T->h;
    if (T->num < LCM_Eend) {
        for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
            ee = Q[*t].end;    /* multiplicity of transaction t */
            for (x = Q[*t].q; *x <= max_item; x++) {
                if (LCM_Ofrq[*x] == 0) { *jq = *x; jq++; }
                LCM_Ofrq[*x] += ee; n++;
            }
        }
    }
    else {
        for (t = LCM_Os[item], t_end = LCM_Ot[item]; t < t_end; t++) {
            ee = Q[*t].end;    /* multiplicity of transaction t */
            for (x = Q[*t].q; *x <= max_item; x++) {
                LCM_Ofrq[*x] += ee; n++;
            }
        }
        for (ee = max_item; ee >= 0; ee--) {
            if (LCM_Ofrq[ee] > 0) { *jq = ee; jq++; }
        }
    }
    LCM_jump.t = jq - LCM_jump.q;
    return (n);
}


/*************************************************************************/
/* remove large items from jump and sort in increasing order
     INPUT: jump, max_item
     OPERATION: 1. for each item i>max_item in jump, remove i from jump
     2. set occ[e].s = occ[e].end for each i<max_item (preserve frequency)
     3. set occ[i].end = 0 for each i in jump
     4. sort items in jump (from jump.s to jump.t) in the increasing order */
     /*************************************************************************/
void LCM_partition_prefix(int item) {
    int i, e;
    for (i = LCM_jump.s; i < LCM_jump.t; i++) {
        e = LCM_jump.q[i];
        if (e > item) {
            LCM_jump.t--;
            LCM_jump.q[i] = LCM_jump.q[LCM_jump.t];
            LCM_jump.q[LCM_jump.t] = e;
            i--;
        }
    }
    QUEUE_sortr_(&LCM_jump);
    qsort_int_(LCM_jump.q + LCM_jump.t, LCM_jumpt - LCM_jump.t);
}


/*************************************************************************/
/* delete marks for pruning of non-closed itemsets
   (items not making recursive call) */
   /*************************************************************************/
void LCMclosed_pruning_del(int tail, int upper_th) {
    while (tail < LCM_Qtmp.t) {
        if (LCM_Qtmp.q[LCM_Eend + LCM_Qtmp.q[LCM_Qtmp.t - 1]] > upper_th) break;
        LCM_Qtmp.t--;
        LCM_Qtmp.q[LCM_Eend + LCM_Qtmp.q[LCM_Qtmp.t]] = -1;
    }
}

/*************************************************************************/
/* set mark for pruning  of non-closed itemsets
   (items not making recursive call) */
   /*************************************************************************/
void LCMclosed_pruning_set(int item, int mark_item, int qt) {
    int j = LCM_Qtmp.t;
    if (mark_item < 0) return;
    LCM_Qtmp.t++;
    while (qt < j) {
        if (LCM_Qtmp.q[LCM_Eend + LCM_Qtmp.q[j - 1]] >= mark_item) break;
        LCM_Qtmp.q[j] = LCM_Qtmp.q[j - 1];
        j--;
    }
    LCM_Qtmp.q[LCM_Eend + item] = mark_item;
    LCM_Qtmp.q[j] = item;
}
#endif

/* FUNCTION DECLARATIONS OF ORIGINAL LCM SOURCE */
void LCMclosed_BM_iter(int item, int m, int pmask, struct bounds_info* parent_info , struct bounds_info* current_info);

void LCMclosed_BM_recursive (int item, int mask, int pmask  , struct bounds_info* parent_info , struct bounds_info* current_info){
  int i;
  if((i=LCM_Ofrq[0]) >= LCM_th){
    if((LCM_BM_pp[1]&pmask)==1 && LCM_BM_pt[1]==0){
        struct bounds_info child_info;
        init_bounds(&child_info);
        child_info.frequency = LCM_Ofrq[0];
        reset_bounds(&child_info);
        //printf("calling LCM_print_last with supp %d\n", LCM_Ofrq[0]);
        LCM_print_last(LCM_Op[0], i , current_info , &child_info);
    }
  }
  LCM_BM_weight[1] = LCM_Ofrq[0] = 0;
  LCM_Ot[0] = LCM_Os[0];
  /* MODIFICATIONS TO KEEP TRACK OF TRANSACTIONS */
  BM_TRANS_LIST_EMPTY(1);
  /* END OF MODIFICATIONS */
  for(i=1; i<item; i++)
    if(LCM_Ofrq[i] >= LCM_th) {
      struct bounds_info child_info;
      init_bounds(&child_info);
      child_info.frequency = LCM_Ofrq[i];
      reset_bounds(&child_info);
      //printf("   calling LCMclosed_BM_iter from LCMclosed_BM_recursive with item %d\n", i);
      LCMclosed_BM_iter(i, mask, pmask , current_info , &child_info);
      child_info.frequency = -1; // debug
    }
    else{
    	if(LCM_Ofrq[i]>0) {
    		//printf("Item %d is infrequent (%d,%d) and will not have LCMclosed_BM_iter,\n",i,LCM_Ofrq[i],LCM_th);
    		LCM_BM_occurrence_delete(i);
    		//printf("Problem fixed!\n");
    	}
    }
  	 // Maybe an else if (LCM_Ofrq[i] > 0) LCM_BM_occurrence_delete(i) doesn't hurt
     //printf("Call to LCMclosed_BM_recursive done. item %d\n",i);
}



/*************************************************************************/
/* LCMclosed iteration (bitmap version ) */
/* input: T:transactions(database), item:tail(current solution) */
/*************************************************************************/
void LCMclosed_BM_iter(int item, int m, int pmask , struct bounds_info* parent_info , struct bounds_info* current_info){
  int mask, it = LCM_itemsett, ttt;

  LCM_frq = LCM_Ofrq[item];

  //printf("  supp %d\n",LCM_frq);

  if(LCM_frq != current_info->frequency){
    printf("problem in LCMclosed_BM_iter: supp %d, current supp %d\n",LCM_frq,current_info->frequency);
    printf("  parent info supp %d\n",parent_info->frequency);
    //printf("  parent info as %d\n",parent_info->as);
    printf("  parent info max_as %d\n",parent_info->max_as);
    //printf("  parent info min_as %d\n\n",parent_info->min_as);
    printf("  current info supp %d\n",current_info->frequency);
    //printf("  current info as %d\n",current_info->as);
    printf("  current info max_as %d\n",current_info->max_as);
    //printf("  current info min_as %d\n\n",current_info->min_as);
    current_info->frequency = LCM_frq;
    reset_bounds(current_info);
  }

  pmask &= BITMASK_31[item];
  if((ttt = LCM_BM_closure(item, pmask)) > 0){
   // pruning has to be here
	  //printf ("BMclo %d item%d it%d frq%d,  prv%d pprv%d::  ttt=%d,%d pmask%x\n", item, LCM_Op[item], LCM_itemsett, LCM_frq, LCM_prv, LCM_pprv, ttt,LCM_Op[ttt], pmask );
    LCM_BM_occurrence_delete(item);
    return;
  }
  LCM_iters++;
  BUF_reset(&LCM_B);
  LCMclosed_BM_occurrence_deliver_(item, m);
  LCM_additem(LCM_Op[item]);
  mask = LCM_BM_rm_infreq(item, &pmask);

  LCM_solution();

  /* MODIFICATION FOR FAST WY ALGORITHIM */
  if(LCM_frq != current_trans.siz){
	  printf("LCM_frq=%d, current_trans.siz=%d\n",LCM_frq,current_trans.siz);
  }
  bm_process_solution(LCM_frq,item,&mask,parent_info,current_info);
  /* END OF MODIFICATION */

  /* MODIFICATION TO KEEP TRACK OF TRANSACTIONS */
  //print_current_trans();
  BM_CURRENT_TRANS_EMPTY();
  /* END OF MODIFICATION */

  LCMclosed_BM_recursive(item, mask, pmask,parent_info,current_info);
  while(LCM_itemsett>it) LCM_delitem();
  BUF_clear(&LCM_B);

  //printf("Call to LCMclosed_BM_iter done. item %d\n",item);
}




/***************************************************************/
/* iteration of LCM ver. 2 */
/* INPUT: T:transactions(database), item:tail of the current solution */
/*************************************************************************/
// LAST ARGUMENT ADDED FOR TRANSACTION KEEPING
int LCMclosed_iter(ARY *T, int item, int prv, TRANS_LIST *trans_list , struct bounds_info* parent_info , struct bounds_info* current_info){
  ARY TT;
  int i, ii, e, ee, n, js=LCM_jump.s, it=LCM_itemsett, mask;
  int flag=-1, pmask = 0xffffffff;
  int* perm;
  perm = (int*)calloc(LCM_BM_MAXITEM, sizeof(int));
  QUEUE_INT *q;

  LCM_jump.s = LCM_jump.t;
  LCM_iters++;
  LCM_additem(item);
  LCM_frq = LCM_Ofrq_[item];
  LCM_prv = item;
  LCM_pprv = prv;

  //printf("   supp %d\n",LCM_frq);

  if(LCM_frq != current_info->frequency && current_info->frequency > 0){
    printf("problem in LCMclosed_iter: supp %d, current supp %d\n",LCM_frq,current_info->frequency);
    printf("Call to LCMclosed_iter. item %d\n",item);
    printf("  parent info supp %d\n",parent_info->frequency);
    //printf("  parent info as %d\n",parent_info->as);
    printf("  parent info max_as %d\n",parent_info->max_as);
    //printf("  parent info min_as %d\n\n",parent_info->min_as);
    printf("  current info supp %d\n",current_info->frequency);
    //printf("  current info as %d\n",current_info->as);
    printf("  current info max_as %d\n",current_info->max_as);
    //printf("  current info min_as %d\n\n",current_info->min_as);
    current_info->frequency = LCM_frq;
    reset_bounds(current_info);
  }

  /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
  TRANS_LIST mk_trans_list, shrink_trans_list;
  /* END OF MODIFICATIONS */

  //printf( " Ot %d %d (%d,%d)\n", LCM_Ot[item]-LCM_Os[item], LCM_frq, item,prv);
  n = LCM_freq_calc(T, item, LCM_Eend-1);
  if(prv >= 0) LCM_Ofrq[prv] = 0;
  LCM_Ofrq[item] = 0;
  ii = LCM_jump_rm_infreq(item);
  LCM_jumpt = LCM_jump.t;
  if(ii > item){
    flag = ii;
    //printf ("###clo item%d %d %d: %d\n", item, ii, LCM_Ofrq[ii], LCM_Ofrq_[ii]);
    goto END2;
  }  /* itemset is not closed */

  BUF_reset(&LCM_B);
  LCM_partition_prefix(item);

  if(QUEUE_LENGTH(LCM_jump)==0){
    LCM_Ofrq[item] = 0;
    LCMclosed_BM_occurrence_deliver_first(item, T, trans_list);//LAST ARGUMENT ADDED FOR TRANSACTION KEEPING
    for(i=LCM_jump.s; i<LCM_jumpt; i++) LCM_Ofrq[LCM_jump.q[i]] = 0;
    mask = LCM_BM_rm_infreq(LCM_BM_MAXITEM, &pmask);
    LCM_solution();
    /* MODIFICATIONS FOR WY ALGORITHM */
    ary_process_solution(LCM_frq, trans_list, item, &mask, parent_info , current_info);
    /* END OF MODIFICATIONS */
    /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
    //print_transaction_list(trans_list,item);
    /* END OF MODIFICATIONS */
    struct bounds_info child_info__;
    init_bounds(&child_info__);
    LCMclosed_BM_recursive(LCM_BM_MAXITEM, mask, pmask, current_info, &child_info__ );
    BUF_clear(&LCM_B);
    goto END2;
  }

  LCM_BM_occurrence_deliver_first(item, T);//LAST ARGUMENT ADDED FOR TRANSACTION KEEPING
  QUEUE_FE_LOOP_(LCM_jump, i, ii) LCM_Ofrq[ii] = 0;
  mask = LCM_BM_rm_infreq(LCM_BM_MAXITEM, &pmask);
  LCM_solution();
  /* MODIFICATIONS FOR WY ALGORITHM */
  ary_process_solution(LCM_frq, trans_list, item, &mask, parent_info , current_info);
  /* END OF MODIFICATIONS */
  /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
  //print_transaction_list(trans_list,item);
  /* END OF MODIFICATIONS */
  BUF_clear(&LCM_B);

// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
  TRANS_LIST_INIT(&mk_trans_list, LCM_frq, LCM_Ot[item]-LCM_Os[item]);
  /* END OF MODIFICATIONS */
  for(i=0; i<LCM_BM_MAXITEM; i++) perm[i] = LCM_Op[i];
  QUEUE_FE_LOOP_(LCM_jump, i, ii) LCM_Ofrq[ii] = LCM_th;
  LCM_Ofrq[item] = LCM_th;
  /* LAST TWO ARGUMENTS ADDED FOR TRANSACTION KEEPING */
  LCM_mk_freq_trsact(&TT, T, item, LCM_Eend-1, n+(LCM_Ot[item]-LCM_Os[item]), mask, trans_list, &mk_trans_list);
  /* END OF MODIFICATIONS */
  LCM_Ofrq[item] = 0;

  BUF_reset(&LCM_B);
  for(i=0; i<LCM_BM_MAXITEM; i++) LCM_BM_occurrence_delete(i);
  LCMclosed_BM_occurrence_deliver_first(-1, &TT, &mk_trans_list);//LAST ARGUMENT ADDED FOR TRANSACTION KEEPING
  for(i=LCM_jump.s; i<LCM_jumpt; i++) LCM_Ofrq[LCM_jump.q[i]] = 0;
  struct bounds_info child_info_;
  init_bounds(&child_info_);
  LCMclosed_BM_recursive(LCM_BM_MAXITEM, 0xffffffff, 0xffffffff, current_info, &child_info_ );
  BUF_clear(&LCM_B);

  if(QUEUE_LENGTH(LCM_jump) == 0) goto END0;
  q = ((QUEUE *)(TT.h))->q;
  /* MODIFICATIONS FOR KEEPING TRACK OF TRANSACTIONS */
  if(ii >= 2 && TT.num>5){
	  TRANS_LIST_INIT(&shrink_trans_list, mk_trans_list.siz1, mk_trans_list.siz2);
	  LCM_shrink(&TT, item, 1, &mk_trans_list, &shrink_trans_list);//LAST TWO ARGUMENTS ADDED FOR TRANSACTION KEEPING
	  TRANS_LIST_END(&mk_trans_list);
  }else{
	  shrink_trans_list = mk_trans_list;
  }
  /* END OF MODIFICATIONS */
  LCM_occ_deliver(&TT, item-1);

  do{
    i = QUEUE_ext_tail_(&LCM_jump);
//    printf ("i=%d(%d) %d %d  :%d,%d\n", i, item, LCM_Ot[item]-LCM_Os[item], LCM_Ot[i]-LCM_Os[i], LCM_Ofrq[i], LCM_Ofrq_[i]);
    /* MODIFICATIONS FOR WY ALGORITHM */
    //WY permutations might cause that some items in LCM_jump.q are no longer frequent/testable, so
    // a check must be added
    if(LCM_Ofrq_[i]>=LCM_th) {
      struct bounds_info child_info_i;
      init_bounds(&child_info_i);
      child_info_i.frequency = LCM_Ofrq_[i];
      reset_bounds(&child_info_i);

      ii = LCMclosed_iter(&TT, i, item, &shrink_trans_list,current_info , &child_info_i);//LAST ARGUMENT ADDED FOR TRANSACTION KEEPING
    }
    //else printf("Item %d pruned since LCM_Ofrq_[%d]=%d, and LCM_th=%d\n",i,i,LCM_Ofrq_[i],LCM_th);
    /* END OF MODIFICATIONS */
    LCM_Ot[i] = LCM_Os[i];
    LCM_Ofrq_[i] = 0;
  }while(LCM_jump.t > LCM_jump.s);

  free2(q);
  ARY_end(&TT);
  TRANS_LIST_END(&shrink_trans_list);
  END0:;
  for(i=0; i<LCM_BM_MAXITEM; i++) LCM_Op[i] = perm[i];
  goto END3;
  END2:;
  for(i=LCM_jump.s; i<LCM_jumpt; i++) LCM_Ofrq[LCM_jump.q[i]] = 0;
  LCM_jump.t = LCM_jump.s;
  END3:;
  LCM_jump.s = js;
  while(it<LCM_itemsett) LCM_delitem();

  //printf("Call to LCMclosed_iter done. item %d\n",item);


  return (flag);
}

/***************************************************************/
/* main of LCM ver. 3 */
/*************************************************************************/
void LCMclosed(){
  int i;
  BUF_reset(&LCM_B);
  LCMclosed_BM_occurrence_deliver_first(-1, &LCM_Trsact, &root_trans_list);//LAST ARGUMENT ADDED FOR TRANSACTION KEEPING
  for (i=LCM_BM_MAXITEM ; i<LCM_Eend ; i++){
    LCM_Ofrq_[i] = LCM_Ofrq[i];
    LCM_Ofrq[i] = 0;
  }

  struct bounds_info child_info;
  init_bounds(&child_info);
  struct bounds_info current_info;
  init_bounds(&current_info);

  LCMclosed_BM_recursive(LCM_BM_MAXITEM, 0xffffffff, 0xffffffff, &current_info, &child_info);
  BUF_clear(&LCM_B);

  for (i=LCM_BM_MAXITEM ; i<LCM_Eend ; i++){
    struct bounds_info child_info_i;
    init_bounds(&child_info_i);
    //printf("calling LCMclosed_iter 2\n");
    LCMclosed_iter(&LCM_Trsact, i, -1, &root_trans_list, &current_info, &child_info_i);//LAST ARGUMENT ADDED FOR TRANSACTION KEEPING
    LCM_Ot[i] = LCM_Os[i];
    LCM_Ofrq_[i] = LCM_Ofrq[i] = 0;
    printf("lcm iter %d\n", i);
  }
  LCM_iters++;
}

int random_seed;
char *input_file; // dataset path
double max_eps;
char *basefilename;

int parseParameters(int argc, char *argv[]){

	// default values for parameters
	K = -1; // -1 means unbounded search

	delta = 0.1;
	J = 10; // number of draws of Rademacher random variables
  int input_file_given = 0;
  int base_file_given = 0;
  int print_help = 0;
  random_seed = 1;
  max_eps = 1.0;
  theta = 0.0;
  max_pattern_freq = 1.0;
  max_variance = 0.25;
  dev_lower_bound = 0.0;
  approximation_ratio = 1.0;
  union_bound_term = 0.0;

	char opt;
  while ( ( opt = getopt ( argc, argv, "j:d:b:i:k:s:e:h:t:f:v:l:a:u:" ) ) != -1 ) {
    switch ( opt ) {
    case 'j': J = atoi(optarg); break;
    case 'd': delta = atof(optarg); break;
    case 'i': input_file = optarg; input_file_given = 1; break;
    case 'b': basefilename = optarg; base_file_given = 1; break;
    case 'k': K = atoi(optarg); break;
		case 's': random_seed = atoi(optarg); break;
    case 'e': max_eps = atof(optarg); break;
    case 'h': print_help = 1; break;
    case 't': theta = atof(optarg); break;
    case 'f': max_pattern_freq = atof(optarg); break;
    case 'v': max_variance = atof(optarg); break;
    case 'l': dev_lower_bound = atof(optarg); break;
    case 'a': approximation_ratio = atof(optarg); break;
    case 'u': union_bound_term = atof(optarg); break;
    }
  }

	// check for the spec file, prompt the parameters info
	if((!input_file_given || !base_file_given) || print_help){
    printf("Parameters:\n");
    printf("    -i [input file]\n");
    printf("    -d [probability delta] (in (0,1] , default: 0.1)\n");
    printf("    -j [Number of Rademacher vectors] (default: 10)\n");
    printf("    -k [Number of top-k patterns to enumerate] (default: -1 (unbounded search))\n");
    printf("    -s [random seed] (default: 1)\n");
    printf("    -t [theta] (default: 1)\n");
    printf("    -e [maximum acceptable value of epsilon] (default: 1)\n");
    printf("    -f [maximum frequency of patterns to use for n-MCERA] (default: 1.)\n");
    printf("    -f [maximum variance] (default: 0.25)\n");
    printf("    -f [approximation ratio] (default: 1.0)\n");
    printf("    -l [lower bound to the value of the n-MCERA] (default: 0.0)\n");
    printf("    -h [print help]\n");
		return 1;
	}


  printf("delta %f\n",delta);
  printf("number of rade draws %d\n",J);
  /*cout << "delta = " << delta << endl;
	cout << "jp = " << jp << endl;*/
	return 0;
}

/*************************************************************************/
/*************************************************************************/
int main(int argc, char *argv[]){
  int i;

  /* MODIFICATIONS FOR FAST WY ALGORITHIM */

  // Main input arguments which are not part of LCM
  //int n_perm;
  double sig_th;
  //char *class_labels_file;
  //char *trans_filename;
  char *tmp_filename;
  //int seed_idx;

  if(parseParameters(argc, argv) == 1){
    exit(1);
  }

  tmp_filename = (char *)malloc((strlen(basefilename)+512)*sizeof(char));
  if(!tmp_filename){
	fprintf(stderr,"Error in function main: couldn't allocate memory for array tmp_filename\n");
	exit(1);
  }
  // Create a file to report runtime information
  strcpy(tmp_filename,basefilename); strcat(tmp_filename,"_timing.txt");
  if(!(timing_file = fopen(tmp_filename,"w"))){
	fprintf(stderr, "Error in function main when opening file %s\n",tmp_filename);
	exit(1);
  }
  // Create a file to report results
  strcpy(tmp_filename,basefilename); strcat(tmp_filename,"_results.txt");
  if(!(results_file = fopen(tmp_filename,"w"))){
  	fprintf(stderr, "Error in function main when opening file %s\n",tmp_filename);
  	exit(1);
  }
  // Create a file to report results
  strcpy(tmp_filename,basefilename); strcat(tmp_filename,"_tfp.txt");
  if(!(tfp_file = fopen(tmp_filename,"w"))){
  	fprintf(stderr, "Error in function main when opening file %s\n",tmp_filename);
  	exit(1);
  }
  // Create a file to report minimum pvalues
  strcpy(tmp_filename,basefilename); strcat(tmp_filename,"_minpvals.txt");
  if(!(minpvals_file = fopen(tmp_filename,"w"))){
	fprintf(stderr, "Error in function main when opening file %s\n",tmp_filename);
	exit(1);
  }

  // Free filename holder
  free(tmp_filename);

  start_measuring_time();

  // Initialise the support of LCM to 1
  LCM_th = 1;
  /* END OF MODIFICATIONS */
  //tic = measureTime();
  LCM_problem = LCM_CLOSED;
  LCM_init(input_file);
  //toc = measureTime();
  time_LCM_init = toc-tic;

  /* MODIFICATIONS FOR FAST WY ALGORITHIM */
  //Initialise random permutations
  //tic = measureTime();
  permutation_init(J,input_file,random_seed);
  //toc = measureTime();
  time_permutations = toc-tic;
  if(theta > 0.0){
    LCM_th = (int)(theta * (double)N);
    printf("LCM_th set to %d\n",LCM_th);
  }
  // Initialize MCRapper permutation code
 // tic = measureTime();
  mcrapper_init(delta , K, max_eps);
 // toc = measureTime();
  time_initialisation_wy = toc-tic;
  /* END OF MODIFICATIONS */
 // tic = measureTime();
  LCMclosed();
 // toc = measureTime();
  time_threshold_correction = toc-tic;

  // Main part of the code
  LCM_output();
  LCM_end();
  ARY_end(&LCM_Trsact);

  /* MODIFICATION TO KEEP TRACK OF TRANSACTIONS */
  //tic = measureTime();
  transaction_keeping_end();
  /* END OF MODIFICATIONS */
  /* MODIFICATIONS FOR FAST WY ALGORITHIM */
  mcrapper_end();
  permutation_end();
  //toc = measureTime();
  time_termination = toc-tic;

  exit(0);
}


#endif
