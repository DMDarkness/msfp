#include <chrono>
#include <cmath>
#include <cstdlib>
#include <string>
#include <fstream>
#include <iostream>
#include <random>
#include <vector>
#include <map>
#include <boost/math/special_functions/beta.hpp>
#include <boost/math/distributions/binomial.hpp>
#include "unistd.h"

using namespace std;
using namespace std::chrono;
using namespace boost::math;

chrono::steady_clock::time_point start_time, end_time;
chrono::duration<double> used_time;//=chrono::steady_clock::now();

double taking_sample_time = 0;
double check_sample_time = 0;
double mining_time = 0;

inline unsigned int get_sample_size_1(float theta, int Imax, float epsilon, float delta)
{
    //Imax = (float)Imax;
    unsigned int size = 10000;
	unsigned int step = 10000;
	while (1) {
		binomial bin(size, theta);
		if(cdf(bin, size * (theta - 1 * epsilon))> delta / (3.0 * Imax)){
			size = size + step;
		}
		else if (step > 1) {
			size = size - step/2;
			step = step / 2;
		}
		else {
			break;
		}
	}
    return size;
}

inline unsigned int get_sample_size_2(float theta, int FI1Num, float epsilon, float delta)
{
    FI1Num = (float)FI1Num;
    unsigned int size = 10000;
	unsigned int step = 10000;
	while (true) {
		binomial bin(size, theta);
		if(cdf(bin, size*(theta - 1*epsilon))>delta/(3*pow(2, FI1Num))){
			size = size + step;
		}
		else if (step > 1) {
			size = size - step / 2;
			step = step / 2;
		}
		else {
			break;
		}
	}

    return size;
}

string pattern_prune(char* Buff, const char *line, int len, vector<unsigned int> *If_Freqs, int Imax) {
	int itm;

	unsigned int spatLoc = 0;

	//int len = strlen(line)+1;

	char* line_cp = new char[len];

	strncpy(line_cp, line, len);


	char* token = strtok(line_cp, " \n");
	while (token != NULL) {
		itm = strtol(token, NULL, 10);
		if (itm < max(10000, Imax + 1)) {
			if ((*If_Freqs)[itm] == 1) {
				for (unsigned int i = 0; i < strlen(token); i++) {
					Buff[spatLoc] = token[i];
					spatLoc++;
				}
				Buff[spatLoc] = ' ';
				spatLoc++;
			}
		}
		token = strtok(NULL, " \n");
	}
	Buff[spatLoc] = '\0';
	delete[] line_cp;
	return string(Buff);
}

inline map<string, float> fpMine_r(float theta, float epsilon)
{
	map<string, float> fpset;
	char sup[9];//r_sup[9];
	sprintf(sup,"%3.4f", (theta-1*epsilon)*100);
	string csp(sup);
	string cmd = "fpgrowth -w -ts -s"+csp+" sample.dat result_msfp.dat";
	system(cmd.c_str());
	ifstream in("result_msfp.dat");
	int pos;
    if(in){
		string line;
        while(getline(in,line)){
			pos = line.find("(");
			if(line.substr(0,pos).length()>0){
				fpset.insert(pair<string, float>(line.substr(0,pos),atof(line.substr(pos+1,line.size()-pos-2).c_str())/100));
			}
        }
    }
	in.close();
	return fpset;
}

inline bool check_every_pat_for_sample_3(float epsilon, float delta, map<string, float> FPstar, float sample_size_3, unsigned int FPstarNum){
	bool result = false;
	double ck = 0;

	for(pair<string, float> pat : FPstar){
		//cout << sample_size_3 <<" "<< epsilon<<" b\n";
		ck = ck + ibeta(pat.second*sample_size_3+1, sample_size_3 - pat.second*sample_size_3 +1, min(1.0, pat.second + 0.5 * epsilon))
			-  ibeta(pat.second*sample_size_3+1, sample_size_3 - pat.second*sample_size_3 +1, max(0.0,pat.second - 0.5 * epsilon));
		//cout << pat.second << "e\n";
	}
	
	if(ck >= FPstarNum-delta/3.0){
		result = true;
	}
	//cout << ck << " " << FPstarNum - delta <<" "<< FPstarNum<< "\n";
	return result;
}

inline pair<bool,map<string, float>> check_sample_size_3(float epsilon, float delta, unsigned int sample_size_3, map<string, unsigned int> *sample3, float theta, int increase_num){

	start_time = chrono::steady_clock::now();//end counting time

	ofstream msfp_sample3;
	if(increase_num == 1){
		msfp_sample3.open("sample.dat", std::ios::trunc);
	}else{
		msfp_sample3.open("sample.dat", std::ios::app);
	}
	
	unsigned int i;
    map<string, unsigned int>::iterator sp3i;
    for(sp3i = sample3->begin();sp3i!=sample3->end();sp3i++){
		if (sp3i->second > 0) {
			if (strcmp(sp3i->first.c_str(), "") == 0) {
				msfp_sample3 << " " << sp3i->second << "\n";
			}
			else {
				msfp_sample3 << sp3i->first << sp3i->second << "\n";
			}
		}
    }

    msfp_sample3.close();

	end_time = chrono::steady_clock::now();//end counting time
	used_time=chrono::duration_cast<chrono::duration<double>>(end_time-start_time);
	taking_sample_time = taking_sample_time + used_time.count();

	start_time = chrono::steady_clock::now();//end counting time
	map<string, float> fp = fpMine_r(theta, 1*epsilon);
	end_time = chrono::steady_clock::now();//end counting time
	used_time=chrono::duration_cast<chrono::duration<double>>(end_time-start_time);
	mining_time = mining_time + used_time.count();

	start_time = chrono::steady_clock::now();//end counting time
	pair<bool,map<string, float>> result;
	result.first = true;

	if(!check_every_pat_for_sample_3(epsilon, delta, fp, sample_size_3, fp.size())){
		result.first = false;
	}else{
		ofstream result_msfp("result_msfp.dat", ios::trunc);
		for(pair<string, float>c_p: fp){
			if(c_p.second >= theta - 0.5*epsilon){
				result_msfp<<c_p.first<<"("<<c_p.second*100<<")\n";
			}
		}
		result_msfp.close();
	}
	
	result.second = fp;
	end_time = chrono::steady_clock::now();//end counting time
	used_time=chrono::duration_cast<chrono::duration<double>>(end_time-start_time);
	check_sample_time = check_sample_time + used_time.count();
	return result;
}

unsigned int calculate_step(float epsilon, float delta, unsigned int current_sample_size, map<string, float> fp_closed)
{
	unsigned int step = 0;
	float ck=0;
	float ratio;
	unsigned int fp_c_num = fp_closed.size();
	while(ck < float(fp_c_num)-delta/6.0){
		ck = 0;
		step = step+10000;
		for(pair<string, float> pat : fp_closed){
			ratio = pat.second;
			ck = ck +
				ibeta(ratio*(current_sample_size + step)+1, 
								current_sample_size + step - ratio*(current_sample_size + step) +1, min(1.0,ratio + 0.5 * epsilon))
				-  beta(ratio*(current_sample_size + step)+1, 
									current_sample_size + step - ratio*(current_sample_size + step) +1, max(0.0,ratio - 0.5 * epsilon));
		}
	}
	//cout << "the step is " << step << "\n";
	return step;
}

unsigned int take_and_process_sample_2_3(unsigned int pres_size, char** pre_sample,
					float epsilon, float delta, float theta, unsigned int sample_size_2, char *dataset, 
					vector<unsigned int> If_Freqs,  
					int Imax)
{
	start_time = chrono::steady_clock::now();//end counting time

	map<string, unsigned int> result;
	unsigned int current_sample_size = 0;//the size of third sample
	
	char line[10000], line_long[10000], Buff[10000], buff[10];

	map<string, unsigned int>::iterator temp_it;
	unsigned int sampled_index = 0;

	bool long_sig = false;

	pair<bool,map<string, float>> ck;
	ck.first = false;
	unsigned int step = 0;
	string t_key;
	int increase_num = 0;

	end_time = chrono::steady_clock::now();//end counting time
	used_time=chrono::duration_cast<chrono::duration<double>>(end_time-start_time);
	taking_sample_time = taking_sample_time + used_time.count();

	while(!ck.first){// && current_sample_size< pres_size){
		if(current_sample_size>0){
			start_time = chrono::steady_clock::now();//end counting time

			step = calculate_step(epsilon, delta, current_sample_size, ck.second);// +sample_size_1;

			end_time = chrono::steady_clock::now();//end counting time
			used_time=chrono::duration_cast<chrono::duration<double>>(end_time-start_time);
			check_sample_time = check_sample_time + used_time.count();}

		else{
			step = sample_size_2;
		}

		start_time = chrono::steady_clock::now();

		increase_num++;
		current_sample_size = current_sample_size + step;

		if(step > 0){
			//cout << "start" << "\n";
			for (; sampled_index < current_sample_size; sampled_index++) {
				int len = strlen(pre_sample[sampled_index%pres_size]) + 1;
				t_key = pattern_prune(Buff, pre_sample[sampled_index%pres_size], len, &If_Freqs, Imax);

				temp_it = result.find(t_key);
				if (temp_it == result.end()) {
					result.insert(pair<string, unsigned int>(t_key, 1));
				}
				else {
					temp_it->second++;
				}
			}
		}

		end_time = chrono::steady_clock::now();//end counting time
		used_time=chrono::duration_cast<chrono::duration<double>>(end_time-start_time);
		taking_sample_time = taking_sample_time + used_time.count();

		ck = check_sample_size_3(epsilon, delta, current_sample_size, &result, theta, increase_num);
		//cout << "check done\n";
		start_time = chrono::steady_clock::now();

		for(temp_it = result.begin(); temp_it != result.end(); temp_it++){
			temp_it->second = 0;
		}

		end_time = chrono::steady_clock::now();//end counting time
		used_time=chrono::duration_cast<chrono::duration<double>>(end_time-start_time);
		taking_sample_time = taking_sample_time + used_time.count();
	}
	return current_sample_size;
}

inline pair<unsigned int, vector<unsigned int>> take_and_process_sample_1(int ds_size,
															unsigned int* pres_size,
															char** pre_sample,
															char *dataset, 
															uniform_int_distribution<int> *distribution, 
															unsigned int sample_size, 
															mt19937_64 *generator, 
															int Imax, 
															float theta)
{
	pair<unsigned int, vector<unsigned int>> result;
	result.first = 0;
	unsigned int item;
	vector<unsigned int> Map(max(10000, Imax+1));
	result.second = Map;

	FILE *ds_FILE = fopen(dataset, "r");

	vector<unsigned int> sampled_indices(sample_size, 0);

	for (unsigned int i = 0; i < sample_size; ++i){
		sampled_indices[i] = (*distribution)(*generator);
	}

	sort(sampled_indices.begin(), sampled_indices.end());
	unsigned int sampled_index = 0;
	unsigned int the_plus;

	unsigned int base_transaction_id = 0;
	char line[10000];

	unsigned int i = 0;

	while (sampled_index < sample_size){
		the_plus = 0;
		while (base_transaction_id < sampled_indices[sampled_index]) {
			if (base_transaction_id % 10000000 == 0) {
				cout << base_transaction_id << "\n";
			}
			fgets(line, 10000, ds_FILE);
			if (*pres_size < 1000000 && rand()*1.0/RAND_MAX < 1000000.0/ds_size) {
				pre_sample[*pres_size] = new char[strlen(line)+1];
				strncpy(pre_sample[*pres_size], line, strlen(line)+1);
				*pres_size = *pres_size+1;
			}
			base_transaction_id++;
		}

		while(sampled_index < sample_size && sampled_indices[sampled_index] == base_transaction_id){
			sampled_index++;
			the_plus++;
		}

		char* line_cp = new char[strlen(line) + 1];
		strncpy(line_cp, line, strlen(line) + 1);
		char* token = strtok(line_cp, " \n");
		while (token != NULL) {
			item = strtol(token, NULL, 10);
			if (item < max(10000, Imax + 1)) {
				result.second[item] = result.second[item] + the_plus;
			}
			token = strtok(NULL, " \n");
		}
		delete[] line_cp;
	}

	for(i=0;i< max(10000, Imax + 1);i++){
		if(result.second[i]>=theta*sample_size){
			result.first++;
			result.second[i] = 1;
		}
		else{
			result.second[i] = 0;
		}
	}

	//cout << "91 is " << result.second[91] << "\n";
	//cout << "109 is " << result.second[109] << "\n";

	fclose(ds_FILE);
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	shuffle(pre_sample, pre_sample+*pres_size, default_random_engine(seed));
	return result;
}

int main(int argc, char **argv) 
{
	int opt;
	if ( argc - 5<0) {
		cerr << "wrong number of arguments" << endl;
		return EXIT_FAILURE;
	} 
	double epsilon = strtod(argv[argc - 5], NULL);
	if (errno == ERANGE || epsilon >= 1.0 || epsilon <= 0.0) {
		printf("%f\n",epsilon);
		cerr << "epsilon should be greater than 0 and smaller than 1" << endl;
		return EXIT_FAILURE;
	}
	double delta = strtod(argv[argc - 4], NULL);
	if (errno == ERANGE || delta >= 1.0 || delta <= 0.0) {
		cerr <<"delta should be greater than 0 and smaller than 1" << endl;
		return EXIT_FAILURE;
	}
	char *dataset = argv[argc - 3];
	double theta = strtod(argv[argc - 2], NULL);
	int Imax = strtod(argv[argc - 1], NULL);
	unsigned int ds_size = 0;
	//cout << epsilon << " " << delta << " " << string(dataset) << " " << theta << " " << Imax << "\n";
	
	FILE* pos_file = fopen(dataset, "r");

	char line[1000];

	while (!feof(pos_file)) {
		fgets(line, 1000, pos_file);
		if (line[998] == '\n' || line[998] == '\0') {
			ds_size++; 
		}
		else {
			line[998] = '\0';
		}
	}

	//cout << ds_size << "\n";
	
	fclose(pos_file);

	start_time = chrono::steady_clock::now();
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	mt19937_64 generator(seed);
	uniform_int_distribution<int> distribution(0, ds_size - 1);
	unsigned int sample_size_1 = get_sample_size_1(theta, Imax, 1*epsilon, delta);

	char **pre_sample = new char*[1000000];
	unsigned int pre_sample_size = 0;

	pair<unsigned int, vector<unsigned int>>result1 = take_and_process_sample_1(ds_size, &pre_sample_size, pre_sample, dataset, &distribution, sample_size_1, &generator, Imax, theta-1*epsilon);


	unsigned int sample_size_2 = get_sample_size_2(theta, result1.first, 1*epsilon, delta);

	end_time = chrono::steady_clock::now();
	used_time=chrono::duration_cast<chrono::duration<double>>(end_time-start_time);
	taking_sample_time = taking_sample_time + used_time.count();

	unsigned int sample_size_3 = take_and_process_sample_2_3(pre_sample_size, pre_sample, epsilon, delta, theta, sample_size_2, dataset, result1.second, Imax);

	cout << "check sampling time " << check_sample_time*1000 << " ms;\n";
	cout << "sampling time is " << taking_sample_time * 1000 << " ms;\n";
	cout << "mining time is " << mining_time * 1000 << " ms;\n";
	cout << "total time is " << (mining_time+ check_sample_time+ taking_sample_time) * 1000 << " ms;\n";
	cout << "first sample size is " << sample_size_1 << "\n";
	cout << "second sample size is " << sample_size_2 << "\n";
	cout << "third sample size is " << sample_size_3 << "\n";
	cout << "total size is " << sample_size_3+sample_size_1 << "\n";

	ofstream rfile("record_msfp.dat", std::ios::out | std::ios::app);
	rfile << "-----------------------------------------------\n";
	rfile << "check sampling time " << check_sample_time * 1000 << " ms;\n";
	rfile << "sampling time is " << taking_sample_time * 1000 << " ms;\n";
	rfile << "mining time is " << mining_time * 1000 << " ms;\n";
	rfile << "total time is " << (mining_time + check_sample_time + taking_sample_time) * 1000 << " ms;\n";
	rfile << "first sample size is " << sample_size_1 << "\n";
	rfile << "second sample size is " << sample_size_2 << "\n";
	rfile << "third sample size is " << sample_size_3 << "\n";
	rfile << "total size is " << sample_size_3 + sample_size_1 << "\n";
	rfile << "minimum support is " << theta << "\n";
	rfile << "epsilon is " << epsilon << "\n";
	rfile << "delta is " << delta << "\n";
	rfile << "data is " << dataset << "\n";
	rfile.close();

	return EXIT_SUCCESS;
}

