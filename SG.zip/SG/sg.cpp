#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <forward_list>
#include <fstream>
#include <iostream>
#include <random>
#include <vector>
#include <map>
#include <bitset>
//#include <ext/hash_map>
#include <bitset>
//#include <gsl/gsl_cdf.h>
#include <boost/math/distributions/normal.hpp>
#include "unistd.h"

using namespace std;
using namespace std::chrono;
using namespace boost::math;
//using namespace __gnu_cxx;

void usage(char *binary_name) {
	cerr << binary_name << ": sampling and information granulation algorithm to extract an (eps,delta)-approximation" << endl;
	cerr << "USAGE: " << binary_name << " [-h] epsilon delta dataset minsup Imax" << endl;
	cerr << "Sample a number of transactions from dataset sufficient to get an (epsilon,delta)-approximation" << endl;
	cerr << "\t-h : print this message and exit" << endl;
}

inline void *malloc_check(size_t size, const char *err_msg) {
	void *ptr = malloc(size);
	if (ptr == NULL) {
		cerr << "CRITICAL: malloc() failed in " << err_msg << endl;
		exit(EXIT_FAILURE);
	}
	return ptr;
}

inline float P(float epsilon, unsigned int size, float p){
    float res = 0;
	normal dis(0, sqrt(p * (1 - p) / float(size)));
    res = cdf(dis, epsilon) - cdf(dis, -epsilon);
    return res;
}

inline unsigned int get_sample_size_1(float theta, int Imax, float epsilon, float delta)
{
	normal dis(0, 1);
	double edge = quantile(dis, 1 - (1 - pow(1 - delta, 1 / 3.0))/ (2.0*Imax));
	unsigned int  size =unsigned int(pow(edge* 0.5/ epsilon,2))+1;

    return size;
}

inline unsigned int get_sample_size_2(float theta, vector<float> v1, vector<float> v2, float epsilon, float delta)
{

    unsigned int size = 0;
	unsigned int step = 10000;
    float res;
    while(1){
        size = size+ step;
        res = 1;
        res = res - pow(2,v2.size())*(1-P(0.5*epsilon,size, 0.5));
        for(unsigned int i = 1; i<=v1.size();i++){
            res = res - pow(2,v1.size()+v2.size()-i)*(1-P(0.5*epsilon, size, v1[i-1]+epsilon));
        }
        if(res>=pow(1-delta, 1.0/3)){
			if (step < 2) {
				break;
			}
			else {
				size = size - step;
				step = step / 2;
			}
        }
    }
    return size;
}

inline pair<unsigned int, vector<unsigned int>> take_sample_1(char *dataset, uniform_int_distribution<int> *distribution, unsigned int sample_size, mt19937_64 *generator, int Imax, float theta)
{
	pair<unsigned int, vector<unsigned int>> result;
	result.first = 0;
	unsigned int item;
	vector<unsigned int> Map(max(10000, Imax+1));
	result.second = Map;

	//ifstream ds_FILE(dataset);
	FILE* ds_FILE = fopen(dataset, "r");

	vector<unsigned int> sampled_indices(sample_size, 0);
	for (unsigned int i = 0; i < sample_size; ++i) {
		sampled_indices[i] = (*distribution)(*generator);
	}
	sort(sampled_indices.begin(), sampled_indices.end());
	unsigned int sampled_index = 0;
	unsigned int the_plus;

	char line[10000];

	unsigned int base_transaction_id = 0;

	while (sampled_index < sample_size){
		the_plus = 0;
		while (base_transaction_id < sampled_indices[sampled_index]) {
			if (base_transaction_id % 10000000 == 0) {
				cout << base_transaction_id << "\n";
			}
			fgets(line, 10000, ds_FILE);
			base_transaction_id++;
		}
		while (sampled_index < sample_size && sampled_indices[sampled_index] == base_transaction_id){
			sampled_index++;
			the_plus++;
		} 

		char* line_cp = new char[strlen(line) + 1];
		strncpy(line_cp, line, strlen(line) + 1);
		char* token = strtok(line_cp, " \n");
		while (token != NULL) {
			item = strtol(token, NULL, 10);
			if (item < max(10000, Imax + 1)) {
				result.second[item] = result.second[item] + the_plus;
			}
			token = strtok(NULL, " \n");
		}
		delete[] line_cp;
	}

	int i;
	for(i=0;i< max(10000, Imax + 1);i++){
		if(result.second[i]>=theta*sample_size){
			result.first++;
		}
		else{
			result.second[i] = 0;
		}
	}
	fclose(ds_FILE);

	return result;
}

void pattern_to_b1000(bitset<1000>* bitpat, const char *line, vector<unsigned int> *If_Freqs, map<unsigned int, unsigned int> *Map, int Imax) {
	char *copy = (char *) malloc_check(strlen(line) + 1, "pattern_to_long_long");
	char *orig_copy = copy;
	strncpy(copy, line, strlen(line) + 1);

	*bitpat = 0;
	int itm;
	//char *token;


	char* token = strtok(copy, " \n");
	while (token != NULL) {
		itm = strtol(token, NULL, 10);
		if (itm <= Imax) {
			if ((*If_Freqs)[itm] == 1) {
				(*bitpat)[Map->find(itm)->second] = 1;
			}
		}
		token = strtok(NULL, " \n");
	}

	free(orig_copy);
}

inline void take_sample_2_bitset1000(unsigned int sample_size_2, char *dataset, uniform_int_distribution<int> *distribution, mt19937_64 *generator, vector<unsigned int> If_Freqs, map<unsigned int, unsigned int> Map, map<unsigned int, unsigned int> rMap, int Imax)
{
	map<string, unsigned int> result;
	string oatkey;

	FILE* ds_FILE = fopen(dataset, "r");
	bitset<1000> temp_pat;// = new bitset<1000>;
	map<string, unsigned int>::iterator temp_it;

	unsigned int sampled_index = 0;

	char line[10000];

	vector<unsigned int> sampled_indices(sample_size_2, 0);
	for (unsigned int i = 0; i < sample_size_2; ++i) {
		sampled_indices[i] = (*distribution)(*generator);
	}
	sort(sampled_indices.begin(), sampled_indices.end());
	unsigned int base_transaction_id = 0;

	while (sampled_index < sample_size_2) {

		while (base_transaction_id < sampled_indices[sampled_index]) {
			if (base_transaction_id % 10000000 == 0) {
				cout << base_transaction_id << "\n";
			}
			fgets(line, 10000, ds_FILE);
			base_transaction_id++;
		}

		//pattern_to_b1000(temp_pat, line, &If_Freqs, &Map, Imax);
		char* copy = (char*)malloc_check(strlen(line) + 1, "pattern_to_long_long");
		char* orig_copy = copy;
		strncpy(copy, line, strlen(line) + 1);

		temp_pat.reset();
		int itm;
		//char *token;


		char* token = strtok(copy, " \n");
		while (token != NULL) {
			itm = strtol(token, NULL, 10);
			if (itm < max(10000, Imax + 1)) {
				if ((If_Freqs)[itm] == 1) {
					temp_pat.set(Map.find(itm)->second);
				}
			}
			token = strtok(NULL, " \n");
		}

		free(orig_copy);

		oatkey = temp_pat.to_string();
		
		temp_it = result.find(oatkey);
		if(temp_it==result.end()){
			result.insert(pair<string, unsigned int>(oatkey,0));
			temp_it = result.find(oatkey);
		}

		while (sampled_index < sample_size_2 && sampled_indices[sampled_index] == base_transaction_id){
			temp_it->second++;
			sampled_index++;
		}
	}
	fclose(ds_FILE);

	ofstream sg_sample("sample.dat", ios::trunc);
	unsigned int i;
    map<string, unsigned int>::iterator sp3i;
    for(sp3i = result.begin();sp3i!=result.end();sp3i++){
		bitset<1000> tr(sp3i->first);
        if(tr.any()){
            for(i=0;i<1000;i++){
                if(tr.test(i)){
                    sg_sample<<rMap[i]<<" ";
                }
            }
            sg_sample<<sp3i->second<<"\n";
        }
        else{
            sg_sample<<" "<<sp3i->second<<"\n";
        }
    }
    sg_sample.close();
}

int main(int argc, char **argv){

	if (argc - 5<0) {
		cerr << "wrong number of arguments" << endl;
		return EXIT_FAILURE;
	} 
	double epsilon = strtod(argv[argc - 5], NULL);
	if (errno == ERANGE || epsilon >= 1.0 || epsilon <= 0.0) {
		printf("%f\n",epsilon);
		cerr << "epsilon should be greater than 0 and smaller than 1" << endl;
		return EXIT_FAILURE;
	}
	double delta = strtod(argv[argc - 4], NULL);
	if (errno == ERANGE || delta >= 1.0 || delta <= 0.0) {
		cerr <<"delta should be greater than 0 and smaller than 1" << endl;
		return EXIT_FAILURE;
	}
	char *dataset = argv[argc - 3];
	double theta = strtod(argv[argc - 2], NULL);
	int Imax = strtod(argv[argc - 1], NULL);
	double ds_size = 0;

	FILE* pos_file = fopen(dataset, "r");

	char line[1000];

	while (!feof(pos_file)) {
		fgets(line, 1000, pos_file);
		if (line[998] == '\n' || line[998] == '\0') {
			ds_size++;
		}
		else {
			line[998] = '\0';
		}
	}
	fclose(pos_file);

	chrono::steady_clock::time_point sample_start = chrono::steady_clock::now();
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	mt19937_64 generator(seed);
	uniform_int_distribution<int> distribution(0, ds_size - 1);

    unsigned int sample_size_1 = get_sample_size_1(theta, Imax, epsilon, delta);

    pair<unsigned int, vector<unsigned int>>result1 = take_sample_1( 
																	dataset, 
																	&distribution, 
																	sample_size_1, 
																	&generator, 
																	Imax, 
																	theta-0.5*epsilon);
	
    map<unsigned int, unsigned int> Map, rMap;

	int i,idx;
	idx = 1;
    vector<float> v1, v2;
    float sup;
	for(i=0;i< max(10000, Imax + 1);i++){
		if(result1.second[i]>0){
			Map.insert(pair<unsigned int, unsigned int>(i,idx));
            rMap.insert(pair<unsigned int, unsigned int>(idx,i));
			idx++;
            sup = float(result1.second[i])/sample_size_1;
            result1.second[i] = 1;
            if(sup<=0.5-epsilon){
                 v1.push_back(sup);
            }
            else{
                v2.push_back(sup);
            }    
		}   
	}

	cout << "v1 and v2 sizes are " << v1.size()<<" "<<v2.size() << "\n";

    sort(v1.begin(),v1.end());

    unsigned int sample_size_2 = get_sample_size_2(theta, v1, v2, epsilon, delta);

	take_sample_2_bitset1000( 
							sample_size_2, 
							dataset, 
							&distribution, 
							&generator, 
							result1.second, 
							Map, 
							rMap, 
							Imax);

	chrono::steady_clock::time_point sample_end = chrono::steady_clock::now();
	chrono::duration<double> sample_time = chrono::duration_cast<chrono::duration<double>>(sample_end - sample_start);

	chrono::steady_clock::time_point mine_start = chrono::steady_clock::now();
    char minsup[9];
	sprintf(minsup,"%3.4f", (theta-0.5*epsilon)*100);
	string csp(minsup);
    string cmd = "fpgrowth -w -ts -s"+csp+" sample.dat result_sg.dat";
	system(cmd.c_str());

	chrono::steady_clock::time_point mine_end = chrono::steady_clock::now();
	chrono::duration<double> mine_time = chrono::duration_cast<chrono::duration<double>>(mine_end - mine_start);

	cout << "sampling time is " << sample_time.count() * 1000 << " ms;\n";
	cout << "mining time is " << mine_time.count() * 1000 << " ms;\n";
	cout << "total time is " << (mine_time.count()+ sample_time.count()) * 1000 << " ms;\n";
	cout << "first sample size is" << sample_size_1 << "\n";
	cout << "second sample size is" << sample_size_2 << "\n";
	cout << "total size is" << sample_size_2+sample_size_1 << "\n";

	ofstream rfile("record_sg.dat", std::ios::out | std::ios::app);
	rfile << "-----------------------------------------------\n";
	rfile << "sampling time is " << sample_time.count() * 1000 << " ms;\n";
	rfile << "mining time is " << mine_time.count() * 1000 << " ms;\n";
	rfile << "total time is " << (mine_time.count() + sample_time.count()) * 1000 << " ms;\n";
	rfile << "first sample size is" << sample_size_1 << "\n";
	rfile << "second sample size is" << sample_size_2 << "\n";
	rfile << "total size is" << sample_size_2 + sample_size_1 << "\n";
	rfile << "minimum support is " << theta << "\n";
	rfile << "epsilon is " << epsilon << "\n";
	rfile << "delta is " << delta << "\n";
	rfile << "data is " << dataset << "\n";
	rfile.close();
    return EXIT_SUCCESS;
}