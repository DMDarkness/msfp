/**
 * Compute a sample of a transactional dataset which can be used to obtain an
 * (eps,delta)-approximation of the collection of Frequent Itemsets. The
 * algorithm uses progressive sampling with a stopping condition based on bounds
 * to the empirical Rademacher averages.
 *
 * Copyright 2014-15 Matteo Riondato <matteo@cs.brown.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#define _CRT_SECURE_NO_WARNINGS

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cfloat>
#include <cmath>
#include <climits>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <map>
#include <random>
#include <unordered_map>
#include <vector>



#include "unistd.h"
using namespace std;
using namespace std::chrono;

#include "rade.h"
#include "rade_bounds.h"
#include "rade_bounds_ci.h"
#include "rade_io.h"
#include "rade_sample.h"
#include "stats.h"
#include "util.h"




extern bool compute_for_topk; // when true, compute a sample for the top-k frequent itemsets
extern bool automatic_schedule; // when true, use automatic schedule
extern bool geometric_schedule; // when true, use geometric schedule
extern bool linear_schedule; // when true, use linear schedule
extern bool wait_for_all; // wait for all stopping conditions to be satisfied before returning
extern char *dataset; // dataset filename
extern unsigned int initial_sample_size; // initial sample size;
extern unsigned int linear_schedule_addend; // control the growth of the sample size when using the linear schedule
extern double geometric_schedule_multiplier; // control the growth of the sample size when using the geometric schedule

unsigned long sampling_time = 0ul;
unsigned long mining_time = 0ul;
unsigned long stopcond_time = 0ul;
unsigned int dataset_size = 0u;
unsigned int sample_size = 0u;
unsigned int max_transaction_length = 0u;
// The following maps store the support of the items, one as if the sample
// was a bag of transactions, the other as if the sample was a set (no
// duplicates).
map<unsigned int, unsigned int> sample_items_sample_as_bag;
map<unsigned int, unsigned int> sample_items_sample_as_set;

// Initialize random number generator

unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();;

mt19937_64 generator(seed);

/**
 * Main
 */
int main(int argc, char* argv[]) {
	// Parse command line options
	cout << "start\n";
	int opt_ret = parse_command_line(argc, argv);
	if (opt_ret == 1) {
		return EXIT_FAILURE;
	} else if (opt_ret == 0) {
		return EXIT_SUCCESS;
	}

	// Get dataset size (doing it now because we assume to have it)
	dataset_size = get_size(dataset);
	cout << dataset_size << "\n";//zzj
	//return EXIT_SUCCESS;//zzj
	// Initialize data structures
	bool stopping_condition_standard_is_satisfied = false;
	bool stopping_condition_new_is_satisfied = false;
	bool stopping_condition_refined_is_satisfied = false;
	bool stopping_condition_optimize_is_satisfied = false;
	const long double max_deviation = (compute_for_topk) ? epsilon / 4.0 :
		epsilon / 2.0;

	// Make sure that the initial sample size is large enough to make sense. If
	// it is smaller than this quantity, the stopping condition will surely not
	// be satisfied at the initial sample size
	unsigned int minimum_sample_size = (unsigned int) ceil(8.0 * log(2.0 / delta) / pow(epsilon, 2.0));
	if (initial_sample_size < minimum_sample_size) {
		cerr << LOG_HEADER << "initial sample size increased to " <<
			minimum_sample_size << " (was " << initial_sample_size << ")" <<
			endl;
		initial_sample_size = minimum_sample_size;
	}
	unsigned int to_sample = initial_sample_size;
	sample_size = initial_sample_size;
	unsigned int iteration = 1u;

	// Open dataset file
	FILE *ds_FILE = fopen(dataset, "r");
	if (ds_FILE == NULL) {
		perror("Error opening dataset file");
		return errno;
	}



	// Progressive sampling process
	while (true) {
		if (verbose) {
			cerr << VERBOSE_HEADER << "iteration: " << iteration <<
				", sample_size: " << sample_size << endl;
		}
		cout << sample_size << "\n";
		sampling_time += sample(ds_FILE, to_sample);
		cout << "sample_completed" << "\n";

		auto stopcond_start_time = steady_clock::now();
		// Compute bounds to the empirical Rademacher average
		const long double rademacher_bound_standard = (use_standard_stop_cond) ?
			get_rademacher_bound_standard() : LDBL_MAX;
		const long double rademacher_bound_new = (use_new_stop_cond) ?
			get_rademacher_bound_new() : LDBL_MAX;
		const long double rademacher_bound_refined = (use_refined_stop_cond) ?
			get_rademacher_bound_refined() : LDBL_MAX;

		const long double rademacher_bound_optimize = (use_optimize_stop_cond) ?
			get_rademacher_bound_optimize() : LDBL_MAX;


		// Compute bounds to the maximum deviation
		const long double deviation_bound_standard = (use_standard_stop_cond) ?
			get_max_deviation_bound(rademacher_bound_standard) : DBL_MAX;
		const long double deviation_bound_new = (use_new_stop_cond) ?
			get_max_deviation_bound(rademacher_bound_new) : DBL_MAX;
		const long double deviation_bound_refined = (use_refined_stop_cond) ?
			get_max_deviation_bound(rademacher_bound_refined) : DBL_MAX;
		const long double deviation_bound_optimize = (use_optimize_stop_cond) ?
			get_max_deviation_bound(rademacher_bound_optimize) : DBL_MAX;

		// Check the stopping condition
		stopping_condition_standard_is_satisfied = deviation_bound_standard <= max_deviation;
		stopping_condition_new_is_satisfied = deviation_bound_new <= max_deviation;
		stopping_condition_refined_is_satisfied = deviation_bound_refined <= max_deviation;
		stopping_condition_optimize_is_satisfied = deviation_bound_optimize <= max_deviation;

		auto stopcond_end_time = steady_clock::now();
		stopcond_time += duration_cast<milliseconds>(stopcond_end_time -
				stopcond_start_time).count();

		const bool dont_wait_cond = (! wait_for_all) &&
			(stopping_condition_standard_is_satisfied ||
				stopping_condition_new_is_satisfied ||
				stopping_condition_refined_is_satisfied ||
				stopping_condition_optimize_is_satisfied);
		const bool wait_cond = wait_for_all && ((use_standard_stop_cond) ?
				stopping_condition_standard_is_satisfied : true) &&
			((use_new_stop_cond) ? stopping_condition_new_is_satisfied : true)
			&& ((use_refined_stop_cond) ?
					stopping_condition_refined_is_satisfied: true) &&
			((use_optimize_stop_cond) ? stopping_condition_optimize_is_satisfied
				: true);

		if (dont_wait_cond || wait_cond) {
			break;
		} else {
			rewind(ds_FILE);
			unsigned int new_sample_size = 0u;
			if (geometric_schedule) {
				new_sample_size = (unsigned int) (sample_size *
						geometric_schedule_multiplier);
			} else if (linear_schedule) {
				new_sample_size = initial_sample_size + linear_schedule_addend *
					iteration;
			} else if (automatic_schedule) {
				/** Old version based on bound to the number of CI, using
				 * equation 4 from Boucheron, Bousquet, Lugosi, Theory of
				 * classification: A survey of some recent advances.
				 *
				const double log_2_delta = M_LN2 - log(delta);
				const double mixed_term =  M_SQRT2 * 2.0 *
					sqrt(get_log_CI_bound(sample_items_sample_as_set)) *
					max_deviation *
					get_max_item_supp(sample_items_sample_as_bag);
				new_sample_size = (log_2_delta + sqrt(log_2_delta * (
								log_2_delta + 2.0 * mixed_term)) + mixed_term) /
					pow(max_deviation, 2.0);
				*/
				const long double minimum = min(deviation_bound_standard,
						min(deviation_bound_new, min(deviation_bound_refined,
								deviation_bound_optimize)));
				new_sample_size = sample_size * pow(minimum / max_deviation,
						2.0);
			} else {
				// NOT REACHED
				cerr << ERROR_HEADER << "you shouldn't be here!" << endl;
				return EXIT_FAILURE;
			}
			if (new_sample_size == sample_size) {
				break;
			}
			to_sample = new_sample_size - sample_size;
			sample_size = new_sample_size;
			iteration++;
		}
	}
	// Close dataset file
	fclose(ds_FILE);



	// Print sampled transactions
	print_sample();


	string command = "fpgrowth -w -ts -s"+to_string(msupport*100)+" sample.dat result.dat";
	auto mining_start_time = steady_clock::now();
	system(command.c_str());
	auto mining_end_time = steady_clock::now();
	mining_time += duration_cast<milliseconds>(mining_end_time -mining_start_time).count();


	cout << "sampling time is " << sampling_time << " ms;\n";
	cout << "stopcond time is " << stopcond_time << " ms;\n";
	cout << "mining time is " << mining_time << " ms;\n";
	cout << "sample size is " << sample_size << "\n";
	cout << "total time is " << sampling_time + stopcond_time + mining_time << "\n";

	ofstream rfile("record_ProgSampRA.dat", std::ios::out | std::ios::app);
	rfile << "-----------------------------------------------\n";
	rfile << "sampling time is " << sampling_time << " ms;\n";
	rfile << "stopcond time is " << stopcond_time << " ms;\n";
	rfile << "mining time is " << mining_time << " ms;\n";
	rfile << "total time is " << sampling_time + stopcond_time + mining_time << "\n";
	rfile << "sample size is " << sample_size << "\n";
	rfile << "minimum support is " << msupport << "\n";
	rfile << "epsilon is " << epsilon << "\n";
	rfile << "delta is " << delta << "\n";
	rfile << "data is " << dataset << "\n";
	rfile.close();

	return EXIT_SUCCESS;
}

