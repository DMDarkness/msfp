/**
 * Compute (or read from metadata) various dataset statistics: number of
 * transactions, number of items, maximum transaction lengths, upper bound to
 * the d-index, h-index, minimum and maximum attainable utilities. 
 * Can handle both utility and "normal" format of transactions.
 * Datasets may contain metadata, which are special lines starting with
 * "#KEYWORD:", where KEYWORD is one of: size, items, dindex, hindex, maxlen,
 * minattutil, maxattutil.
 * The algorithm used to compute the upper bound to d-index is Algorithm 1 from
 * Riondato M. and Upfal E., "Efficient Discovery of Association Rules and
 * Frequent Itemsets through Sampling with Tight Performance Guarantees", ACM
 * Transactions on Knowledge Discovery from Data.
 *
 * Copyright 2014 Matteo Riondato <matteo@cs.brown.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

#ifndef STATS_H 
#define STATS_H 

#include <cstring>
#include <set>
#include <unordered_map>

using namespace std;

// Magic strings for stats
static const string stat_items = "items";
static const string stat_size = "size";
static const string stat_dindex = "dindex";
static const string stat_hindex = "hindex";
static const string stat_maxlen = "maxlen";
static const string stat_maxattutil = "maxattutil";
static const string stat_minattutil = "minattutil";
static const string is_utility_dataset = "is_utility_dataset";
static const string colons = ":";

void print_stats(unordered_map<string,double>& stats);
double get_transaction_util(char *line);
double get_min_util(char *line);
unsigned int get_d_index_bound(const char *in_filename);
unsigned int get_size(const char *in_filename, const bool use_metadata = true);
unordered_map<string, double> get_stats(const char *in_filename, const bool use_metadata = true);
#endif
