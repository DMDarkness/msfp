/**
 *
 * Copyright 2015 Matteo Riondato <matteo@cs.brown.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

#include <cmath>

#include "vc_sample.h"

/**
 * Compute the sample size using the VC-dimension formula
 *
 * The 'vc_constant' parameter is the absolute constant for the sample size
 * (often known as 'c'). In "Maarten Loeffler and Jeff M. Phillips, Shape
 * Fitting on Point Sets with Probability Distributions, ESA'09", it is stated
 * that this constant is approximately 0.5, but that is not a proof.
 */
unsigned int get_sample_size(double epsilon, double delta, unsigned int d_index, double vc_constant) {
	return (unsigned int) ceil((4.0 * vc_constant * (d_index - log(delta))) /
			pow(epsilon, 2.0));
}

/**
 * Given a sample size, delta, and d_index, return the corresponding epsilon
 * using the VC-dimension formula
 */
double get_epsilon(unsigned int sample_size, double delta, unsigned int d_index, double vc_constant) {
	return sqrt((4.0 * vc_constant * (d_index  - log(delta))) / sample_size);
}
