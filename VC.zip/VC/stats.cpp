/**
 * Compute (or read from metadata) various dataset statistics: number of
 * transactions, number of items, maximum transaction lengths, upper bound to
 * the d-index, h-index, minimum and maximum attainable utilities. 
 * Can handle both utility and "normal" format of transactions.
 * Datasets may contain metadata, which are special lines starting with
 * "#KEYWORD:", where KEYWORD is one of: size, items, dindex, hindex, maxlen,
 * minattutil, maxattutil.
 * The algorithm used to compute the upper bound to d-index is Algorithm 1 from
 * Riondato M. and Upfal E., "Efficient Discovery of Association Rules and
 * Frequent Itemsets through Sampling with Tight Performance Guarantees", ACM
 * Transactions on Knowledge Discovery from Data.
 *
 * Copyright 2014 Matteo Riondato <matteo@cs.brown.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
#define _CRT_SECURE_NO_WARNINGS

#include <algorithm>
#include <cassert>
#include <cerrno>
#include <cfloat>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <set>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using namespace std;

#include "stats.h"
#include "util.h"

extern bool verbose;

/**
 * Print stats
 *
 */
void print_stats(unordered_map<string,double>& stats) {
	cout << "#" << stat_size << ": " << (int) stats[stat_size] << endl;
	cout << "#" << stat_items << ": " << (int) stats[stat_items] << endl;
	cout << "#" << stat_hindex << ": " << (int) stats[stat_hindex] << endl;
	cout << "#" << stat_dindex << ": " << (int) stats[stat_dindex] << endl;
	cout << "#" << stat_maxlen << ": " << (int) stats[stat_maxlen] << endl;
	if (stats[is_utility_dataset] == 1.0) {
		cout << "#" << stat_maxattutil << ": " << stats[stat_maxattutil] << endl;
		cout << "#" << stat_minattutil << ": " << stats[stat_minattutil] << endl;
	}
}

/**
 * Return the transaction utility (i.e., \util(line,line))
 *
 */
double get_transaction_util(char *line) {
	char *start = strstr(line, colons.c_str()) + 1;
	// We copy the line because we modify it.
	char *copy = (char *) malloc_check(strlen(start) + 1, "get_transaction_util");
	strncpy(copy, start, strlen(start) + 1);
	char *end = strstr(copy, colons.c_str()) + 1;
	*end = '\0';
	double util = strtod(copy, NULL);
	free(copy);
	return util;
}

/**
 * Return the minimum item utility in the transactions
 *
 */
double get_min_util(char *line) {
	char *start = strstr(line, colons.c_str()) + 1;
	start = strstr(line, colons.c_str()) + 1;
	// We copy the line because we modify it.
	char *copy = (char *) malloc_check(strlen(start) + 1, "get_min_util");
	char *orig_copy = copy;
	strncpy(copy, start, strlen(start) + 1);
	char *token;
	double min_util = DBL_MAX;
	token = strtok(copy, "  ");
	while (token != NULL) {
		double curr_util = strtod(token, NULL);
		min_util = fmin(curr_util, min_util);
		token = strtok(NULL, "  ");
	}
	free(orig_copy);
	return min_util;
}

/**
 * Compute the (upper bound to the) d-index
 *
 * Metadata (if present) is ignored on purpose for timing purposes
 *
 * The algorithm to compute the upper bound to the d-index is Algorithm 1 from
 * M. Riondato and E. Upfal, Efficient Discovery of Association Rules and
 * Frequent Itemsets through Sampling with Tight Performance Guarantees, ACM
 * Transactions on Knowledge Discovery from Data.
 *
 */
unsigned int get_d_index_bound(const char *in_filename) {
	FILE *in_file = fopen(in_filename, "r");
	if (in_file == NULL) {
		perror("Error opening input file");
		exit(errno);
	}

	char line[TRANSACTION_LINE_MAXLEN];
	// This is to store the long transactions 
	vector<set<unsigned int>> long_transactions_d; 

	// Read first transaction
	get_next_line(line, sizeof(line), in_file);
	set<unsigned int> first_transaction = transaction_to_set(line);
	long_transactions_d.push_back(first_transaction);
	unsigned int d_index = 1;

	unsigned int Num = 0;

	// Iterate over all transactions to compute bound to d-index
	while (get_next_line(line, sizeof(line), in_file)) {
		Num++;
		if (Num % 10000000 == 0) {
			cout << Num << "\n";
		}
		set<unsigned int> curr_transaction = transaction_to_set(line);
		unsigned int curr_transaction_len = curr_transaction.size();

		// Only process if longer than candidate d-index
		if (curr_transaction_len > d_index) {
			// We now check whether this transaction is a subset of
			// one of the long transactions we stored
			bool process = true;
			for (set<unsigned int> long_transaction :
					long_transactions_d) {
				if (includes(long_transaction.begin(),
						long_transaction.end(),
						curr_transaction.begin(),
						curr_transaction.end()))  {
					process = false;
					break;
				}
			}
			// If it was a subset of a long transaction, skip it and
			// go to the next one
			if (!process) {
				continue; // iterate the main while loop
			}
			// The transaction is longer than d-index and not a
			// subset of a longer transaction. Add it to the list of
			// long transactions
			long_transactions_d.push_back(curr_transaction);
			// Sort the long transactions by size in reverse order
			sort(long_transactions_d.begin(), long_transactions_d.end(),
					set_is_larger);
			// Compute new candidate d-index
			if (long_transactions_d[d_index].size() > d_index) {
				++d_index;
			}

			// Trim the vector of long transactions
			long_transactions_d.resize(d_index);
		}
	}
	fclose(in_file);



	return d_index;
}

/**
 * Compute the size of the dataset. 
 * If use_metadata is true, look for metadata and use them if found.
 *
 */
unsigned int get_size(const char *in_filename, const bool use_metadata) {
	unsigned int size = 0;
	//cout << "eee" << "\n";//zzj
	FILE *in_file = fopen(in_filename, "r");
	if (in_file == NULL) {
		perror("Error opening input file");
		exit(errno);
	}
	char line[TRANSACTION_LINE_MAXLEN];
	while (! feof(in_file)) {
		//cout << size << "\n";//zzj
		fgets(line, sizeof(line), in_file);
		// Is this a metadata line?
		if (line[0] == '#') {
			if (use_metadata) {
				char *start = strstr(line, colons.c_str()) + 1;
				if (strstr(line, (stat_size + colons).c_str()) != NULL) {
					size = strtol(start, NULL, 10);
					break;
				}
			}
		} else {
			++size;
		}
	}
	fclose(in_file);
	return size;
}

/**
 * Compute various dataset statistics: size, items, max transaction length,
 * h-index and (upper bound to) d-index.
 *
 * If 'use_metadata' is true, we first check whether there are metadata in
 * the file.
 *
 * The algorithm to compute the upper bound to the d-index is Algorithm 1 from
 * M. Riondato and E. Upfal, Efficient Discovery of Association Rules and
 * Frequent Itemsets through Sampling with Tight Performance Guarantees, ACM
 * Transactions on Knowledge Discovery from Data.
 *
 */
unordered_map<string, double> get_stats(const char *in_filename, const bool use_metadata) {
	FILE *in_file = fopen(in_filename, "r");
	if (in_file == NULL) {
		perror("Error opening input file");
		exit(errno);
	}

	unordered_map<string, double> stats;

	char line[TRANSACTION_LINE_MAXLEN];
	stats[is_utility_dataset] = 0.0;
	if (use_metadata) {
		// Try to read metadata
		bool found_items = false;
		bool found_size =  false;
		bool found_hindex = false;
		bool found_dindex = false;
		bool found_maxlen = false;
		bool found_maxattutil = false;
		bool found_minattutil = false;
		while (! feof(in_file)) {
			fgets(line, sizeof(line), in_file);

			// Is this a metadata line?
			if (line[0] == '#') {
				char *start = strstr(line, colons.c_str()) + 1;
				if (strstr(line, (stat_items + colons).c_str()) != NULL) {
					stats[stat_items] = strtol(start, NULL, 10);
					found_items = true;

				} else if (strstr(line, (stat_size + colons).c_str()) != NULL) {
					stats[stat_size] = strtol(start, NULL, 10);
					found_size = true;

				} else if (strstr(line, (stat_hindex + colons).c_str()) != NULL) {
					stats[stat_hindex] = strtol(start, NULL, 10);
					found_hindex = true;

				} else if (strstr(line, (stat_dindex + colons).c_str()) != NULL) {
					stats[stat_dindex] = strtol(start, NULL, 10);
					found_dindex = true;

				} else if (strstr(line, (stat_maxlen + colons).c_str()) != NULL) {
					stats[stat_maxlen] = strtol(start, NULL, 10);
					found_maxlen = true;

				} else if (strstr(line, (stat_maxattutil + colons).c_str()) != NULL) {
					stats[stat_maxattutil] = strtol(start, NULL, 10);
					found_maxattutil = true;

				} else if (strstr(line, (stat_minattutil + colons).c_str()) != NULL) {
					stats[stat_minattutil] = strtol(start, NULL, 10);
					found_minattutil = true;

				}
			} else { // i.e., if line is not a metadata line
			  // check whether the file is a utility dataset or a plain one
				if (strstr(line, colons.c_str()) != NULL) {
					stats[is_utility_dataset] = 1.0;
				}
			}
		}
		// If all the stats were found, just return
		if (stats[is_utility_dataset] == 1.0) {
			if (found_items && found_size && found_dindex && found_hindex && found_maxlen && found_maxattutil && found_minattutil) {
				fclose(in_file);
				return stats;
			}
		} else if (found_items && found_size && found_dindex && found_hindex && found_maxlen) {
			fclose(in_file);
			return stats;
		}

		if (verbose) {
			cerr << VERBOSE_HEADER << "not all stats found, rewinding and computing" << endl;
		}
	} else { // if (use_metadata)
		while (! feof(in_file)) {
			fgets(line, sizeof(line), in_file);
			if (line[0] != '#') { // i.e., if line is not a metadata line
				// check whether the file is a utility dataset or a plain one
				if (strstr(line, colons.c_str()) != NULL) {
					stats[is_utility_dataset] = 1.0;
				}
				break; // we found a non-metadata line, so we can exit the loop;
			}
		}
	}

	// Rewind file and compute statistics if not all were found in metadata or
	// metadata ignored
	fseek(in_file, 0, SEEK_SET);

	// We assume that items are non-negative integers
	unordered_set<unsigned int> items; 
	// This is to store the long transactions for the h-index computation
	vector<set<unsigned int>> long_transactions_h; 
	// This is to store the long transactions for the d-index computation
	vector<set<unsigned int>> long_transactions_d; 

	// Read first transaction
	get_next_line(line, sizeof(line), in_file);
	set<unsigned int> first_transaction = transaction_to_set(line);
	long_transactions_h.push_back(first_transaction);
	long_transactions_d.push_back(first_transaction);
	for (unsigned int item : first_transaction) {
		items.insert(item);
	}
	stats[stat_maxlen] = first_transaction.size();
	stats[stat_size] = 1.0;
	stats[stat_dindex] = 1.0;
	stats[stat_hindex] = 1.0;
	if (stats[is_utility_dataset] == 1) {
		stats[stat_maxattutil] = get_transaction_util(line);
		stats[stat_minattutil] = get_min_util(line);
	}

	// Iterate over all transactions to compute stats
	while (get_next_line(line, sizeof(line), in_file)) {
		if (verbose && ((unsigned int) stats[stat_size]) % 1000000u == 0u) {
			cerr << VERBOSE_HEADER << "Read: " << stats[stat_size] << endl;
		}
		set<unsigned int> curr_transaction = transaction_to_set(line);
		unsigned int curr_transaction_len = curr_transaction.size();
		for (unsigned int item : curr_transaction) {
			items.insert(item);
		}
		// Increase size stat
		stats[stat_size]++;

		// Update (if needed) maxattutil and minattutil
		if (stats[is_utility_dataset] == 1.0) {
			double curr_max_util = get_transaction_util(line);
			double curr_min_util = get_min_util(line);
			stats[stat_maxattutil] = fmax(stats[stat_maxattutil], curr_max_util);
			stats[stat_minattutil] = fmin(stats[stat_minattutil], curr_min_util);
		}

		// Only process if longer than candidate h-index
		if (curr_transaction_len > stats[stat_hindex]) {
			long_transactions_h.push_back(curr_transaction);
			// Sort the long transactions by size in reverse order
			sort(long_transactions_h.begin(), long_transactions_h.end(),
					set_is_larger);
			// Compute new candidate h-index
			if (long_transactions_h[stats[stat_hindex]].size() > stats[stat_hindex]) {
			  stats[stat_hindex] += 1.0;
			}
			// Trim the vector of long transactions
			long_transactions_h.resize(stats[stat_hindex]);

			// Update maxlen stat if needed
			if (curr_transaction_len > stats[stat_maxlen]) {
				stats[stat_maxlen] = curr_transaction_len; 
			}
		}

		// Only process if longer than candidate d-index
		if (curr_transaction_len > stats[stat_dindex]) {
			// We now check whether this transaction is a subset of
			// one of the long transactions we stored
			bool process = true;
			for (set<unsigned int> long_transaction :
					long_transactions_d) {
				if (includes(long_transaction.begin(),
						long_transaction.end(),
						curr_transaction.begin(),
						curr_transaction.end()))  {
					process = false;
					break;
				}
			}
			// If it was a subset of a long transaction, skip it and
			// go to the next one
			if (!process) {
				continue; // iterate the main while loop
			}
			// The transaction is longer than d-index and not a
			// subset of a longer transaction. Add it to the list of
			// long transactions
			long_transactions_d.push_back(curr_transaction);
			// Sort the long transactions by size in reverse order
			sort(long_transactions_d.begin(), long_transactions_d.end(),
					set_is_larger);
			// Compute new candidate d-index
			if (long_transactions_d[stats[stat_dindex]].size() > stats[stat_dindex]) {
			  stats[stat_dindex] += 1.0;
			}

			// Trim the vector of long transactions
			long_transactions_d.resize(stats[stat_dindex]);
		}

		// Add transaction items to set
		for (unsigned int item : curr_transaction) {
			items.insert(item);
		}
	}
	fclose(in_file);

	// Compute number of items
	stats[stat_items] = items.size();

	return stats;
}
