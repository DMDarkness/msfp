/**
 * Compute a sample of a transactional dataset which can be used to obtain an
 * (eps,delta)-approximation of the collection of Frequent Itemsets. The
 * algorithm uses static sampling with a sample size computed using an upper
 * bound to the VC-dimension of the problem.
 *
 * Copyright 2014 Matteo Riondato <matteo@cs.brown.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <forward_list>
#include <iostream>
#include <fstream>
#include <random>
#include <vector>

#include "unistd.h"
#include "getopt.h"
#include "stats.h"
#include "util.h"
#include "vc_sample.h"

using namespace std;
using namespace std::chrono;

bool verbose = false;

void usage(char *binary_name) {
	cerr << binary_name << ": static sampling algorithm to extract an (eps,delta)-approximation" << endl;
	cerr << "USAGE: " << binary_name << " [-h] [-m] [-v] epsilon delta dataset" << endl;
	cerr << "Sample a number of transactions from dataset sufficient to get an (epsilon,delta)-approximation" << endl;
	cerr << "\t-h : print this message and exit" << endl;
	cerr << "\t-m : keep the sample in memory and only print it to stdout at the end" << endl;
	cerr << "\t-v : verbose output" << endl;
}

int main(int argc, char **argv) {
	bool sample_in_memory = false;
	int opt;

	if (argc - 4<0) {
		cerr << ERROR_HEADER << "wrong number of arguments" << endl;
		return EXIT_FAILURE;
	} 
	double msupport = strtod(argv[argc - 4], NULL);
	if (errno == ERANGE || msupport >= 1.0 || msupport <= 0.0) {
		cerr << ERROR_HEADER <<
			"minimum support should be greater than 0 and smaller than 1"
			<< endl;
		return EXIT_FAILURE;
	}
	double epsilon = strtod(argv[argc - 3], NULL);
	if (errno == ERANGE || epsilon >= 1.0 || epsilon <= 0.0) {
		cerr << ERROR_HEADER << 
			"epsilon should be greater than 0 and smaller than 1" 
			<< endl;
		return EXIT_FAILURE;
	}
	double delta = strtod(argv[argc - 2], NULL);
	if (errno == ERANGE || delta >= 1.0 || delta <= 0.0) {
		cerr << ERROR_HEADER << 
			"delta should be greater than 0 and smaller than 1" 
			<< endl;
		return EXIT_FAILURE;
	}
	char *dataset = argv[argc - 1];
	cout << msupport << " " << epsilon << "  " << delta << " " << dataset << "\n"; //zzj
	double ds_size = get_size(dataset);

	// Initialize random number generator
/*#ifndef DEBUG
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
#else*/
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
//#endif
	mt19937_64 generator(seed);
	uniform_int_distribution<int> distribution(0, ds_size - 1);

	auto start = steady_clock::now();

	unsigned int d_index = get_d_index_bound(dataset);
	auto d_index_end = steady_clock::now();
	unsigned int sample_size = get_sample_size(epsilon, delta, d_index);
	if (verbose) {
		cerr << VERBOSE_HEADER << "d_index: " << d_index << ", sample_size: " <<
			sample_size << ", time: " <<
			duration_cast<milliseconds>(d_index_end - start).count() << " ms" <<
			endl;
	}

	FILE *ds_FILE = fopen(dataset, "r");
	if (ds_FILE == NULL) {
		perror("Error opening input file");
		return errno;
	}

	// Add transactions to sample (printing them to stdout)
	vector<unsigned int> sampled_indices(sample_size, 0);
	for (unsigned int i = 0; i < sample_size; ++i) {
		sampled_indices[i] = distribution(generator);
	}
	sort(sampled_indices.begin(), sampled_indices.end());

	unsigned int transaction_index = -1;
	unsigned int sampled_index = 0;
	// Using a forward list as we don't need sequential access.
	forward_list<string> sampled_transactions;
	char line[TRANSACTION_LINE_MAXLEN];

	ofstream file("sample.dat", std::ios::out | std::ios::trunc);
	while (sampled_index < sample_size) {
		// Read line
		do {
			get_next_line(line, sizeof(line), ds_FILE);
			transaction_index++;
		} while (transaction_index < sampled_indices[sampled_index]);

		unsigned int base_transaction_id = sampled_indices[sampled_index];

		string transaction(line);

		unsigned int weight = 0;
		do {
			sampled_index++;
			weight++;
		} while (sampled_index < sample_size &&
				sampled_indices[sampled_index] ==
				base_transaction_id);
		file << transaction.substr(0, transaction.length() - 1) << " " << weight << "\n";
	}
	file.close();
	auto end = steady_clock::now();
	unsigned long elapsed = duration_cast<milliseconds>(end - start).count();
	unsigned long d_index_elapsed = duration_cast<milliseconds>(d_index_end - start).count();

	string command = "fpgrowth -w -ts -s" + to_string(msupport * 100) + " sample.dat result.dat";
	auto mining_start_time = steady_clock::now();
	system(command.c_str());
	auto mining_end_time = steady_clock::now();
	unsigned long mining_time = duration_cast<milliseconds>(mining_end_time - mining_start_time).count();


	cout << "d_index computing time " << d_index_elapsed << " ms;\n";
	cout << "sampling time is " << elapsed- d_index_elapsed << " ms;\n";
	cout << "mining time is " << mining_time << " ms;\n";
	cout << "total time is " << elapsed+mining_time << " ms;\n";
	cout << "sample size is " << sample_size << "\n";

	ofstream rfile("record_SampVC.dat", std::ios::out | std::ios::app);
	rfile << "-----------------------------------------------\n";
	rfile << "d_index computing time is " << d_index_elapsed << " ms;\n";
	rfile << "sampling time is " << elapsed - d_index_elapsed << " ms;\n";
	rfile << "mining time is " << mining_time << " ms;\n";
	rfile << "total time is " << elapsed + mining_time << " ms;\n";
	rfile << "sample size is " << sample_size << "\n";
	rfile << "minimum support is " << msupport << "\n";
	rfile << "epsilon is " << epsilon << "\n";
	rfile << "delta is " << delta << "\n";
	rfile << "data is " << dataset << "\n";
	rfile.close();

	return EXIT_SUCCESS;
}

